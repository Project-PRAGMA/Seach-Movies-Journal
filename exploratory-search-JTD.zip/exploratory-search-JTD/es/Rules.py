def weights_AV(k):
    return [1 for _ in range(0, k)]


def weights_CCAV(k):
    return [1] + [0 for _ in range(1, k)]


def weights_PAV(k):
    return [1 / i for i in range(1, k + 1)]


def weights_QAV(k, q):
    return [1 / (i ** q) for i in range(1, k + 1)]


AV = weights_AV(100)

CCAV = weights_CCAV(100)

PAV = weights_PAV(100)

QAV_0 = weights_QAV(100, 0)
QAV_1 = weights_QAV(100, 1)
QAV_1_1 = weights_QAV(100, 1.1)
QAV_1_2 = weights_QAV(100, 1.2)
QAV_1_3 = weights_QAV(100, 1.3)
QAV_1_4 = weights_QAV(100, 1.4)
QAV_1_5 = weights_QAV(100, 1.5)
QAV_1_6 = weights_QAV(100, 1.6)
QAV_1_7 = weights_QAV(100, 1.7)
QAV_1_8 = weights_QAV(100, 1.8)
QAV_1_9 = weights_QAV(100, 1.9)
QAV_2 = weights_QAV(100, 2)
QAV_3 = weights_QAV(100, 3)
QAV_10 = weights_QAV(100, 10)
QAV_20 = weights_QAV(100, 20)
QAV_30 = weights_QAV(100, 30)

HUV_0 = QAV_0
HUV_1 = QAV_1
HUV_2 = QAV_2
HUV_3 = QAV_3

rules_dict = {
    'av': AV, 'pav': PAV, 'ccav': CCAV,
    'HUV_0': QAV_0, 'HUV_1': QAV_1, 'HUV_1.1': QAV_1_1, 'HUV_1.2': QAV_1_2,
    'HUV_1.3': QAV_1_3, 'HUV_1.4': QAV_1_4, 'HUV_1.5': QAV_1_5, 'HUV_1.6': QAV_1_6,
    'HUV_1.7': QAV_1_7, 'HUV_1.8': QAV_1_8, 'HUV_1.9': QAV_1_9, 'HUV_2': QAV_2, 'HUV_3': QAV_3,
    'qav_1_5': QAV_1_5, 'qav_2': QAV_2, 'qav_3': QAV_3, 'qav_10': QAV_10, 'qav_20': QAV_20, 'qav_30': QAV_30
}

# index={'AV': AV, 'CCAV': CCAV, 'PAV': PAV}
