import time
from typing import List, Dict


# utility elections with OWA-based rules as ILP
#  maximize
#        \sum_a\sum_i^m{x_i * u_{a,i} * (\sum_j^ m{y_{a,i,j} * o_j}})
#  , where
#       a - agent, i - resource, j - resource, o - OWA vector, k - committee size
#       x_i - candidate i in the winning committee,
#       y_{a,i,j) - take o_j as OWA for agent a and candidate i
#  subject to
#       x, y - binary
#       \sum_i^m{x_i} = k
#       \sum_i^m{y_{a,i,j}} = 1, for all a, j
#       \sum_j^m{y_{a,i,j}} = 1, for all a, i
class OwaILP0(object):

    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        """

        :param m: the count of resources
        :param k: the committee size
        :param pref_profile: a dictionary of resource-0-based-index to utility
        :param owa_vector: owa vector
        :param verbose:
        """
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        self.k = k
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.last_timestamp = time.time()

    def run(self):
        committee = []  # we use a list to make sure the order is preserved
        committee_score = -1

        import gurobipy as gp
        from gurobipy import GRB

        try:
            n, m, k = self.n, self.m, self.k
            pref_profile = self.pref_profile
            owa = self.owa_vector

            # Create a new model
            model = gp.Model("utOWA")

            # Create variables
            x = model.addMVar((m,), vtype=GRB.BINARY, name="x")
            y = model.addMVar((n, m, k), vtype=GRB.BINARY, name="y")

            # Set objective
            values = (x[i] * pref_profile[a][i] * sum((y[a, i, j] * owa[j] for j in range(k) if owa[j] != 0))
                      for a in range(n)
                      for i in range(m)
                      if i in pref_profile[a]
                      )
            model.setObjective(sum(values), GRB.MAXIMIZE)

            model.addConstr(x.sum() == k, "committee_size")

            for a in range(n):
                for i in range(m):
                    model.addConstr(y[a, i, :].sum() <= 1, "single_lambda_for_utility")
                for j in range(k):
                    model.addConstr(y[a, :, j].sum() == 1, "single_utility_for_lambda")

            # Optimize model
            model.optimize()

            committee = [ix for ix, v in enumerate(x.X) if round(v) == 1]
            committee_score = model.ObjVal

            if self.verbose > 1:
                print("INPUT: " + str(pref_profile))

                for v in model.getVars():
                    if v.VarName[0] == 'x':
                        print('%s %g' % (v.VarName, v.X))

                print('Obj: %g, calculated: %g' % model.ObjVal, self.score(committee))

            model.terminate()

        except gp.GurobiError as e:
            print('Gurobi Error ' + str(e))
            raise

        except AttributeError:
            print('Encountered an attribute error')
            raise

        return committee, committee_score

    def score(self, committee):
        score = 0.0
        for voter in self.pref_profile:
            utilities = sorted([voter[cix] for cix in committee if cix in voter], reverse=True)
            for utility, owa in zip(utilities, self.owa_vector):
                score += utility * owa
        return score
