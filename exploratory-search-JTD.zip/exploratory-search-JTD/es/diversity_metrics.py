import numpy as np


def compute_rank_distance_diversity(goal_pid2index, rule_winner_pids, ignore_order=False,
                                    distance_metric=lambda x, y: (abs(x - y) - 1) ** (1)):
    """
    how 'spread' is the result over the most relevant results: `goal_pid2index`
    - `goal_pid2index`: the most relevant indices of the rule's product_ids
    - sort the indices (if ignore_order)
    - compute distances between indices
    - apply distance metrics (e.g. square root so that single bigger distances don't impact results too much)
    - sum = diversity metric / len(rule_winners_pids)
    """
    rule_winner_goal_indices = ([goal_pid2index[pid] for pid in rule_winner_pids])
    if ignore_order:
        rule_winner_goal_indices = sorted(rule_winner_goal_indices)
    distance_metrics_value = [distance_metric(x, y) for x, y in
                              zip(rule_winner_goal_indices, rule_winner_goal_indices[1:])]
    return round(sum(distance_metrics_value) / len(distance_metrics_value), 2)


def compute_rank_mean_diversity(goal_pid2index, rule_winner_pids, weight_func=lambda i: 1.0):
    """
    how 'spread' is the result over the most relevant results: `goal_pid2index`
    - `goal_pid2index`: the most relevant indices of the rule's product_ids
    - diversity = sum the ranks of products from `rule_winner_pids` in `goal_pid2index`
    - return diversity / len(rule_winners_pids)
    """
    # print('mean diversity winner pids: ', rule_winner_pids)
    rule_winner_goal_indices = ([goal_pid2index[pid] for pid in rule_winner_pids])
    weighted_indices = [goal_index * weight_func(ix) for ix, goal_index in enumerate(rule_winner_goal_indices)]
    # print(rule_winner_goal_indices)
    return round(np.mean(weighted_indices), 2)


def compute_rank_distance_variance(goal_pid2index, rule_winner_pids, ignore_order, stats_func):
    rule_winner_goal_indices = ([goal_pid2index[pid] for pid in rule_winner_pids])
    if ignore_order:
        rule_winner_goal_indices = sorted(rule_winner_goal_indices)
    distances = [y - x for x, y in
                 zip(rule_winner_goal_indices, rule_winner_goal_indices[1:])]
    return round(stats_func(distances), 2)


def compute_rule_diversities(results_df, found_df_sorted, run_name, rule):
    goal_pid2index = {product_id: index for index, product_id in enumerate(found_df_sorted.product_id)}
    rule_winner_pids = list(
        results_df.query(f'run_name=="{run_name}" and rule=="{rule}"').sort_values('rank').product_id)
    return [
        # ('rank distance variance', compute_rank_distance_variance(goal_pid2index, rule_winner_pids, ignore_order=True, stats_func=np.var)),
        # ('rank distance stddev',
        #  compute_rank_distance_variance(goal_pid2index, rule_winner_pids, ignore_order=True, stats_func=np.std)),
        # ('average rank distance', compute_rank_distance_diversity(goal_pid2index, rule_winner_pids, ignore_order=False)),
        # ('average rank distance _ sorted', compute_rank_distance_diversity(goal_pid2index, rule_winner_pids, ignore_order=True)),
        ('average rank', compute_rank_mean_diversity(goal_pid2index, rule_winner_pids)),
        # ('weighted average rank 1', compute_rank_mean_diversity(goal_pid2index, rule_winner_pids,
        #                                                           weight_func=linear_ab_func(1, 1, len(
        #                                                               rule_winner_pids)))),
        # ('weighted average rank 2', compute_rank_mean_diversity(goal_pid2index, rule_winner_pids,
        #                                                               weight_func=linear_ab_func(2, 1, len(
        #                                                                  rule_winner_pids)))),
        # ('weighted average rank 4', compute_rank_mean_diversity(goal_pid2index, rule_winner_pids,
        #                                                               weight_func=linear_ab_func(4, 1, len(
        #                                                                  rule_winner_pids)))),
    ]


def linear_ab_func(a, b, k):
    delta = (b - a) / (k - 1)
    return lambda i: a + delta * i
