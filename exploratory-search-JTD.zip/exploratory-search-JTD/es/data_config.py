import os
import sys

data_folder = os.path.dirname(sys.modules[__name__].__file__) + "/../in"

data_folder_movielens_raw = f'{data_folder}/movielens_raw'
data_movielens_100k = f'{data_folder}/movielens_100k'
data_movielens_1m = f'{data_folder}/movielens_1m'
data_movielens_10m = f'{data_folder}/movielens_10m'
data_movielens_25m = f'{data_folder}/movielens_25m'

tables = ['aisles', 'departments', 'order_products__prior', 'order_products__train', 'orders', 'products']
