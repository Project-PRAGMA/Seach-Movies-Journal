import random
from collections import Counter
from typing import List, Callable

import numpy as np
import pandas as pd

from es.elections import InstacartDataFrames


class SyntheticDataCubeBuilder:
    def __init__(self,
                 cube_size: int, n_levels: int, n_candidates_per_area: int,
                 cube_proba: List[float], cand_weight_func: Callable[[int], float],
                 n_voters: int,
                 n_approvals_per_voter_func: Callable[[], int],
                 seed=13,
                 verbose=0):
        """
        The cube is divided into `cube_size x cube_size` areas at the first level.
        Each of the areas can recursively be divided at the second level, etc up till `n_levels`.
        Candidates' names are derived from the cube area indexes at a given level (from 0..`cube_size x cube_size`)
        and a candidate index in the given area (from 0..`n_candidates_per_area`),
        eg 'level1Index_level2Index.candidateIndex'.
        For example, for `n_levels`=2, `cube_size`=2, `n_candidates_per_area`=3 the candidates names will be:
        0_0.0, 0_0.1, ..., 3_3.2.

        The generator will produce `n_voters` voters, each approving `n_approvals_per_voter_func()` candidates.
        For a voter v the approval probability of a candidate x_y_z is equal to:
         permutation(v,level1)(cube_proba)[x] * permutation(v,level2)(cube_proba)[y] * cand_proba_func(z)
        , where cand_proba_func is obtained from cand_weight_func, so that it sums to 1.


        :param n_levels:
        :param cube_size: the width (and height) of a cube
        :param n_candidates_per_area:
        :param cube_proba: a probability per cube area at a single level (cube_size x cube_size in total)
        :param n_voters:
        :param n_approvals_per_voter_func: there might be less approvals if random choice 're-selects' candidates
        :param seed:
        :param verbose: from 0 (no logging) till 3 (most logging)
        """
        random.seed(seed)
        # =========================================================
        # cube_proba = [1.0/9]*9
        # cube_proba = [(1.0-.5)/8]*8 + [.5]
        # n_levels = 2
        # each level = list of (name, level_probability)
        n_areas_per_level = cube_size * cube_size
        assert len(cube_proba) == n_areas_per_level
        candidate_counter = Counter()

        # self.orders = [generate_voter_approvals(ix, n_voters) for ix in range(n_voters)]

        gen = VoterApprovalsGenerator(
            cube_proba=cube_proba,
            cand_weight_func=cand_weight_func,
            n_candidates_per_area=n_candidates_per_area,
            n_levels=n_levels
        )
        self.orders = [gen.generate_voter_approvals(n_approvals_per_voter_func()) for _ in range(n_voters)]

        self.candidate_names = list(gen.generate_candidate_names())

        if verbose >= 1:
            print()
            # print("-proba_profile:\n", "\n".join((str(x) for x in
            #                                       (list(generate_candidates(list(create_cell_proba_per_level())))))))
            # print("-accumulated_probas: \n", "\n".join([str(x) for x in zip(accumulated_probas, proba_profile)]))
            print("-most common:\n", "\n".join([str(x) for x in candidate_counter.most_common()[:20]]))

    def build(self):
        order_id2order = {ix + 1: order for ix, order in enumerate(self.orders)}
        order_df = pd.DataFrame([(oid, 1) for oid, order in order_id2order.items()], columns=['order_id', 'user_id'])
        product_name2id = {name: cand_ix + 1 for cand_ix, name in enumerate(self.candidate_names)}
        # product_id2name = { id: name for name, id in product_name2id.items() }
        product_df = pd.DataFrame([(pid, name, name[0], 1, 1) for name, pid in product_name2id.items()],
                                  columns="product_id,product_name,main_genre,aisle_id,department_id".split(','))
        op = [(oid, product_name2id[product_name]) for oid, order in order_id2order.items() for product_name in order]
        order_products_df = pd.DataFrame(op, columns="order_id,product_id".split(','))
        return ElectionData(product_df, order_df, order_products_df)

    @staticmethod
    def from_params(model_params, seed=13):
        builder = SyntheticDataCubeBuilder(
            cube_size=model_params.cube_size,
            n_levels=model_params.n_levels,
            n_candidates_per_area=model_params.cand_size * model_params.cand_size,
            cube_proba=model_params.cube_proba,
            #                                 cand_weight_func=lambda cand_ix: 5 - cand_ix,
            cand_weight_func=eval(model_params.cand_weight_func),
            n_voters=model_params.n_voters,
            n_approvals_per_voter_func=lambda: model_params.n_approvals_per_voter,
            verbose=0,
            seed=seed)
        idata = builder.build()

        iframes = InstacartDataFrames.from_data(idata)
        return idata, iframes


class VoterApprovalsGenerator:
    def __init__(self, cube_proba, cand_weight_func, n_levels, n_candidates_per_area, verbose=0):
        self.n_levels = n_levels
        self.verbose = verbose
        self.n_candidates_per_square = n_candidates_per_area
        self.cand_probas = self._weight_func2proba_func(cand_weight_func, n_candidates_per_area)
        self.cube_proba = cube_proba

    def generate_candidate_names(self):
        n_squares_per_level = len(self.cube_proba)

        def gen(level):
            if level == 1:
                for square_ix in range(n_squares_per_level):
                    for cand_ix in range(self.n_candidates_per_square):
                        yield f"{square_ix}c{cand_ix}"
            else:
                for candidate in gen(level - 1):
                    for square_ix in range(n_squares_per_level):
                        yield f"{square_ix}_{candidate}"

        return gen(level=self.n_levels)

    def generate_voter_approvals(self, n_approvals):
        """
        Generates at most `n_approvals` for voter `ix` driven by `self.cube_proba` and `self.cand_proba` and
        a randomly generated voter preference (IxMapper).

        :param n_approvals:
        :return:
        """
        acc_cube_probas = self._create_accumulated_probas(self.cube_proba)
        cand_proba = [self.cand_probas[area_candidate_ix] for area_candidate_ix in
                      range(self.n_candidates_per_square)]
        acc_cand_probas = self._create_accumulated_probas(cand_proba)

        ix_mapper = self._generate_mapper(self.n_levels, len(self.cube_proba))

        return list({self._select_candidate_by_proba(acc_cube_probas, ix_mapper, acc_cand_probas)
                     for _ in range(n_approvals)})

    @staticmethod
    def _weight_func2proba_func(weight_func, item_count):
        weights = [weight_func(ix) for ix in range(item_count)]
        return np.divide(weights, np.sum(weights))

    @staticmethod
    def _choose_ix_by_proba(acc_probas):
        rnd = random.random()
        for i, value in enumerate(acc_probas):
            if rnd <= value:
                return i
        return len(acc_probas) - 1

    @staticmethod
    def _create_accumulated_probas(proba_profile: List[float]) -> List[float]:
        acc = [proba_profile[0]]
        for cell in proba_profile[1:]:
            acc.append(acc[-1] + cell)
        acc[-1] = 1.0
        return acc

    def _select_candidate_by_proba(self,
                                   acc_cube_probas: List[float], ixMapper,
                                   acc_cand_probas: List[float]):
        preference_index_per_level = [self._choose_ix_by_proba(acc_cube_probas) for _ in range(ixMapper.n_levels)]
        final_square_ix_per_level = ixMapper.pref_ix2square_ix(preference_index_per_level)
        area_candidate_ix = self._choose_ix_by_proba(acc_cand_probas)
        return "_".join([str(x) for x in final_square_ix_per_level]) + f"c{area_candidate_ix}"

    @staticmethod
    def _generate_mapper(n_levels: int, count_per_level: int):
        values = list(range(count_per_level))
        random.shuffle(values)

        if n_levels == 1:
            return VoterPrefMapperLeaf(values)
        else:
            return VoterPrefMapperNode(
                values,
                [VoterApprovalsGenerator._generate_mapper(
                    n_levels - 1,
                    count_per_level) for _ in range(count_per_level)],
                n_levels
            )


class VoterPrefMapper:
    def __init__(self, n_levels):
        self.n_levels = n_levels

    def pref_ix2square_ix(self, ix_per_level: List[int]) -> List[int]:
        raise NotImplementedError()


class VoterPrefMapperLeaf(VoterPrefMapper):
    def __init__(self, values: List[int]):
        super().__init__(1)
        self.values = values

    def pref_ix2square_ix(self, ix_per_level: List[int]) -> List[int]:
        assert len(ix_per_level) == 1
        return [self.values[ix_per_level[0]]]

    def __repr__(self):
        return repr(self.values)


class VoterPrefMapperNode(VoterPrefMapper):
    def __init__(self, ix_map, mappers, n_levels):
        """
        Maps/Translates cube_proba indexes for a single level using `ix_map` and delegates the remaining levels to
        `mappers`
        :param ix_map:
        :param mappers:
        :param n_levels:
        """
        super().__init__(n_levels)
        self.ix_map = ix_map
        self.mappers = mappers

    def pref_ix2square_ix(self, ix_per_level: List[int]) -> List[int]:
        """
        :param ix_per_level:
        :return:
        """
        requested_ix = ix_per_level[0]
        mapped_ix = self.ix_map[requested_ix]
        return [mapped_ix] + self.mappers[mapped_ix].pref_ix2square_ix(ix_per_level[1:])

    def __repr__(self):
        return "\n".join((repr(mapper) for mapper in self.mappers))


class ElectionData:

    def __init__(self, product_df, order_df, order_products_df):
        self.order_products_df = order_products_df
        self.order_df = order_df
        self.product_df = product_df
        self.aisle_df = pd.DataFrame([(1, 'default aisle')], columns='aisle_id,aisle'.split(','))
        self.department_df = pd.DataFrame([(1, 'default department')], columns='department_id,department'.split(','))

    # data interface

    def read_df_products(self):
        return self.product_df

    def read_df_orders(self):
        return self.order_df

    def read_df_order_products__all(self):
        return self.order_products_df

    def read_df_departments(self):
        return self.department_df

    def read_df_aisles(self):
        return self.aisle_df
