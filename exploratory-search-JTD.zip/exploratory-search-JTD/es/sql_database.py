import sqlite3
import time

import pandas as pd
from IPython.core.display import display


class Database:
    """
    Stores dataframes as tables in an in-memory SQLite.
    Run `query` to execute sql.
    """

    def __init__(self, filename=":memory:"):
        conn = sqlite3.connect(filename)
        self.conn = conn

    def add_replace_table(self, df, tablename, index_columns=None, if_exists='replace', verbose=0):
        """
        :param if_exists: {'fail', 'replace', 'append'}
        :param index_columns: ['product_id', 'product_id,order_id'...]
        :return:
        """
        if verbose > 0:
            print(f"adding table: {tablename}")
        if len(df) == 0:
            raise Exception(f"Creating empty tables is not supported: {tablename}")
        df.to_sql(tablename, self.conn, if_exists=if_exists, index=False)

        self.add_indices(tablename, index_columns, verbose)

    def add_indices(self, table_name, index_columns, verbose=0):
        """

        :param table_name:
        :param index_columns:
        """
        if verbose > 0:
            print(f"adding indices: {index_columns} to {table_name}")

        index_columns = index_columns if index_columns is not None else []
        for cols in index_columns:
            ix_name = "ix_" + cols.replace(',', '_').replace(' ', '')
            self.exec(f"CREATE INDEX if not exists {ix_name} ON {table_name}({cols})")

    def commit(self):
        self.exec("commit")

    def get_tables(self):
        return self.query("SELECT name FROM sqlite_master WHERE type = 'table'").name.tolist()

    def query(self, query):
        # print(query)
        return pd.read_sql_query(query, self.conn)

    def schema_show(self):
        df = self.query("select * from sqlite_schema where type='table'")
        print("SCHEMA:")
        for table, sql in zip(df.name.tolist(), df.sql.tolist()):
            print(sql
                  .replace('\n', ' ').replace('   ', ' ').replace(" INTEGER", ":int")
                  .replace('"', '').replace('CREATE TABLE ', '- ').replace(' TEXT', ':text'),
                  "    | indices =",
                  self.query(f"select * from sqlite_schema where type='index' and tbl_name='{table}'").name.tolist()
                  )

    def query_show(self, query):
        start = time.time()
        df = self.query(query)
        elapsed = time.time() - start
        print('---')
        print('> ', query)
        display(df)
        print(f'elapsed: {elapsed:.3f} (sec)')
        return df

    def exec(self, query):
        # print(query)
        self.conn.cursor().execute(query)

    def load_frames(self, iframes, verbose=1):
        for table in self.get_tables():
            self.exec(f"DROP TABLE {table}")

        print('Loading dfs to sqlite')
        self.add_replace_table(iframes.df_order_products, 'order_product',
                               index_columns=['order_id,product_id', 'order_id', 'product_id'],
                               verbose=verbose)
        self.add_replace_table(iframes.df_products, 'product', index_columns=['product_id'],
                               verbose=verbose)
        self.exec(
            f"create table product_count as select product_id, count(*) order_count from order_product group by product_id")
        self.add_indices('product_count', ['product_id'], verbose=verbose)

        print(self.get_tables())

    @staticmethod
    def ints2sql_in_expr(ints):
        return f"({','.join([str(i) for i in ints])})"
