import math
import os

import bokeh as bk
import numpy as np
import pandas as pd
from IPython.core.display import display
from bokeh.layouts import row
from bokeh.plotting import figure, show
from bokeh.transform import log_cmap

from es.data.synthetic_data_cube import SyntheticDataCubeBuilder
from es.diversity_metrics import compute_rule_diversities
from es.elections import InstacartDataFrames
from es.runner.scenario_runner import ScenarioRunner
from utils import unique


def show_compare_ranks(model_params, exp_folder, plot_side=200, visual_params=None, legend_fraction=.3,
                       figsize=(25, 8)):
    print(model_params)

    results_df = ScenarioRunner.get_results_df(exp_folder)

    def calc_unique_id(col):
        id2comp_rank = {}
        for id in results_df[col]:
            if not id2comp_rank:
                id2comp_rank[id] = 1
            if id not in id2comp_rank:
                id2comp_rank[id] = max(id2comp_rank.values()) + 1

            yield id2comp_rank[id]

    results_df['winner'] = list(calc_unique_id('product_name'))
    results_df['scorer'] = results_df.run_name.apply(lambda x: x.split("ut_scorer=")[1])
    # display(results_df)
    import seaborn as sns
    # col='run_name', style="run_name",
    n_scorers = len(set(results_df.scorer))
    markers = ['o', 's', 'P', 'v', '^', '>', '<']
    # sns.set_theme(style="ticks", color_codes=True)
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(nrows=1, ncols=n_scorers, figsize=figsize)
    for ax_index, scorer in enumerate(set(results_df.scorer.tolist())):
        ax = axs[ax_index]
        g = sns.pointplot(x="rule", y="rank",
                          hue='product_name',  # hue_norm=(0, 1),
                          # style="scorer", dashes=False, markers=(markers * n_scorers)[:n_scorers],
                          # kind="point", col='scorer',
                          # palette={"male": "g", "female": "m"},
                          # markers=[f"${i}$" for i in range(100)]*100, scale=1.5,
                          # linestyles=["-", "--"],
                          data=results_df.query('scorer==@scorer'),
                          ax=ax)
        ax.invert_yaxis()
        box = g.get_position()
        g.set_position([box.x0, box.y0, box.width * (1 - legend_fraction), box.height])  # resize position
        g.set_title(f"scorer={scorer}")

        # Put a legend to the right side
        g.legend(loc='upper left', bbox_to_anchor=(1.0, 1.0), ncol=1, markerfirst=True)


def show_cube_grid(view_model, model_params, exp_folder, plot_side=200, max_div_value=100, verbose=0,
                   visual_params=None):
    print(model_params)
    import os

    div_metrics_name2acro = dict()
    figures_layout = []
    for filename in os.listdir(exp_folder):
        if not filename.startswith('exp') or '_TFIDF.tsv' in filename:
            continue

        results_df = pd.read_csv(os.path.join(exp_folder, filename))

        def product_name2item_name(x):
            squares, candidate = x.split('c')
            candidate = str(int(candidate) + 1)
            levels = [str(int(i) + 1) for i in squares.split("_")]
            levels = '-'.join(levels)
            return f"{levels}.{candidate}"

        results_df['item_name'] = results_df.product_name.apply(product_name2item_name)

        found_df_sorted = pd.read_csv(ScenarioRunner.get_tfidf_path(os.path.join(exp_folder, filename)), sep='\t')
        found_df_sorted['rank'] = range(len(found_df_sorted))

        # if verbose>=1:
        # display(found_df_sorted)
        # display(results_df)
        print("====================================")
        print(filename)

        for run_ix, run_name in enumerate(results_df.run_name.unique()):
            print(f"({run_ix})", run_name)
            rules = results_df.query('run_name==@run_name and rank==1').rule.to_list()
            print(rules)
            figures = [view_model.cube_figure(results_df, found_df_sorted, run_ix, run_name, rule, model_params,
                                              plot_side=plot_side, visual_params=visual_params) for rule in rules]
            figures_layout.append(figures)

            def acronym_func(name):
                acro = "".join(x[0] for x in name.split(' '))
                div_metrics_name2acro[name] = acro
                return acro

            print(results_df)
            print('rules', rules)
            rule2diversity = {
                rule: [(acronym_func(name), value) for name, value in
                       compute_rule_diversities(results_df, found_df_sorted, run_name, rule)]
                for rule in rules
            }
            div_figures = [
                _diversity_figure(rule2diversity[rule], plot_side=plot_side, plot_height=100, max_value=max_div_value)
                for rule in rules
            ]
            figures_layout.append(div_figures)

    print(f'diversity metrics: ', " ".join(f"({acro}): {name}" for name, acro in div_metrics_name2acro.items()))

    layout = bk.layouts.gridplot(figures_layout, merge_tools=False)
    show(layout)


def _diversity_figure(diversities, plot_side=200, plot_height=100,
                      max_value=100):
    """

    :param diversities: key: Str,value: Float dict, where key - name of diversity metrics, value - the float value of the metric
    :return:
    """
    from bokeh.models import ColumnDataSource, LabelSet
    source = ColumnDataSource(data=dict(
        div_metrics=[key for key, _ in diversities],
        div_metric_values=[value for _, value in diversities]
    ))

    p = figure(x_range=source.data['div_metrics'],
               plot_height=plot_height,
               plot_width=plot_side,
               y_range=(0, max_value),
               #                title=f"{rule} ({run_ix})",
               )
    p.vbar(x='div_metrics', top='div_metric_values', width=0.9, alpha=0.6, source=source)

    labels = LabelSet(x='div_metrics', y='div_metric_values', text='div_metric_values', level='glyph',
                      x_offset=-5, y_offset=0, source=source, render_mode='canvas', text_alpha=.6)

    p.xgrid.grid_line_color = None
    p.toolbar.logo = None
    p.toolbar_location = None
    p.yaxis.visible = False

    p.add_layout(labels)

    return p


class RankSquareViewModel:

    def cube_figure(self, results_df, found_df_sorted, run_ix, run_name, rule, model_params,
                    plot_side=200):
        side2d_size = int(pow(len(found_df_sorted), .5)) + 1

        df = results_df.query('run_name==@run_name and rule==@rule')

        def id2coord(id):
            rank = found_df_sorted.query("product_id==@id")['rank'].to_list()[0]
            coord = (int(rank / side2d_size), rank % side2d_size)
            # print(f"converted {id} of tfidf rank {rank} to coord {coord}")
            return coord

        df['x'] = df['product_id'].apply(lambda x: id2coord(x)[0])
        df['y'] = df['product_id'].apply(lambda x: id2coord(x)[1])
        #     display(df)
        TOOLS = "box_zoom,pan,reset"
        TOOLTIPS = [
            # ("product: rank", "@product_name @rank"),
            ("", "@product_name"),
        ]
        palette = bk.palettes.Viridis[256]
        # palette.reverse()
        mapper = log_cmap('rank', palette, 1, model_params.k)
        p = figure(tooltips=TOOLTIPS, tools=TOOLS, active_drag='box_zoom',
                   plot_width=plot_side, plot_height=int(plot_side),
                   min_border=0, min_border_left=0,
                   toolbar_location="above",
                   title=f"{rule} ({run_ix})",
                   x_range=(0, side2d_size),
                   y_range=(side2d_size, 0),
                   )

        p.rect(x='y', y='x',
               width=1, height=1, color=mapper, alpha=.6, source=df)

        # p.rect(x='y', y='x',
        #        width=.4, height=.4, color='white', alpha=1, source=found_df_sorted[1:2 * model_params.k])
        # greys_mapper = log_cmap('rank', bk.palettes.Blues[256], 1, 2 * model_params.k)
        # p.rect(x='y', y='x',
        #        width=.2, height=.2, color=greys_mapper, alpha=1, source=found_df_sorted[1:2 * model_params.k])

        p.axis.visible = False
        p.grid.visible = False
        p.toolbar.logo = None
        p.toolbar_location = None
        return p


def visual_isset(x, visual_params):
    return x in visual_params and visual_params[x]


class SyntCubeViewModel:

    def cube_figure(self, results_df, found_df_sorted, run_ix, run_name, rule, model_params,
                    visual_params=None, plot_side=200):
        if visual_params is None:
            visual_params = dict()

        SyntCubeViewModel.df_enrich_with_xy(results_df, model_params)
        SyntCubeViewModel.df_enrich_with_xy(found_df_sorted, model_params)

        df = results_df.query('run_name==@run_name and rule==@rule')
        #     display(df)
        TOOLS = "box_zoom,pan,reset"
        TOOLTIPS = [
            # ("product: rank", "@product_name @rank"),
            ("", "@item_name"),
        ]

        if visual_isset('ignore_ranks', visual_params):
            palette = ['black'] * model_params.k
        else:
            palette = bk.palettes.Viridis[256]
            # palette.reverse()

        mapper = log_cmap('rank', palette, 1, model_params.k)

        side2d_size = pow(model_params.cube_size, model_params.n_levels) * model_params.cand_size
        p = figure(tooltips=TOOLTIPS, tools=TOOLS, active_drag='box_zoom',
                   plot_width=plot_side, plot_height=int(plot_side),
                   min_border=0, min_border_left=0,
                   toolbar_location="above",
                   title=f"{rule} ({run_ix})",
                   x_range=(0, side2d_size),
                   y_range=(side2d_size, 0),
                   )

        p.rect(x='y', y='x',
               width=1, height=1, color=mapper, alpha=.6, source=df)

        if visual_isset('show_tfidf_dots', visual_params):
            p.rect(x='y', y='x',
                   width=.4, height=.4, color='white', alpha=1, source=found_df_sorted[1:2 * model_params.k])
            greys_mapper = log_cmap('rank', bk.palettes.Blues[256], 1, 2 * model_params.k)
            p.rect(x='y', y='x',
                   width=.2, height=.2, color=greys_mapper, alpha=1, source=found_df_sorted[1:2 * model_params.k])

        level_width = lambda col: .4 if col % (model_params.cand_size * model_params.cube_size) == 0 else .2
        for x in range(model_params.cand_size, side2d_size, model_params.cand_size):
            p.line([x, x], [0, side2d_size], width=level_width(x))

        for y in range(model_params.cand_size, side2d_size, model_params.cand_size):
            p.line([0, side2d_size], [y, y], width=level_width(y))

        # p.background_fill_color = "#eeeeee"
        p.axis.visible = False
        p.grid.visible = False
        p.toolbar.logo = None
        p.toolbar_location = None
        return p

    @staticmethod
    def _product2d_coord(name, cube_size, cand_size):
        levels, cand = tuple(name.split('c'))
        levels = [int(level) for level in levels.split('_')]
        cand = int(cand)
        cand2d = (math.floor(cand / cand_size), cand % cand_size)
        levels2d = [(math.floor(level / cube_size), level % cube_size) for level in levels]
        x, y = cand2d
        mult = cand_size
        for lx, ly in reversed(levels2d):
            x, y = x + lx * mult, y + ly * mult
            mult *= cube_size
        return x, y

    @staticmethod
    def df_enrich_with_xy(df, model_params):
        name2coord = lambda x, ix: 0.5 + SyntCubeViewModel._product2d_coord(x, model_params.cube_size,
                                                                            model_params.cand_size)[ix]
        df['x'] = df['product_name'].apply(lambda x: name2coord(x, 0))
        df['y'] = df['product_name'].apply(lambda x: name2coord(x, 1))


class SpectrumViewModel:

    def cube_figure(self, results_df, found_df_sorted, run_ix, run_name, rule, model_params,
                    plot_side=200, plot_height=50, max_rank=None):
        if not max_rank:
            max_rank = len(found_df_sorted)

        df = results_df.query('run_name==@run_name and rule==@rule')

        def id2coord(id):
            rank = found_df_sorted.query("product_id==@id")['rank'].to_list()[0]
            return rank

        df['x'] = df['product_id'].apply(lambda x: id2coord(x))
        #     display(df)
        TOOLS = "box_zoom,pan,reset"
        TOOLTIPS = [
            ("product: rank", "@product_name @rank"),
        ]
        # palette = bk.palettes.Viridis[256]
        # palette = bk.palettes.Cividis[256]
        palette = bk.palettes.Greys[256]
        # palette.reverse()
        mapper = log_cmap('rank', palette, 1, model_params.k)
        p = figure(tooltips=TOOLTIPS, tools=TOOLS, active_drag='box_zoom',
                   plot_width=plot_side, plot_height=plot_height,
                   min_border=0, min_border_left=0,
                   toolbar_location="above",
                   title=f"{rule} ({run_ix})",
                   x_range=(0, max_rank),
                   y_range=(0, plot_height),
                   )

        p.rect(x='x', y=0,
               width=1, height=plot_height * 2, color='black', alpha=.6, source=df)

        p.axis.visible = False
        p.grid.visible = False
        p.toolbar.logo = None
        p.toolbar_location = None
        return p


def show_spectrum_grid(view_model, model_params, exp_folder, plot_side=200, plot_height=50, max_div_value=100,
                       verbose=0):
    print(model_params)

    div_metrics_name2acro = dict()
    figures_layout = []
    for filename in os.listdir(exp_folder):
        if not filename.startswith('exp') or '_TFIDF.tsv' in filename:
            continue

        print("====================================")
        print(f"{exp_folder}/{filename}")

        results_df = pd.read_csv(os.path.join(exp_folder, filename))

        found_df_sorted = pd.read_csv(ScenarioRunner.get_tfidf_path(os.path.join(exp_folder, filename)), sep='\t')
        found_df_sorted['rank'] = range(len(found_df_sorted))

        if verbose >= 1:
            display(found_df_sorted)
            display(results_df)

        max_div_value = 0
        for run_ix, run_name in enumerate(results_df.run_name.unique()):
            rules = results_df.query('run_name==@run_name and rank==1').rule.to_list()
            max_div_value = max(max_div_value,
                                max(value
                                    for rule in rules
                                    for name, value in
                                    compute_rule_diversities(results_df, found_df_sorted, run_name, rule)
                                    ))

        for run_ix, run_name in enumerate(results_df.run_name.unique()):
            print(f"({run_ix})", run_name)
            rules = results_df.query('run_name==@run_name and rank==1').rule.to_list()
            figures = [view_model.cube_figure(results_df, found_df_sorted, run_ix, run_name, rule, model_params,
                                              plot_side=plot_side, plot_height=plot_height) for rule in rules]
            figures_layout.append(figures)

            def acronym_func(name):
                acro = "".join(x[0] for x in name.split(' '))
                div_metrics_name2acro[name] = acro
                return acro

            rule2diversity = {
                rule: [(acronym_func(name), value) for name, value in
                       compute_rule_diversities(results_df, found_df_sorted, run_name, rule)]
                for rule in rules
            }
            div_figures = [
                _spectrum_diversity_figure(rule2diversity[rule], plot_side=50, plot_height=plot_height,
                                           max_value=max_div_value)
                for rule in rules
            ]
            figures_layout.append(div_figures)

    print(f'diversity metrics: ', " ".join(f"({acro}): {name}" for name, acro in div_metrics_name2acro.items()))

    figures_layout = np.transpose(figures_layout).tolist()
    layout = bk.layouts.gridplot(figures_layout, merge_tools=False)
    show(layout)


def _spectrum_diversity_figure(diversities, plot_side=200, plot_height=100,
                               max_value=100):
    """

    :param diversities: key: Str,value: Float dict, where key - name of diversity metrics, value - the float value of the metric
    :return:
    """
    from bokeh.models import ColumnDataSource
    source = ColumnDataSource(data=dict(
        div_metrics=[key for key, _ in diversities],
        div_metric_values=[value for _, value in diversities]
    ))

    p = figure(y_range=source.data['div_metrics'],
               plot_height=plot_height,
               plot_width=plot_side,
               x_range=(0, max_value),
               #                title=f"{rule} ({run_ix})",
               )
    p.hbar(y='div_metrics', right='div_metric_values', height=1, alpha=0.3, source=source)

    # labels = LabelSet(x='div_metrics', y=0, text='div_metric_values', level='glyph',
    #                   x_offset=0, y_offset=10, source=source, render_mode='canvas', text_alpha=1.0,
    #                   text_font_size="5pt")
    # p.add_layout(labels)

    # p.grid.grid_line_color = None
    p.toolbar.logo = None
    p.toolbar_location = None
    p.axis.visible = False
    p.grid.visible = False

    return p


def show_cross_rank_grid(view_model, model_params, exp_folder, plot_side=200, plot_height=50, max_div_value=100,
                         verbose=0):
    print(model_params)
    import os

    div_metrics_name2acro = dict()
    figures_layout = []
    for filename in os.listdir(exp_folder):
        if not filename.startswith('exp') or '_TFIDF.tsv' in filename:
            continue

        results_df = pd.read_csv(os.path.join(exp_folder, filename))

        found_df_sorted = pd.read_csv(ScenarioRunner.get_tfidf_path(os.path.join(exp_folder, filename)), sep='\t')
        found_df_sorted['rank'] = range(len(found_df_sorted))

        # if verbose>=1:
        # display(found_df_sorted)
        # display(results_df)
        print("====================================")
        print(filename)

        for run_ix, run_name in enumerate(results_df.run_name.unique()):
            print(f"({run_ix})", run_name)
            rules = results_df.query('run_name==@run_name and rank==1').rule.to_list()
            figures = view_model.cube_figure(results_df, found_df_sorted, run_ix, run_name, rules, model_params,
                                             plot_side=plot_side, plot_height=plot_height)
            figures_layout.append(figures)

    # figures_layout = np.transpose(figures_layout).tolist()
    layout = bk.layouts.gridplot(figures_layout, merge_tools=False)
    show(layout)


class CrossRankViewModel:

    def cube_figure(self, results_df, found_df_sorted, run_ix, run_name, rules, model_params,
                    plot_side=200, plot_height=50, max_rank=None):
        if not max_rank:
            max_rank = len(found_df_sorted)

        TOOLS = "box_zoom,pan,reset"
        TOOLTIPS = [
            ("product: rank", "@product_name @rank"),
        ]
        palette = bk.palettes.Viridis[256]
        # palette = bk.palettes.Cividis[256]
        # palette = bk.palettes.Greys[256]
        # palette.reverse()
        mapper = log_cmap('rank', palette, 1, model_params.k)
        p = figure(tooltips=TOOLTIPS, tools=TOOLS, active_drag='box_zoom',
                   plot_width=plot_side, plot_height=model_params.k * 10,
                   min_border=0, min_border_left=0,
                   toolbar_location="above",
                   title=f"({run_ix})",
                   x_range=(0, max_rank),
                   y_range=(0, model_params.k),
                   )

        colors = ['red', 'green', 'blue', 'orange', 'grey']
        for color, rule in zip(colors, rules):
            df = results_df.query('run_name==@run_name and rule==@rule')

            def id2coord(id):
                rank = found_df_sorted.query("product_id==@id")['rank'].to_list()[0]
                return rank

            df['tfidfrank'] = df['product_id'].apply(lambda x: id2coord(x))
            #     display(df)

            # print(df[['tfidfrank', 'rank']])
            # p.rect(x='tfidfrank', y='rank',
            #        width=1, height=1, color=mapper, alpha=.6, source=df)
            p.circle(x='tfidfrank', y='rank',
                     size=5, color=color, alpha=.6, source=df, legend_label=rule)

        p.axis.visible = True
        p.grid.visible = False
        p.toolbar.logo = None
        p.toolbar_location = None

        # p.legend.location = "bottom_right"
        # p.legend.label_text_font_size = '5pt'
        # p.legend.click_policy = "hide"

        return [p]


class MultiRunner:
    def __init__(self, model_params):
        self.model_params = model_params

    def run_show(self, iterations, seed=13, out_folder=None):
        results_df = self.run(iterations, seed)
        self.show(results_df, out_folder)
        return results_df

    def run(self, iterations, seed=13, verbose=0, include_unity=False, min_popularity=20):
        print(f"Running {iterations} iterations")
        iter_results_dfs = []
        P = self.model_params
        exp_name = P.exp_name
        for iteration in range(iterations):
            #     P.exp_name = f"{exp_name}_{iteration}"
            print(f"generating data, iteration {iteration}")
            idata = SyntheticDataCubeBuilder(cube_size=P.cube_size,
                                             n_levels=P.n_levels,
                                             n_candidates_per_area=P.cand_size * P.cand_size,
                                             cube_proba=P.cube_proba,
                                             #                                 cand_weight_func=lambda cand_ix: 5 - cand_ix,
                                             cand_weight_func=eval(P.cand_weight_func),
                                             n_voters=P.n_voters,
                                             n_approvals_per_voter_func=lambda: P.n_approvals_per_voter,
                                             verbose=0,
                                             seed=seed + iteration).build()

            iframes = InstacartDataFrames.from_data(idata, verbose=0, min_popularity=min_popularity)

            runner = ScenarioRunner(iframes, P)
            results_df = runner.run(verbose=verbose, return_df=True, include_unity=include_unity)
            results_df['iteration'] = iteration
            iter_results_dfs.append(results_df)
            if verbose > 0:
                print(results_df)
        return pd.concat(iter_results_dfs, ignore_index=True)

    def show(self, full_df, color_max=1000, out_folder=None):
        import matplotlib.pyplot as plt
        import seaborn as sns
        sns.set_theme()
        full_df = full_df.copy()

        full_df['smallcube'] = full_df.product_name.apply(lambda x: x[:3])
        full_df['bigcube'] = full_df.product_name.apply(lambda x: x[:1])

        def cube_stats4rule(rule):
            count_00 = full_df.query(f"smallcube=='0_0' and rule=='{rule}'").product_id.count()
            count_0 = full_df.query(f"bigcube=='0' and rule=='{rule}'").product_id.count()
            count_full = full_df.query(f"rule=='{rule}'").product_id.count()
            return dict(rule=rule, count_11=count_00, count_1rest=count_0 - count_00, count_rest=count_full - count_0)

        P = self.model_params

        full_df['product_name'] = full_df.product_name.apply(lambda x: x.split('c')[0] + 'c0')
        SyntCubeViewModel.df_enrich_with_xy(full_df, model_params=P)
        full_df.sort_values('x')

        rules = unique(full_df.rule.tolist())
        run_names = unique(full_df.run_name.tolist())
        size_x = len(rules) * 4
        size_y = len(run_names) * 5
        f, axs = plt.subplots(figsize=(size_x, size_y), nrows=len(run_names), ncols=len(rules), squeeze=False)
        nx = P.cube_size ** P.n_levels

        cube_stats_df = pd.DataFrame([cube_stats4rule(rule) for rule in sorted(rules)])
        display(cube_stats_df)

        if out_folder is not None:
            cube_stats_filename = f"{out_folder}/cube_stats.csv"
            print(f"Saving cube_stats to {cube_stats_filename}")
            cube_stats_df.to_csv(cube_stats_filename)

        for row, run_name in enumerate(run_names):
            print(f"({row})", run_name)
            for col, rule in enumerate(rules):
                df = full_df.query("rule==@rule and run_name==@run_name").groupby(['x', 'y'], as_index=False).count()
                df['x'] = (df.x - .5) / P.cand_size
                df['y'] = (df.y - .5) / P.cand_size

                df['cnt'] = df.steps
                df = df[['x', 'y', 'cnt']]
                cells_present = {(t.x, t.y) for t in df.itertuples()}
                cells_all = {(x, y) for x in range(nx) for y in range(nx)}
                cells_missing = cells_all - cells_present
                missing_df = pd.DataFrame((dict(x=x, y=y, cnt=0) for x, y in cells_missing))
                df = pd.concat([df, missing_df])
                df.cnt = df.cnt.replace(0, np.nan)
                pivot = df.pivot('x', 'y', 'cnt')
                cmap = sns.color_palette("Greys", as_cmap=True)
                from matplotlib.colors import LogNorm

                plt.rcParams.update({'font.size': 12})
                cur_ax = axs[row][col]
                p = sns.heatmap(pivot, norm=LogNorm(vmax=1000, vmin=1), annot=True, fmt=".0f", linewidths=.5,
                                ax=cur_ax, cmap=cmap, xticklabels=False, yticklabels=False,
                                cbar=False, square=True)
                p.set(xlabel=None, ylabel=None, title=f"{rule} ({row})")

                f = plt.figure(figsize=(4, 4), frameon=False, tight_layout=dict(pad=0, w_pad=0, h_pad=0))

                plt.rcParams.update({'font.size': 20})
                p = sns.heatmap(pivot, norm=LogNorm(vmax=1000, vmin=1), annot=True, fmt=".0f", linewidths=.5,
                                cmap=cmap, xticklabels=False, yticklabels=False,
                                cbar=False, square=True)
                p.set(xlabel=None, ylabel=None, title=None)

                if out_folder is not None:
                    filename = f"{out_folder}/msynth-{rule}.png"
                    print(f"saving results to: {filename}")
                    f.savefig(filename)
