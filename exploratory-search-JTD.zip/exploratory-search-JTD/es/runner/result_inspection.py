import io
import os


class ResultsInspectorBase():
    def __init__(self):
        self.experiment_folder = '<unset>'

    def visit_results(self, searchterm, filtered_elections, mp, results_dict, election_results_list):
        raise NotImplementedError()


class ResultsInspectorDummy(ResultsInspectorBase):
    def visit_results(self, searchterm, filtered_elections, mp, results_dict, election_results_list):
        pass


class ResultsInspectorSaveCommitteeScores(ResultsInspectorBase):
    def __init__(self, filepath):
        super().__init__()
        self.filepath = filepath
        self.output_path = None

    def visit_results(self, searchterm, filtered_elections, mp, results_dict, election_results_list):
        if not self.output_path:
            self.output_path = f"{self.experiment_folder}/{self.filepath}"

        if not os.path.exists(self.output_path):
            with open(self.output_path, "w+") as f:
                f.write(
                    f"search_term"
                    f"\t"
                    f"rule"
                    f"\t"
                    f"committee_size"
                    f"\t"
                    f"committee_score"
                    f"\t"
                    f"utility_scorer"
                    f"\t"
                    f"PARAMS"
                    f"\n"
                )

        with open(self.output_path, 'a+') as f:
            for rule, results in election_results_list.items():
                f.write(
                    f"{searchterm}"
                    f"\t"
                    f"{rule}"
                    f"\t"
                    f"{mp.k}"
                    f"\t"
                    f"{results.committee_score}"
                    f"\t"
                    f"{filtered_elections.utility_scorer}"
                    f"\t"
                    f"{mp}"
                    f"\n"
                )
