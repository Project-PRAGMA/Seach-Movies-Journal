import os
from random import random

import pandas as pd
from IPython.core.display import display

import utils
from es.elections import Elections
from es.electionutils import ElectionUtils
from es.scorers import CachingScorer, BatchedUtilityScorer, AgentSpreadScoringStrategy
from es.similarity import IdentitySimilarity
from es.utils import filter_abc_rules
from es.runner.result_inspection import ResultsInspectorDummy


class ScenarioRunner:
    """
    Runs elections in various scenarios of inputs
    """

    def __init__(self, iframes, model_params, results_inspector=ResultsInspectorDummy(), seed=None):

        self.results_inspector = results_inspector
        self.model_params = model_params
        self.filtering = model_params.filtering if 'filtering' in model_params else {}
        self.throw_on_rerun = self.model_params.throw_on_rerun if 'throw_on_rerun' in self.model_params else True

        if 'genres_filter' in self.filtering:
            iframes.onlyGenres(genres=self.filtering['genres_filter'])

        if 'drop_freq_rel' in self.filtering:
            iframes.drop_most_frequent(drop_relative=self.filtering['drop_freq_rel'],
                                       drop_n=self.filtering['drop_freq_n'])

        if 'sample_orders' in self.filtering:
            sample_products = self.filtering['sample_products'] if 'sample_products' in self.filtering else None
            iframes.sample(n_orders=self.filtering['sample_orders'], n_products=sample_products, inplace=True,
                           random_state=seed)

        self.utils = ElectionUtils(iframes)
        self.elections = Elections.from_instacart_frames(iframes)
        if iframes.verbose > 0:
            print(
                f'loaded {len(iframes.df_products)} products and '
                f'{len(iframes.df_orders)} orders, ({len(iframes.df_order_products)} ops)')
        self.iframes = iframes
        self.IDF_1 = self.elections.create_idf_map_1()
        # IDF_SMOOTH = elections.create_idf_map_smooth()
        # IDF_2toSMOOTH = elections.create_idf_map_2tosmooth()
        # IDF_3toSMOOTH = elections.create_idf_map_xtosmooth(3)
        # IDF_4toSMOOTH = elections.create_idf_map_xtosmooth(4)

    def create_scorer(self, metric, found_df_nosearchterm, scoring_strategy):
        return CachingScorer(BatchedUtilityScorer(
            found_df_no_search_ids=found_df_nosearchterm,
            metric=metric,
            ascending=False,
            scoring_strategy=scoring_strategy,
            approval_set_func=self.utils.instacart_frames.get_product_ids_for_order))

    def run(self, verbose=1, return_df=False, output_base_folder='results', include_unity=True, seed=None):
        """

        :param verbose:
        :param return_df: if True - nothing is saved to disk
        :return:
        """
        mp = self.model_params

        from datetime import datetime
        exp_folder = f'{output_base_folder}/{mp.exp_name}'
        exp_timestamp = datetime.now()
        if not return_df:
            if os.path.exists(f'{output_base_folder}/tmp'):
                import shutil
                shutil.rmtree(f'{output_base_folder}/tmp')
            if os.path.exists(exp_folder):
                if self.throw_on_rerun:
                    raise Exception(f"folder exists: {exp_folder}")
                else:
                    print("WARN: appending to the results folder, which exists !!!")
            else:
                os.makedirs(exp_folder)

        from datetime import datetime
        if verbose > 0:
            print(datetime.now())

        search_term_results_df = None
        #     ARG:  =====================================
        search_term_res = utils.strings_to_res(mp.searchterms)
        for search_term in search_term_res:
            results_df = pd.DataFrame([],
                                      columns='run_name,steps,idf,product_id,product_name,rule,rulex,algo,algo_version,rank,search_term'.split(
                                          ','))
            try:
                search_df = self.utils.find_products(search_term, min_order_count=1, max_order_count=1000000)
                if len(search_df) == 0:
                    raise Exception(f"Couldn't find search term: {search_term}")
                found_df = self.utils.calc_found_df(search_df)
                found_df_sorted = found_df.sort_values(by='tfidfto2', ascending=False)
                found_df_nosearchterm = found_df[~found_df.product_id.isin(search_df.product_id)]

                if len(found_df_nosearchterm) < mp.k:
                    raise Exception(f"Found {len(found_df)} resources for: '{search_term}'. Committee of size {mp.k} can't be formed")

                found_df_sorted_nosearchterm = found_df_sorted[~found_df_sorted.product_id.isin(search_df.product_id)]
                if verbose > 0:
                    print(f'searching for: {search_term} : {search_df.product_name.tolist()}')

                #     ARG:  =====================================
                popularity_multiplier = 1.1
                #     ARG:  =====================================
                idfs_tuples = dict(
                    IDF_1=self.IDF_1,
                    #         IDF_SMOOTH=IDF_SMOOTH,
                    #         IDF_2toSMOOTH=IDF_2toSMOOTH,
                    #     ORG_IDF_SMOOTH=ORG_IDF_SMOOTH,
                    #     ORG_IDF_2toSMOOTH=ORG_IDF_2toSMOOTH,
                ).items()
                #     ARG:  =====================================
                #     rules = ['av', 'pav', 'qav_2', 'qav_3', 'ccav']
                #     rules = ['seqphragmen', 'seqcc', 'seqpav', 'seqslav', 'rule-x']
                if mp.rules:
                    rules = mp.rules
                else:
                    rules = ['av', 'pav', 'qav_2', 'qav_3', 'ccav']
                #     ARG:  =====================================
                steps_it = [1]

                #     ARG:  =====================================
                def generate_scorers():
                    if mp.scorer_metrics:
                        for metric in mp.scorer_metrics:
                            if mp.scorer_funcs is not None:
                                for func in mp.scorer_funcs:
                                    yield self.create_scorer(metric, found_df_nosearchterm,
                                                             func(found_df_sorted_nosearchterm, metric=metric))
                            else:
                                yield self.create_scorer(metric, found_df_nosearchterm,
                                                         AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm(
                                                             found_df_sorted_nosearchterm, metric=metric))

                runs = {}

                filters_str = "filtering=None"
                if self.filtering:
                    filters_str = ','.join([f'{k}={v}' for k, v in self.filtering.items() if v is not None]) \
                        .replace('[', '').replace(']', '').replace("'", '')
                results_filename = f'{exp_folder}/exp={mp.exp_name},search={search_term},win={mp.k},{filters_str}.csv'
                #     results_filename=f'{exp_folder}/{exp_name}.tsv'
                log_filename = f'{exp_folder}/all_results.log'
                all_results_filename = f'{exp_folder}/all_results.tsv'

                if not return_df:
                    if os.path.exists(results_filename):
                        print(f'INFO: Results filename exists: {results_filename}, skipping...')
                        continue

                    with open(log_filename, 'a') as f:
                        f.write(f"START - - - - - - - - - - - - - - - - - - - - - - -\n")
                        f.write(f"Run Details: {results_filename}\n")
                        f.write(f"Start Timestamp: {exp_timestamp}\n")

                for idf_name, idf in idfs_tuples:
                    for steps in steps_it:
                        #         for popularity_multiplier in [1.0, 2.0]:
                        #             for ut_name, ut in dict(filtered_set=utils, full_set=org_utils).items():
                        #             for ut_name, ut in dict(filtered_set=utils).items():
                        #         for max_ratio_in_out in [.1, .2, .3]:
                        ut_scorers = [None] if include_unity else []
                        ut_scorers += list(generate_scorers())
                        for ut_scorer in ut_scorers:
                            #             for topn in [20]:
                            #                 for topn_metric in ['tfidfto2']:
                            run_name = ';'.join([
                                f'exp_name={mp.exp_name}',
                                #                         f'steps={steps}',
                                #                         f'idf={idf_name}',
                                #                         f'cand_weight_func={cand_weight_func}',
                                f'ut_scorer={ut_scorer}',
                                #                     f'multiplier={popularity_multiplier}',
                                #                     f'dataset={ut_name}',
                                #                     f'max_ratio={max_ratio_in_out}',
                                #                         f'whitelist=topn_by_metric'
                                #                         f'topn={topn}',
                                #                         f'topn_metric={topn_metric}',
                                #                     f'assymetric: top=40/40, order_count_found'
                                #                     f'rec_winners: topn=15, order_count_found'
                            ])

                            if verbose > 0:
                                print('----------\nRUN: ' + run_name)

                            #                   /---------SEARCH/GLOBAL- elections

                            filtered_elections = self.utils.create_filtered_elections(
                                search_df, idf, similarity=None, steps=steps,
                                utility_scorer=ut_scorer,
                            )

                            #                     filtered_elections = es.elections.Elections.from_instacart_frames(utils.instacart_frames, idf, borda_scorer)
                            #                   \---------SEARCH/GLOBAL- elections

                            #                         utility_scorer=ut_scorer,\
                            #                     product_id_blacklist=rec_winners_df.product_id\
                            #                     product_id_blacklist=assymetric_blacklist_df.product_id\
                            #                         product_id_whitelist=utils.top_products(found_df, topn, topn_metric).product_id\
                            #                     product_id_blacklist=product_ids_more_popular(popularity_multiplier, ut)\
                            #                     product_id_blacklist=products_with_max_ratio(max_ratio=max_ratioInOut).product_id\

                            results_dict, election_results_list = self.utils.calc_results(
                                rules=filter_abc_rules(rules, idf_name),
                                k=mp.k,
                                filtered_elections=filtered_elections,
                                verbose=verbose,
                                run_params=mp,
                                similarity=IdentitySimilarity(),
                                seed=seed
                            )

                            self.results_inspector.experiment_folder = exp_folder

                            self.results_inspector.visit_results(search_term, filtered_elections, mp,
                                                                 results_dict, election_results_list)

                            if not return_df:
                                with open(all_results_filename, 'a') as f:
                                    for rule, election_result in election_results_list.items():
                                        for row in results_dict[rule][
                                            ['algo', 'algo_version', 'rule', 'rank', 'product_id', 'product_name']] \
                                                .itertuples():
                                            f.write(f"{search_term}")
                                            f.write('\t' + '\t'.join(
                                                (str(x) for x in list(row[1:]))))  # omitting the index (as first item)
                                            f.write(
                                                f"\t{mp.exp_name}\t{exp_timestamp}\t{results_filename}\t{run_name}\t")
                                            f.write('\n')

                                with open(log_filename, 'a') as f:
                                    f.write(f"Run Name: {run_name}\n")
                                    for rule, election_result in election_results_list.items():
                                        f.write(f"Winners ({rule}):\n{election_result.winner_ids}\n")
                                        f.write(election_result.description + '\n')
                                    f.write(f"Done Timestamp: {datetime.now()}\n")
                                    f.write(f"DONE - - -\n")

                            results_all = pd.concat(results_dict.values(), ignore_index=True)
                            results_all['steps'] = steps
                            results_all['idf'] = idf_name
                            results_all['run_name'] = run_name
                            results_all['search_term'] = search_term
                            results_df = pd.concat([results_df, results_all[results_df.columns]], ignore_index=True)
                            search_term_results_df = results_df if search_term_results_df is None \
                                else pd.concat([search_term_results_df, results_df], ignore_index=True)

                            runs[run_name] = results_all
                            if verbose >= 1:
                                print("--------------------")
                                print(f"RUN: {run_name}, search term: {search_term}")
                                display(self.utils.rules_sidebyside_df(results_all, rules, withid=True))
                                display(found_df_sorted[:mp.k])

                if not return_df:
                    results_df.to_csv(results_filename, index=False)
                    print(f'saved election results to {results_filename}')
                    tfidf_path = ScenarioRunner.get_tfidf_path(results_filename)
                    found_df_sorted.to_csv(tfidf_path, sep='\t')
                    print(f'saved tfidf results to {tfidf_path}')
            except Exception:
                import sys
                import traceback
                print(f"Error while processing {search_term}: {sys.exc_info()}")
                print(traceback.format_exc())
                # or
                print(sys.exc_info()[2])

        if return_df:
            if verbose > 0:
                print(f"Results not saved to file")

            return search_term_results_df
        else:
            print(f"Results saved to '{exp_folder}'")
            return exp_folder

    @staticmethod
    def get_tfidf_path(results_path):
        return results_path[:-4] + "_TFIDF.tsv"

    @staticmethod
    def get_results_df(exp_folder):
        # there's only one, no?
        return [pd.read_csv(os.path.join(exp_folder, filename))
                for filename in os.listdir(exp_folder)
                if filename[:3] == 'exp' and filename[-4:] == '.csv'][0]

    @staticmethod
    def load_results(exp_folder):
        results_df = None
        found_df_sorted = None
        for filename in os.listdir(exp_folder):
            if not filename.startswith('exp') or '_TFIDF.tsv' in filename:
                continue

            rdf = pd.read_csv(os.path.join(exp_folder, filename))
            rdf['filename'] = filename
            results_df = pd.concat([results_df, rdf]) if results_df is not None else rdf

            fdfs = pd.read_csv(ScenarioRunner.get_tfidf_path(os.path.join(exp_folder, filename)), sep='\t')
            fdfs['rank'] = range(len(fdfs))
            fdfs['filename'] = filename
            found_df_sorted = pd.concat([found_df_sorted, fdfs]) if found_df_sorted is not None else fdfs

        return results_df, found_df_sorted
