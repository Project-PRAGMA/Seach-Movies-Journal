from typing import List, Dict

from es.OwaGreedy1 import OwaGreedy1


class OwaGreedy3(OwaGreedy1):
    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        """
        g3 - operate on sorted committees, where there's no impact of adding a new resource (to the old committee)
        """
        OwaGreedy1.__init__(self, m=m, k=k, pref_profile=pref_profile, owa_vector=owa_vector, verbose=verbose)
        self.owa_delta = [-x + y for x, y in zip(owa_vector, owa_vector[1:])]

        # NOTE: we assume homogenous utilities for a given resource, hence retrieving from voter 0
        # we default utility to 1 for empty approvals for a resource - as it won't be selected anyhow
        self.rix2voter_ut = {rix: (voters[0].approvals[rix] if len(voters) > 0 else 1)
                             for rix, voters in self.resource_ix2approving_voters.items()}

    def run(self):
        committee = []  # we use a list to make sure the order is preserved
        committee_set = set(committee)
        sorted_rixs = []  # resource indexes in utility order, descending
        sorted_ruts = []  # utilities sorted descending
        committee_score = 0
        for member_ix in range(self.k):
            max_score_delta = -1
            max_score_rix = -1
            max_score_rut = -1

            for rix in range(self.m):
                rut = self.rix2voter_ut[rix]
                if rix not in committee_set:
                    score_delta = self.score_de(sorted_rixs, rix, rut)
                    if score_delta > max_score_delta:
                        max_score_rix, max_score_rut, max_score_delta = rix, rut, score_delta

            if max_score_rix == -1:
                raise Exception(f"Failed to find candidate number: #{member_ix}")
            else:
                committee.append(max_score_rix);
                committee_set = set(committee)
                committee_score += max_score_delta

                insert_ix = next(
                    (ix for ix, ut in enumerate(sorted_ruts) if ut < max_score_rut),
                    len(sorted_ruts))
                sorted_rixs.insert(insert_ix, max_score_rix)
                sorted_ruts.insert(insert_ix, max_score_rut)

            if self.verbose > 0:
                print(f"added member #{member_ix}: {max_score_rix}, "
                      f"total committee score {committee_score:.3f}, "
                      f"added member delta: {max_score_delta:.3f}")
        return committee, committee_score

    def score_de(self, sorted_rixs: List[int], rix: int, rut: float):
        """
        :param sorted_rixs: list of committee member indices (resource indices) sorted by voter's utility, descending
        :param rix: resource index to find a score delta for
        :param rut: resource `rix`'s utility
        :return:
        """
        score_delta = 0
        for voter in self.get_voters_approving_resource(rix):
            utilities = [voter.approvals[cix] for cix in sorted_rixs if cix in voter.approvals]

            insert_ix = 0
            while insert_ix < len(utilities) and utilities[insert_ix] >= rut:
                insert_ix += 1

            for ix in range(insert_ix, len(utilities)):
                score_delta += utilities[ix] * self.owa_delta[ix]

            score_delta += rut * self.owa_vector[insert_ix]

        return score_delta
