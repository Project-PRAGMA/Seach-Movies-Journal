import random

import pyximport;

from data.base_data import ParquetDFFolder

ALGO_GREEDY = 'g'
ALGO_SA = 'sa'
ALGO_ILP = 'ilp'
ALGOS = [ALGO_SA, ALGO_GREEDY, ALGO_ILP]
PROD_VERSIONS = {ALGO_GREEDY: 4, ALGO_SA: 2, ALGO_ILP: 1}
ALGO_DEFAULT = ALGO_GREEDY

pyximport.install()
import os
from collections import defaultdict

import numpy as np
import pandas as pd

# The Owa... classes are used in dynamically generated code (HINT: leave them here)

from es.OwaAnnealer0 import OwaAnnealer0
from es.OwaAnnealer1 import OwaAnnealer1
from es.OwaAnnealer2 import OwaAnnealer2
from es.OwaAnnealer2d import OwaAnnealer2d

from es.OwaGreedy0 import OwaGreedy0
from es.OwaGreedy1 import OwaGreedy1
from es.OwaGreedy2 import OwaGreedy2
from es.OwaGreedy3 import OwaGreedy3
from es.OwaGreedy3a import OwaGreedy3a
from es.OwaGreedy4 import OwaGreedy4

from es.OwaILP0 import OwaILP0
from es.OwaILP1 import OwaILP1


from es.utils import canonicalTitle


class ElectionResults:
    def __init__(self, winner_ids, description, committee_score=None):
        self.committee_score = committee_score
        self.winner_ids = winner_ids
        self.description = description


class InstacartDataFrames:
    def __init__(self, df_order_products_all, df_orders, df_products, df_departments, df_aisles, verbose=1):
        self.verbose = verbose
        self.df_order_products = df_order_products_all
        self.df_orders = df_orders
        self.df_products = df_products
        self.df_departments = df_departments
        self.df_aisles = df_aisles

    @staticmethod
    def from_data(instacart_data, verbose=1, min_popularity=20):
        if verbose > 0:
            print(f'reading instacart data')
        df_order_products = instacart_data.read_df_order_products__all()

        if min_popularity is not None:
            product_count_df = df_order_products[['product_id']].groupby(df_order_products.product_id).count()
            product_count_df.columns = ['order_count']
            popular_product_ids = product_count_df[product_count_df.order_count >= min_popularity].index
            pre_filter_count = len(df_order_products)
            df_order_products = df_order_products[df_order_products.product_id.isin(popular_product_ids)]
            if verbose > 0:
                print(
                    f'WARN: Only products with min_popularity={min_popularity} considered ({pre_filter_count - len(df_order_products)} approvals filtered from {pre_filter_count} to {len(df_order_products)})')

        return InstacartDataFrames(df_order_products, instacart_data.read_df_orders(),
                                   instacart_data.read_df_products(), instacart_data.read_df_departments(),
                                   instacart_data.read_df_aisles(), verbose=verbose)

    def to_pq(self, folder):
        if not os.path.exists(folder):
            os.mkdir(folder)
        # else:
        #     raise Exception(f'folder {folder} already exists! remove manually if you want to overwrite')
        pq_folder = ParquetDFFolder(folder, verbose=1)
        for name, df in dict(
                order_products__all=self.df_order_products,
                orders=self.df_orders,
                products=self.df_products,
                departments=self.df_departments,
                aisles=self.df_aisles
        ).items():
            pq_folder.save_df(df, name)

    def to_tsv(self, folder):
        if os.path.exists(folder):
            raise Exception(f'folder {folder} already exists! remove manually if you want to overwrite')
        os.mkdir(folder)
        for name, df in dict(
                order_products=self.df_order_products,
                orders=self.df_orders,
                products=self.df_products,
                departments=self.df_departments,
                aisles=self.df_aisles
        ).items():
            df.to_csv(InstacartDataFrames._frame_file_path(folder, name), sep='\t')

    @staticmethod
    def _frame_file_path(folder, name):
        return os.path.join(folder, name + '.tsv')

    @staticmethod
    def from_tsv(folder):
        print(f'reading frames from: {folder}')
        return InstacartDataFrames(
            df_order_products_all=pd.read_csv(InstacartDataFrames._frame_file_path(folder, 'order_products'), sep='\t'),
            df_orders=pd.read_csv(InstacartDataFrames._frame_file_path(folder, 'orders'), sep='\t'),
            df_products=pd.read_csv(InstacartDataFrames._frame_file_path(folder, 'products'), sep='\t'),
            df_departments=pd.read_csv(InstacartDataFrames._frame_file_path(folder, 'departments'), sep='\t'),
            df_aisles=pd.read_csv(InstacartDataFrames._frame_file_path(folder, 'aisles'), sep='\t'),
        )

    def perturb(self, perturbation_ratio, perturb_type, random_state=None):
        """
        :param perturbation_ratio: 0..1 ratio of perturbed votes to all votes
        :param perturb_type:
        :param random_state:
        :return:
        """

        if perturb_type == 'REMOVE':
            return InstacartDataFrames(
                df_order_products_all=self.df_order_products.sample(
                    n=int(len(self.df_order_products) * (1 - perturbation_ratio)),
                    replace=False,
                    random_state=random_state),
                df_orders=self.df_orders,
                df_products=self.df_products,
                df_aisles=self.df_aisles,
                df_departments=self.df_departments,
                verbose=self.verbose
            )
        if perturb_type == 'ADD':
            if random_state is not None:
                random.setstate(random_state)

            existing_tuples = set((a, b) for a, b in self.df_order_products.to_numpy())

            all_add_tuples = set((o, p)
                                 for o in self.df_orders.order_id.to_list()
                                 for p in self.df_products.product_id.to_list()
                                 ) - existing_tuples

            n = int(len(self.df_order_products) * perturbation_ratio)
            tuples_to_add = random.sample(all_add_tuples, n)
            new_order_products_df = pd.concat(
                [self.df_order_products, pd.DataFrame(tuples_to_add, columns=['order_id', 'product_id'])])

            return InstacartDataFrames(
                df_order_products_all=new_order_products_df,
                df_orders=self.df_orders,
                df_products=self.df_products,
                df_aisles=self.df_aisles,
                df_departments=self.df_departments,
                verbose=self.verbose
            )
        else:
            raise Exception(f"Perturbation type: '{perturb_type}' is not supported")

    def filter2products(self, product_ids, inplace=True):
        df_products = self.df_products[self.df_products.product_id.isin(product_ids)]
        df_order_products = self.df_order_products[self.df_order_products.product_id.isin(df_products.product_id)]
        df_orders = self.df_orders[self.df_orders.order_id.isin(df_order_products.order_id)]
        if inplace:
            self.df_products = df_products
            self.df_order_products = df_order_products
            self.df_orders = df_orders
            return self
        else:
            return InstacartDataFrames(df_order_products, df_orders, df_products, self.df_departments, self.df_aisles)

    # inplace is a hack
    def filterOutProducts(self, bad_product_ids, inplace=True):
        good_product_ids = self.df_products[~self.df_products.product_id.isin(bad_product_ids)].product_id
        return self.filter2products(good_product_ids, inplace)

    def drop_most_frequent(self, drop_n=None, drop_relative=None, leave_ids=None):
        if drop_n is None and drop_relative is None:
            # print('INFO: not limiting most frequent')
            pass
        else:
            drop_n = int(drop_relative * len(
                self.df_order_products.product_id.unique())) if drop_relative is not None else drop_n
            goodids = set(self.df_order_products.product_id.value_counts().index[drop_n:]).union(leave_ids)
            self.filter2products(goodids)
            if self.verbose > 0:
                print(
                    f'WARN: limited the frame with drop_n={drop_n}: to: '
                    f'{len(self.df_orders)} orders, {len(self.df_products)} products '
                    f'(and {len(self.df_order_products)} order-product tuples)')

    def sample(self, n_orders, n_products=None, random_state=None, inplace=True):
        result = self
        if n_orders is None and n_products is None:
            # print('INFO: not limiting via sampling')
            pass
        else:
            if n_orders:
                df_orders = self.df_orders.sample(n=n_orders, random_state=random_state)
                df_order_products = self.df_order_products[
                    self.df_order_products.order_id.isin(df_orders.order_id)]
                df_products = self.df_products[self.df_products.product_id.isin(df_order_products.product_id)]
            else:
                df_orders = self.df_orders
                df_products = self.df_products
                df_order_products = self.df_order_products

            if n_products and len(df_products) > n_products:
                df_products = df_products.sample(n=n_products, random_state=random_state)
                df_order_products = df_order_products[
                    df_order_products.product_id.isin(df_products.product_id) &
                    df_order_products.order_id.isin(df_orders.order_id)
                    ]
                df_orders = df_orders[df_orders.order_id.isin(df_order_products.order_id)]

            if self.verbose > 0:
                print(
                    f'WARN: limited the frame by sampling {n_orders} random orders to: {len(df_orders)} orders, '
                    f'{len(df_products)} products (and {len(df_order_products)} order-product tuples)')
                # print(df_products.product_name)
            if inplace:
                self.df_orders = df_orders
                self.df_order_products = df_order_products
                self.df_products = df_products
            else:
                result = InstacartDataFrames(df_order_products, df_orders, df_products, self.df_departments,
                                             self.df_aisles)
        return result

    def enrich_df_product(self, genres_tolist=False):
        df_genres = pd.read_csv('movie_genres.csv')
        if genres_tolist:
            df_genres = df_genres.groupby('ml_title')['genre'].apply(list).to_frame().reset_index()
        df_genres['can_title'] = canonicalTitle(df_genres.ml_title)
        self.df_products['can_title'] = canonicalTitle(self.df_products.product_name)
        self.df_products = pd.merge(self.df_products, df_genres, on='can_title', how='left')

    def onlyGenres(self, genres):
        if genres is None:
            # print(f'INFO: not limiting genres')
            pass
        else:
            df_genres = pd.read_csv('movie_genres.csv')
            df_genres['can_title'] = canonicalTitle(df_genres.ml_title)
            self.df_products['can_title'] = canonicalTitle(self.df_products.product_name)
            filtered_titles = df_genres.can_title[df_genres.genre.isin(genres)]
            goodids = self.df_products[self.df_products.can_title.isin(filtered_titles)].product_id
            self.filter2products(goodids)
            if self.verbose > 0:
                print(
                    f'WARN: limited the frame with genres: {genres} to: {len(self.df_orders)} orders, '
                    f'{len(self.df_products)} products (and {len(self.df_order_products)} order-product tuples)')

    def create_with_filtered_product_ids(self, product_ids, similarity=None, steps=1, need_all_steps=False):
        """
        Creates a new iFrame limited to products that share a basket with any of the 'product_ids'
        :param need_all_steps:
        :param steps: the amount of the lookup steps to do, ie (step1) products Y sharing a trolley with X, and (step2)
        products Z sharing a trolley with Y, and (step3)...
        :param product_ids:
        :param similarity: if not None - approvals from product_ids are copied over to similar to product_ids
        :return: a tuple: (final_iframe, iframe_per_step_list)
        """

        def run_one_step(op, product_ids):
            white_order_ids = op[op.product_id.isin(product_ids)].order_id
            op4white_orders = op[op.order_id.isin(white_order_ids)]
            white_products_ids = op4white_orders.product_id.unique()
            # print(f'\nproduct_ids={sorted(product_ids.tolist())}, \nwhite_pids={sorted(white_products_ids)}')

            white_order = self.df_orders[self.df_orders.order_id.isin(white_order_ids)]
            white_products = self.df_products[self.df_products.product_id.isin(white_products_ids)]
            return InstacartDataFrames(op4white_orders, white_order, white_products, self.df_departments,
                                       self.df_aisles)

        iframes = [run_one_step(self.df_order_products, product_ids)]
        for step in range(1, steps):
            latest_iframes = iframes[-1]
            if not need_all_steps:
                iframes = []
            iframes.append(run_one_step(self.df_order_products, latest_iframes.df_products.product_id))

        return iframes[-1], iframes

    def create_with_limit_to_product_ids(self, product_ids):
        print(f'creating frames limited to {len(product_ids)} products')
        op = self.df_order_products
        order_products_filtered = op[op.product_id.isin(product_ids)]
        products_filtered = self.df_products[self.df_products.product_id.isin(product_ids)]
        orders_filtered = self.df_orders[self.df_orders.order_id.isin(order_products_filtered.order_id)]
        return InstacartDataFrames(order_products_filtered, orders_filtered, products_filtered, self.df_departments,
                                   self.df_aisles)

    def create_random_order_spread_frames(self, n_baskets_per_user):
        """
        assign orders to users (so that a user would have n_baskets_per_user orders)
        shuffle each users products within their orders
        result: a user still buys complete clusters, but spread across multiple 'visits'
        :param n_baskets_per_user:
        :return:
        """
        n_users = int(len(self.df_orders) / n_baskets_per_user)
        order_user_df = self.df_orders.copy()
        ou = order_user_df
        ou['user_id'] = np.random.random_integers(1, n_users, size=len(ou))

        op_df = self.df_order_products.copy().merge(ou, on="order_id")
        op_df['order_id'] = op_df.user_id * n_baskets_per_user + np.random.random_integers(0, n_baskets_per_user - 1,
                                                                                           size=len(op_df))
        order_df = pd.DataFrame([(oid, 1) for oid in op_df.order_id.unique()], columns=['order_id', 'user_id'])

        # op_df = op_df.sort_values(['order_id'])
        return InstacartDataFrames(op_df, order_df, self.df_products.copy(), self.df_departments.copy(),
                                   self.df_aisles.copy())

    def create_split_products_into_flavours(self, n_flavours):
        """
        for each product in every basket replace it with one of X its flavours
        """
        # make sure we have a segment == 10^x beyound our product ids
        segment_log = np.ceil(np.log10(len(self.df_products)))
        segment = int(np.power(10, segment_log))

        new_products = []
        for i in range(n_flavours):
            df = self.df_products.copy()
            df.product_id += i * segment
            df.product_name += f'/{i}'
            new_products.append(df)

        new_products_df = pd.concat(new_products)

        newop = self.df_order_products.copy()
        newop.product_id = segment * np.random.randint(0, n_flavours, size=len(newop)) + newop.product_id

        return InstacartDataFrames(newop, self.df_orders.copy(), new_products_df, self.df_departments.copy(),
                                   self.df_aisles.copy())

    def get_product_ids_for_order(self, order_id):
        return set(self.df_order_products[self.df_order_products.order_id == order_id].product_id)


"""
main elections class
- internal data structures are using cix (candidate idexes) and vix (voter indexes) mapped to product_ids and order_ids
"""


class Elections:
    # TODO: remove candidates_count i voters_count
    def __init__(self, candidates_count, voters_count, instacartFrames, idf_map=None, utility_scorer=None, verbose=1):
        self.verbose = verbose
        self.utility_scorer = utility_scorer
        self.candidate_count = candidates_count
        self.voter_count = voters_count
        self.instacartFrames = instacartFrames
        self.candidate_ix2id_list = instacartFrames.df_products.product_id.tolist()
        self.candidate_id2ix_dict = {self.candidate_ix2id_list[i]: i for i in range(len(self.candidate_ix2id_list))}
        self.voter_ix2id_list = instacartFrames.df_orders.order_id.tolist()
        self.voter_id2ix_dict = {self.voter_ix2id_list[i]: i for i in range(len(self.voter_ix2id_list))}
        self.set_idf_map(idf_map)
        self.utility_profile = None

    def sample(self, max_candidates=None, max_voters=None, random_state=None):
        sampled_frames = self.instacartFrames.sample(n_orders=max_voters, n_products=max_candidates, random_state=random_state)
        return Elections.from_instacart_frames(sampled_frames)

    def set_idf_map(self, idf_map):
        if idf_map is None:
            idf_map = self.create_idf_map_1()
        self.idf_map = idf_map
        self.idf_vector = list(
            map(lambda ix: idf_map.get(self.candidate_ix2id_list[ix]), range(len(self.candidate_ix2id_list))))

    def voter_id2ix(self, id):
        return self.voter_id2ix_dict[id]

    def voter_ix2id(self, ix):
        if ix < 0:
            return ix
        return self.voter_ix2id_list[ix]

    def candidate_id2ix(self, id):
        return self.candidate_id2ix_dict[id]

    def candidate_ix2id(self, ix):
        if ix < 0:
            return ix
        return self.candidate_ix2id_list[ix]

    def create_idf_map_1(self):
        return {id: 1.0 for id in self.instacartFrames.df_products.product_id}

    def _create_idf_df_smooth(self):
        df_idf = self.instacartFrames.df_order_products[['product_id', 'order_id']].groupby('product_id',
                                                                                            as_index=False).count()
        all_orders_count = len(self.instacartFrames.df_order_products.order_id.unique())
        df_idf['idf'] = np.log(np.divide(all_orders_count, df_idf.order_id))
        return df_idf

    def __str__(self):
        return f'Elections(C={self.candidate_count}, V={self.voter_count}'

    @staticmethod
    def from_instacart_frames(instacart_frames, idf_map=None, utility_scorer=None):
        if utility_scorer is not None and idf_map is None:
            idf_map = None
            print(f'setting IDF_MAP=None, because candidate_scorer is not None')

        e = Elections(len(instacart_frames.df_products), len(instacart_frames.df_orders), instacart_frames, idf_map,
                      utility_scorer=utility_scorer, verbose=instacart_frames.verbose)
        return e

    def generate_utility_profile(self):
        if self.utility_profile is None:
            # print('generating utility profile')
            utility_profile = [{} for _ in range(self.voter_count)]

            for item in self.instacartFrames.df_order_products.itertuples(index=False):
                voter_ix = self.voter_id2ix(item.order_id)
                candidate_ix = self.candidate_id2ix(item.product_id)
                score = self.utility_scorer.score(item.order_id,
                                                  item.product_id) if self.utility_scorer is not None else 1.0
                utility_profile[voter_ix][candidate_ix] = score
            self.utility_profile = utility_profile
            # print('utility profile generated.')
        return self.utility_profile

    def equals(self, other):
        return self.candidate_count == other.candidate_count \
               and self.voter_count == other.voter_count

    def get_owa_anneal_results(self, k, owa_vector, anneal_settings=None, algo_version=0, verbose=0):
        optimizer = self.resolve_optimizer(ALGO_SA, algo_version, k, owa_vector, verbose)
        state, energy = optimizer.run(anneal_settings)
        winner_ids = [self.candidate_ix2id(cix) for cix in state]
        return ElectionResults(winner_ids, f"annealing score={-energy}", -energy)

    def get_owa_greedy_results(self, k, owa_vector, verbose=0, algo_version=0):
        optimizer = self.resolve_optimizer(ALGO_GREEDY, algo_version, k, owa_vector, verbose)
        committee, score = optimizer.run()
        winner_ids = [self.candidate_ix2id(cix) for cix in committee]
        return ElectionResults(winner_ids, f"greedy score={score}", score)

    def get_owa_ilp_results(self, k, owa_vector, verbose=0, algo_version=0):
        optimizer = self.resolve_optimizer(ALGO_ILP, algo_version, k, owa_vector, verbose)
        committee, score = optimizer.run()
        winner_ids = [self.candidate_ix2id(cix) for cix in committee]
        return ElectionResults(winner_ids, f"ILP score={score}", score)

    def resolve_optimizer(self, algo, algo_version, k, owa_vector, verbose):
        # NOTE: don't remove - utility_profile is used in eval
        utility_profile = self.generate_utility_profile()
        optimizers = {ALGO_GREEDY: "OwaGreedy", ALGO_SA: "OwaAnnealer", ALGO_ILP: "OwaILP"}
        optimizer_class = f"{optimizers[algo]}{algo_version}"
        optimizer = eval(f"{optimizer_class}(self.candidate_count, k, utility_profile, owa_vector, "
                         f"verbose=verbose)")
        return optimizer

    def get_av_results(self, k, verbose=0):
        utility_profile = self.generate_utility_profile()
        total_cand_utilities = defaultdict(float)
        for voter_utilities in utility_profile:
            for cix, utility in voter_utilities.items():
                total_cand_utilities[cix] += utility
        winners = list(sorted([(ut, cix) for cix, ut in total_cand_utilities.items()], reverse=True))[:k]
        winners_indices = [cix for _, cix in winners]
        winner_utilities = [utility for utility, _ in winners]
        winner_ids = [self.candidate_ix2id(cix) for cix in winners_indices]
        score = sum(winner_utilities)
        return ElectionResults(winner_ids, f"greedy score={score} ({winner_utilities})", score)
