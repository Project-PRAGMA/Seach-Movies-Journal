from collections import namedtuple

Voter = namedtuple("Voter", "index approvals")


def build_resource_approving_voters(pref_profile, m):
    approving_voters = {rix: [] for rix in range(m)}
    for vix, voter in enumerate(pref_profile):
        for rix, utility in voter.items():
            if utility > 0:
                approving_voters[rix].append(Voter(vix, voter))
            else:
                raise Exception("Utilities should be positive")
    return approving_voters
