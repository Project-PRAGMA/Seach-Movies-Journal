import math
import os
import re
from collections import defaultdict
from functools import reduce
import random

import bokeh
import bokeh as bk
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from bokeh.layouts import row
from bokeh.models import ColumnDataSource, ColorBar
from bokeh.plotting import figure, show
from bokeh.transform import log_cmap

import utils
from data.movielens_data import MovielensData
from es import Rules
from es.elections import Elections, ALGO_SA, ALGO_GREEDY, ALGOS, ALGO_DEFAULT, PROD_VERSIONS, ALGO_ILP, \
    InstacartDataFrames
from es.metrics import Metric, MetricBM25, MetricTfxIdf
from es.similarity import IdentitySimilarity
from es.utils import dotdict
from es.sql_database import Database


class ElectionUtils:
    def __init__(self, instacart_frames, db_filename=None):
        self.instacart_frames = instacart_frames

        self.verbose = self.instacart_frames.verbose

        op = instacart_frames.df_order_products
        product_count_df = op[['product_id']].groupby(op.product_id).count()
        product_count_df.columns = ['order_count']
        product_count_df.reset_index(inplace=True)
        self.avgdl = product_count_df.order_count.mean()

        products1 = pd.merge(instacart_frames.df_products, instacart_frames.df_aisles, on="aisle_id", how='inner')
        self.products_full = pd.merge(products1, instacart_frames.df_departments, on="department_id", how='inner')
        self.product_count_df = product_count_df
        self.product_search = pd.merge(self.products_full, product_count_df, on="product_id", how='left')
        self.op_verbose = op.merge(instacart_frames.df_products, on='product_id', how='left')

        if db_filename is not None:
            print(f'creating db with {len(self.product_search)} products')
            self.db = Database(db_filename)
            self.db.add_replace_table(self.product_search, "product", index_columns=['product_id'])

    # ======================================================================
    # handies
    def _________handies(self):
        pass

    @staticmethod
    def from_movielens(parquet_folder):
        idata = MovielensData(parquet_folder)
        iframes = InstacartDataFrames.from_data(idata)
        utils = ElectionUtils(iframes)
        return utils

    @staticmethod
    def create_grid(figures, rows=1, columns=None, toolbar_location='right', sizing_mode='scale_both'):
        empty_figure = bokeh.plotting.figure()
        empty_figure.toolbar_location = None
        if columns is None:
            columns = math.ceil(len(figures) / rows)
        else:
            rows = math.ceil(len(figures) / columns)

        empty_spots = rows * columns - len(figures)
        if empty_spots > 0:
            figures = figures + [empty_figure] * empty_spots
        figures_shape = np.reshape(figures, (rows, columns)).tolist()

        figures_layedout = bokeh.layouts.layout(figures_shape, sizing_mode=sizing_mode)
        return figures_layedout

    @staticmethod
    def prefix_cols(df, prefix):
        df.columns = [prefix + x for x in df.columns]

    #
    @staticmethod
    def bk_title(title):
        t = bokeh.models.annotations.Title()
        t.text = title
        return t

    # ======================================================================
    # data processing
    def _________data_processing(self):
        pass

    def rules_sidebyside_df(self, results_df, rules, withid=False, withcat=False):
        additional_columns_dict = {}
        if withid:
            additional_columns_dict['product_id'] = 'id'
        if withcat:
            additional_columns_dict['genre'] = 'cat'

        return self.rules_sidebyside_df2(results_df, rules, additional_columns_dict)

    def rules_sidebyside_df2(self, results_df, rules, add_cols_dict=None):
        add_cols_dict = {} if add_cols_dict is None else add_cols_dict

        def rule_dfs():
            for rule in rules:
                ruledf = results_df[results_df.rule == rule]
                df = pd.DataFrame({'rank': ruledf['rank']})
                df[rule] = ruledf.product_name
                for col, show_col in add_cols_dict.items():
                    df[f"{rule}_{show_col}"] = ruledf[col]
                yield df

        return reduce(lambda l, r: pd.merge(l, r, on='rank', how='left'), rule_dfs())

    def calc_results(self, rules, k, similarity, filtered_elections, verbose=1, run_params=None, seed=None):

        results_dict = {}
        elections_results_dict = {}
        if run_params is None:
            run_params = dotdict({})
        for long_rule in rules:

            if seed is not None:
                random.seed(seed)

            if verbose >= 1:
                print(f'processing RULE: {long_rule}')

            algo, algo_version, rule, owa_vector = parse_rule(long_rule)
            if verbose > 0:
                print(f"Using algo/version: {algo}/{algo_version}")

            if algo == ALGO_SA:
                election_results = filtered_elections.get_owa_anneal_results(k,
                                                                             owa_vector=owa_vector,
                                                                             anneal_settings=run_params.anneal_settings,
                                                                             algo_version=algo_version,
                                                                             verbose=verbose
                                                                             )
                enriched_results = self.winner_ids2result_df(election_results.winner_ids)
            elif algo == ALGO_GREEDY:
                if rule != 'HUV_0' or run_params.thorough_HUV_0 is True:
                    election_results = filtered_elections.get_owa_greedy_results(k, owa_vector=owa_vector,
                                                                                 verbose=verbose,
                                                                                 algo_version=algo_version)
                else:
                    if verbose > 0:
                        print("Using optimised HUV_0")
                    election_results = filtered_elections.get_av_results(k, verbose=verbose)

                enriched_results = self.winner_ids2result_df(election_results.winner_ids)
            elif algo == ALGO_ILP:
                election_results = filtered_elections.get_owa_ilp_results(k, owa_vector=owa_vector,
                                                                          verbose=verbose,
                                                                          algo_version=algo_version)

                enriched_results = self.winner_ids2result_df(election_results.winner_ids)
            else:
                raise Exception(f'the rule {rule} is not recognised')
            if verbose > 0:
                print(f'{election_results.description}')

            # self.prefix_cols(enriched_results, f'{rule}_')
            elections_results_dict[long_rule] = election_results
            enriched_results['rule'] = long_rule
            enriched_results['rulex'] = rule
            enriched_results['algo'] = algo
            enriched_results['algo_version'] = algo_version
            results_dict[long_rule] = enriched_results
        return results_dict, elections_results_dict

    @staticmethod
    def _apply_idf_weights(idf_map, filtered_iframes_list, step_weights):
        all_product_ids = set([])
        product_ids_per_weight = []
        for iframe in filtered_iframes_list:
            step_ids = set(iframe.df_products.product_id.tolist())
            # print(f'step_ids: {step_ids}')
            product_ids_per_weight.append(step_ids.difference(all_product_ids))
            all_product_ids.update(step_ids)

        new_idf_map = idf_map.copy()
        for product_ids, weight in zip(product_ids_per_weight, step_weights):
            print(f'* weight={weight}, product_ids: {product_ids}')
            for id in product_ids:
                new_idf_map[id] *= weight

        return new_idf_map

    def create_filtered_elections(self, search_df, idf_map=None, similarity=None, steps=1, step_weights=None,
                                  product_id_blacklist=None, product_id_whitelist=None, utility_scorer=None):
        apply_step_weights = step_weights is not None
        filtered_iframes, filtered_iframes_list = self.instacart_frames.create_with_filtered_product_ids(
            search_df.product_id,
            similarity=similarity,
            steps=steps,
            need_all_steps=apply_step_weights)

        # pid_map = {x.Index: x.order_id for x in filtered_iframes.df_order_products.groupby('product_id').count().itertuples()}
        # print("FILTERED: ")
        # print([(id, pid_map[id]) for id in [1,3,5,8,7]])
        #
        for frames in filtered_iframes_list:
            frames.filterOutProducts(search_df.product_id, inplace=True)

        if product_id_blacklist is not None:
            products2remove = set(product_id_blacklist).difference(set(search_df.product_id))
            for frames in filtered_iframes_list:
                frames.filterOutProducts(products2remove)

        if product_id_whitelist is not None:
            for frames in filtered_iframes_list:
                frames.filter2products(product_id_whitelist)

        if self.verbose:
            print(
                f'filtered iframes, products: {filtered_iframes.df_products.shape[0]}, ' +
                f'orders:  {filtered_iframes.df_orders.shape[0]}')
        idf_map_with_weights = self._apply_idf_weights(idf_map, filtered_iframes_list,
                                                       step_weights) if apply_step_weights else idf_map
        elections = Elections.from_instacart_frames(filtered_iframes, idf_map_with_weights, utility_scorer)
        return elections

    def winner_ids2result_df(self, winner_ids):
        #     create winners data frame
        winners_df = pd.DataFrame(winner_ids, columns=['product_id'])
        winners_df['rank'] = winners_df.index + 1

        # print(f'enhancing winner info')
        df = self.products_full.merge(winners_df, how='right', on='product_id').sort_values(by='rank')
        df.reset_index(inplace=True)
        return df

    def calc_search_df(self, name_re):
        return self.find_products(name_re, min_order_count=1)

    def find_single_product(self, search_term, strict=True):
        results = self.find_products(search_term, min_order_count=1)
        if len(results) > 1:
            results = results[:1]

        if len(results) == 1:
            return {k: v for k, id_val_dict in results.to_dict().items() for _, v in id_val_dict.items()}

        if strict:
            if len(results) == 0:
                raise Exception(f"cannot find the product by search_term: {search_term}")
            else:
                raise Exception(f"found {len(results.product_id)} items instead of one for search_term {search_term}")
        else:
            return None

    def find_products(self, name_re, dep_re=".*", aisle_re='.*', min_order_count=1000.0, max_order_count=10000000):
        product_search = self.product_search
        return product_search[ \
            product_search.product_name.str.contains(name_re, regex=True, flags=re.IGNORECASE) \
            & product_search.department.str.contains(dep_re, regex=True, flags=re.IGNORECASE) \
            & product_search.aisle.str.contains(aisle_re, regex=True, flags=re.IGNORECASE) \
            & (product_search.order_count >= min_order_count) \
            & (product_search.order_count <= max_order_count) \
            ].sort_values(by='order_count', ascending=False)

    # ======================================================================
    # VISUALISATION
    def _________visualisation(self):
        pass

    @staticmethod
    def plot_rank_scatter(results, column, rule_color_map=None, figsize=(15, 5)):

        if rule_color_map is None:
            rule_color_map = dict(zip(results.rule.unique(),
                                      'green red blue yellow orange brown violet violet violet violet violet violet'.split(
                                          ' ')))

        fig, ax = plt.subplots(1, 1)

        plt.rcParams["figure.figsize"] = figsize
        plt.xticks(rotation=90)
        plt.xlabel('rank')
        plt.ylabel(column)
        plt.gca().invert_yaxis()
        scatter = ax.scatter(
            results['rank'],
            results[column],
            c=results.rule.map(lambda x: rule_color_map[x] if x in rule_color_map.keys() else 'black'),
            alpha=.5)

        plt.show()

    def plot_rank_slopes(self, left, right, results_dict, rank_limit=None):

        def plot_ranks_by_product(df):
            ymin = min(df.min())
            ymax = max(df.max())

            from matplotlib.pyplot import figure
            figure(num=None, figsize=(12, 10), dpi=80, facecolor='w', edgecolor='k')
            # fig, ax = plt.subplots(1,1)
            # fig

            num_times = df.shape[1]
            num_units = df.shape[0]

            x_max = 10
            plt.ylabel(f'{left} vs {right}')
            plt.title = (f'{left} vs {right}')
            plt.xlim(0, x_max)
            plt.ylim(ymin - 1, ymax + 1)
            plt.axis('off')
            plt.gca().invert_yaxis()

            x_boost = 10

            for time in range(num_times):
                for unit in range(num_units):
                    if time == 1:
                        #             on the right
                        label = f'{df.values[unit][time]} : {df.index[unit]}'
                        alignment = 'left'
                        x = x_max / 2 + 1
                    else:
                        label = f'{df.index[unit]} : {df.values[unit][time]}'
                        alignment = 'right'
                        x = x_max / 2 - 1

                    y = df.values[unit][time]
                    if y >= 0:
                        plt.text(x,
                                 y,
                                 label,
                                 horizontalalignment=alignment,
                                 verticalalignment='center')

            num_lines = range(1, num_times)

            for l in num_lines:
                for row in df.values:
                    plt.plot([x_max * l / 2 - 1 + .25, x_max * l / 2 + .75], [row[l - 1], row[l]])

            plt.show()

        def by_product_name(results, prefix):
            aa = results[['product_name', 'product_id', 'rank']]
            aa['product'] = aa['product_name'] + ' [' + aa.product_id.astype(str) + ']'
            aa.index = aa['product']
            prefixed_rank = f'{prefix}_rank'
            aa[prefixed_rank] = aa['rank']
            return aa[[prefixed_rank]]

        df = pd.merge(by_product_name(results_dict[left], left), by_product_name(results_dict[right], right),
                      how='outer', left_index=True, right_index=True)
        if rank_limit:
            df = df[(df[f'{left}_rank'] < rank_limit) | (df[f'{right}_rank'] < rank_limit)]

        plot_ranks_by_product(df)

    @staticmethod
    def figure_coocurrence(op_verbose, add_scale=True, axis_visible=False):
        product_pairs = op_verbose.merge(op_verbose, on='order_id')
        product_pairs = product_pairs[product_pairs.product_id_x != product_pairs.product_id_y]
        product_pairs = product_pairs.sort_values(by=['product_name_x', 'product_name_y'])

        product_pairs = product_pairs.groupby(by=['product_id_x', 'product_id_y', 'product_name_x', 'product_name_y'],
                                              as_index=False).order_id.count()
        product_pairs['size'] = 255 * product_pairs.order_id / max(product_pairs.order_id)
        product_pairs['count'] = product_pairs.order_id

        all_product_ids = product_pairs.product_name_x.unique().tolist()
        TOOLS = "box_zoom,pan,reset"
        TOOLTIPS = [
            ("(x,y): count", "(@product_name_x, @product_name_y): @count"),
        ]
        palette = bk.palettes.Viridis[256]
        # palette.reverse()
        mapper = log_cmap('size', palette, 1, 255)
        p = figure(tooltips=TOOLTIPS, tools=TOOLS, active_drag='box_zoom',
                   plot_width=600, plot_height=600,
                   min_border=0, min_border_left=50,
                   toolbar_location="above",
                   title="Product co-ocurrence",
                   x_range=all_product_ids,
                   y_range=all_product_ids)

        p.rect(x='product_name_x', y='product_name_y',
               width=1, height=1, color=mapper, alpha=0.4, source=product_pairs)

        # p.background_fill_color = "#eeeeee"
        p.axis.visible = axis_visible
        p.grid.visible = False

        if add_scale:
            color_bar = ColorBar(color_mapper=mapper['transform'], width=8, location=(0, 0))
            p.add_layout(color_bar, 'right')

        # create the vertical histogram
        x_counts = op_verbose.groupby(by=['product_id', 'product_name'], as_index=False).order_id.count()
        x_counts['counts'] = x_counts.order_id
        vmax = x_counts.counts.max()
        # vhist, vedges = np.histogram(x_counts.counts.tolist(), bins=20)
        pv = figure(plot_width=200, plot_height=p.plot_height, y_range=x_counts.product_name,
                    x_range=(0, vmax), min_border=20, y_axis_location="left",
                    tools=TOOLS, active_drag='box_zoom')
        pv.ygrid.grid_line_color = None
        pv.xaxis.major_label_orientation = np.pi / 2
        pv.background_fill_color = "#fafafa"
        pv.yaxis.axis_label_text_font_size = "10pt"

        pv.hbar(y=x_counts.product_id - 2, right=x_counts.counts, height=1)

        return p, pv

    @staticmethod
    def figure_coocurence_ranks(op_verbose, results, title='coocurrence ranks', toolbar_location='right', size=7):

        from bokeh.transform import linear_cmap
        #     results['product_name_x'] = results.product_name
        #     results['product_name_y'] = results.product_name
        cooc, hist = ElectionUtils.figure_coocurrence(op_verbose, add_scale=False, axis_visible=False)
        mapper = linear_cmap('rank', bokeh.palettes.gray(len(results)), 1, len(results))
        # cooc.vbar(x=results.product_id, width=.11, alpha=0.1, top=10)
        cooc.circle(x='product_name', y='product_name', color=mapper, line_color='black', size=size, source=results)
        cooc.toolbar_location = toolbar_location
        cooc.title = ElectionUtils.bk_title(title)
        return cooc

    @staticmethod
    def plot_coocurrence(op_verbose, include_histogram=True):
        coocurence, histogram = ElectionUtils.figure_coocurrence(op_verbose)
        to_show = [[coocurence, histogram]] if include_histogram else [[coocurence]]
        layout = bk.layouts.gridplot(to_show, merge_tools=False)
        show(layout)

    def figures_by_params(self, title_prefix, op_verbose, search_df, k, rules, steps_it, idfs_tuples,
                          similarity=IdentitySimilarity(), toolbar_location=None):
        figures = []
        for rule in rules:
            for idf_name, idf in idfs_tuples:
                for steps in steps_it:
                    filtered_elections = self.create_filtered_elections(search_df, idf, similarity=similarity,
                                                                        steps=steps)

                    results_dict = self.calc_results(rules, k, similarity, search_df, filtered_elections)
                    results_all = pd.concat(results_dict.values())

                    results = results_all[results_all.rule == rule]
                    cooc = self.figure_coocurence_ranks(
                        op_verbose, results, toolbar_location=toolbar_location,
                        title=f'{title_prefix}{rule},steps={steps},idf={idf_name}')
                    figures.append(cooc)
        return figures

    # ======================================================================
    # search section

    def _________search_section(self):
        pass

    """
        search_df - a dataframe with product_id column
    """

    def calc_found_df(self, search_df, org_iframes=None, metrics_list=None, sorted_by=None, nosearchterm=False,
                      verbose=1, extra_cols="idfto2,tfidf,tfidfto2,bm25,ratioIn"):
        verbose = min(verbose, self.verbose)
        metrics_list = [] if metrics_list is None else metrics_list
        # filter items
        iframes_reduced, _ = self.instacart_frames.create_with_filtered_product_ids(search_df.product_id)
        df = iframes_reduced.df_order_products[['product_id', 'order_id']].groupby('product_id', as_index=False).count()
        df.columns = ['product_id', 'order_count_found']
        # add full product info
        df = df.merge(self.product_search[['product_id', 'product_name', 'order_count']], on='product_id')
        df['tf'] = df.order_count_found

        doc_length = len(df) - len(search_df)  # adjusting for the search elements
        voter_count = len(self.instacart_frames.df_order_products.order_id.unique())
        if verbose > 0:
            print(f"dl={doc_length}, avgdl={self.avgdl}, products={len(df)} metrics_voter_count={voter_count}, "
                  f"real_voter_count={len(self.instacart_frames.df_order_products.order_id.unique())}")

        df['idf'] = np.log(np.divide(voter_count, df.order_count))

        extra_funcs = {}
        extra_funcs['idfto2'] = lambda: np.power(1.85, df.idf)
        extra_funcs['tfidf'] = lambda: df.order_count_found * df.idf
        extra_funcs['tfidfto2'] = lambda: df.order_count_found * df.idfto2
        extra_funcs[f'bm25'] = lambda: MetricBM25(k=2.0, b=0.9).calc(idf=df.idf, tf=df.tf, dl=doc_length,
                                                                     avgdl=self.avgdl)
        extra_funcs['ratioIn'] = lambda: df.order_count_found / df.order_count
        for extra_col in extra_cols.split(","):
            df[extra_col] = extra_funcs[extra_col]()

        for metric_dict in metrics_list:
            m = Metric.from_dict(metric_dict)
            if type(m) is MetricBM25:
                df[m.get_name()] = m.calc(idf=df.idf, tf=df.tf, dl=doc_length, avgdl=self.avgdl)
            elif type(m) is MetricTfxIdf:
                df[m.get_name()] = m.calc(tf=df.tf, idf=df.idf)

        # df.to_csv("output/metrics.csv")

        if sorted_by is not None:
            df = df.sort_values(by=sorted_by, ascending=False)
        if nosearchterm:
            df = df[~df.product_id.isin(search_df.product_id)]

        return df

    def product_ids_more_popular(self, search_df, multiplier, utils):
        """
        return a list of products more popular (by multiplier) than max product_id from search_df
        """
        search_product_id = search_df.product_id.max()
        count_threshold = utils.product_search.query(f'product_id=={search_product_id}').order_count.max()
        max_order_count = count_threshold * multiplier
        result = utils.product_search.query(f'order_count>{max_order_count}').product_id
        print(
            f'the count of products more popular than product_id {search_product_id} ' +
            f'(with count={count_threshold}) by {multiplier} times is = {len(result)}')
        return result

    def products_with_max_ratio(self, search_df, org_iframes, max_ratio):
        df = self.calc_found_df(search_df, org_iframes, verbose=self.verbose)
        return df[df.ratioIn <= max_ratio]

    def top_products(self, found_df, topn, topn_metric, ascending=False):
        return found_df.sort_values(topn_metric, ascending=ascending)[:topn]

    def asymmetric_products(self, search_id, org_iframes, found_df, topn, symmetry_topn, metric, ascending=False):
        """
        for each product B in found_df
        - find AV winners sorted by metric/ascending
        - if this winners' set doesn't include the 'search_id' (within symmetry_topn items), then B is asymmetric
        return topn asymetric ids (by metric/ascending)
        """
        print(f'finding assymetric products')
        result_ids = []
        df1 = found_df.sort_values(metric, ascending=ascending)[:topn]
        for pid in list(df1.product_id):
            #         print(f'.')
            search_df2 = self.product_search[self.product_search.product_id == pid]
            found_df2 = self.calc_found_df(search_df2, org_iframes).sort_values(metric, ascending=ascending)[
                        :symmetry_topn]
            if search_id not in set(found_df2.product_id):
                print(f'found: {pid}')
                result_ids.append(pid)
            if len(result_ids) >= topn:
                break

        return found_df[found_df.product_id.isin(result_ids)]

    def recurring_winners_blacklist(self, org_iframes, topn, seed_size, drop_ratio_threshold,
                                    topn_metric='order_count_found', ascending=False):
        """
        for a seed list of products, calculate the the winners for each of the product with topn AV (by metric/ascending)
        intersect the winner lists - this is the blacklist - return it
        """
        # result of: np.random.choice(list(utils.product_search.product_id), size=15, replace=False)
        seed_product_ids = [3824, 14353, 17100, 2163, 1743, 15979, 17163, 1918, 10171,
                            11652, 4341, 15627, 2135, 15953, 5683, 6268, 4569, 9833,
                            5657, 6300, 6318, 13034, 2243, 15989, 5672, 2726, 1911,
                            6027, 14511, 9521][:seed_size]

        counts = defaultdict(int)
        print(f'calculating recurring winners blacklist for {seed_size} elements.')
        for pid in seed_product_ids:
            search_df = self.product_search[self.product_search.product_id == pid]
            found_df = self.calc_found_df(search_df, org_iframes).sort_values(topn_metric, ascending=ascending)[:topn]
            for pid in found_df.product_id:
                counts[pid] += 1
            # print(f"AV for PID={pid}: ", ", ".join(list(found_df.product_name)))
        # print(f"COUNTS: {counts}")
        blacklist = [pid for pid, count in counts.items() if count / seed_size >= drop_ratio_threshold]

        return self.product_search[self.product_search.product_id.isin(blacklist)]

    def products_tf_metric_grid(self, product_res, factors, metrics_list, metric_converter=None,
                                metric_kind='unspecified', out_folder=None, title_ids_to_highlight=None):
        import seaborn as sns
        sns.set_theme(style="white",
                      font_scale=1.8,
                      # palette=palette,
                      context='notebook')
        print(product_res)
        for product_re in product_res:
            shortcut = None
            for movie, short in {
                'The Search for Spock': 'sfs',
                'Renegades': 'renegades',
                # 'Indiana Jones and the Last Crusade': 'ij_crusade',
                # 'Indiana Jones and the Temple of Doom': 'ij_temple',
                # 'Skyfall': 'jb_skyfall',
                # 'Goldfinger': 'jb_goldfinger',
                'The Lion, the Witch and the Wardrobe': 'narnia_lion',
                'Prince Caspian: The Return to Narnia': 'narnia_prince',
                'The Voyage of the Dawn Treader': 'narnia_voyage',
                # 'The Silver Chair': 'narnia_silver',
                # 'The Horse and His Boy': 'narnia_horse',
                "The Magician's Nephew": 'narnia_magician',
                # 'The Last Battle': 'narnia_last',
            }.items():
                if movie in product_re:
                    shortcut = short

            if out_folder is not None and shortcut is not None:
                products_df = self.find_products(product_re, min_order_count=1)
                assert len(products_df) > 0, f"no products found for re: {product_re}"
                found_df = self.calc_found_df(products_df, metrics_list=metrics_list, nosearchterm=True)
                found_df['title_re'] = product_re
                found_df['TF'] = found_df.tf
                found_df['movie'] = found_df.product_id.map(
                    lambda x: 'SearchedFor' if x in title_ids_to_highlight else 'other'
                )
                found_df['size'] = found_df['movie'].map(lambda x: 3 if x == 'other' else 4)
                metric_labels = [Metric.from_dict(m).get_name() for m in metrics_list]
                if metric_converter is not None:
                    for m in metric_labels:
                        found_df[metric_converter(m)] = found_df[m]
                    metric_labels = [metric_converter(label) for label in metric_labels]

                found_df['approvals'] = found_df['order_count']

                # with sns.color_palette("ch:start=0,rot=0,dark=0.7,light=0,hue=0", n_colors=len(found_df['approvals'].unique())) as palette:
                g = sns.PairGrid(found_df, y_vars=factors,
                                 x_vars=list(metric_labels),
                                 height=4,
                                 aspect=.75,
                                 hue='approvals',
                                 # palette=palette
                                 )
                g.map(
                    sns.scatterplot,
                    style=found_df['movie'],
                    size=found_df['size']
                )

                # cut off everything from 'size' onwards (label order is what decides what items gets shown in the legend
                size_index = [ix for ix, v in enumerate(g._legend_data.keys()) if v == 'size'][0]
                new_label_order = list(g._legend_data.keys())[:size_index]
                g.add_legend(
                    label_order=new_label_order,
                    loc='lower center',
                    ncol=5,
                    frameon=True,
                    bbox_to_anchor=(0.3, 0),
                )
                g.fig.subplots_adjust(top=0.9, bottom=.4)
                # g.fig.suptitle(utils.product_re2display(product_re), horizontalalignment='center', x=0.35)

                g._legend.set_title("")

                fig_filename = f"{out_folder}/calib_balance_metric({metric_kind})_movie({shortcut}).png"
                print(f"Saving balance figure to '{fig_filename}'")
                g.savefig(fig_filename, dpi=300)

        #         print(product_re)
        #         display(found_df.sort_values(col, ascending=False)[:10])

    @staticmethod
    def load_results_df(exp_folder):
        result_df = None
        for filename in os.listdir(exp_folder):
            if not filename.startswith('exp') or '_TFIDF.tsv' in filename:
                continue
            df = pd.read_csv(os.path.join(exp_folder, filename))
            df['scorer'] = df.run_name.apply(lambda s: s.split("ut_scorer=")[1])
            result_df = df if result_df is None else pd.concat([df, result_df]).drop_duplicates()
        return result_df

    @staticmethod
    def load_tfidf_results_df(exp_folder):
        result_df = None
        for filename in os.listdir(exp_folder):
            if not '_TFIDF.tsv' in filename:
                continue
            df = pd.read_csv(os.path.join(exp_folder, filename), sep='\t')
            # df['filename'] = filename
            search_term = filename.split("search=")[1]
            search_term = search_term[:search_term.index(",")]
            df['search_term'] = search_term
            df['rank'] = range(1, len(df) + 1)
            result_df = df if result_df is None else pd.concat([df, result_df]).drop_duplicates()
        return result_df

    def load_results_db(self, exp_folder):
        db = Database()
        df = self.load_results_df(exp_folder)
        db.add_replace_table(df, 'results')
        df = self.load_tfidf_results_df(exp_folder)
        db.add_replace_table(df, 'tfidfs')
        return db


def parse_rule(rule):
    split = rule.split('.')
    if len(split) == 1:
        algo, version, rule = ALGO_DEFAULT, PROD_VERSIONS[ALGO_GREEDY], rule
    else:
        algo_version, rule = split
        algo_start, algo_finish = re.match(r"\D*", algo_version).span()
        if algo_finish == 0 or algo_start > 0:
            raise Exception(f"couldn't parse the algo from: {split}")
        elif algo_finish == len(algo_version):
            algo = algo_version
            version = PROD_VERSIONS[algo]
        else:
            algo, version = algo_version[:algo_finish], algo_version[algo_finish:]

    assert algo in ALGOS, f"unrecognised rule algo: {algo}"
    assert rule in Rules.rules_dict, f"sa rule postfix {rule} must exist in the rules dictionary ({Rules.rules_dict}). it doesn't"

    owa_vector = Rules.rules_dict[rule]

    return algo, version, rule, owa_vector
