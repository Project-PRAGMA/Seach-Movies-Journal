import base64
import contextlib
import copy
import hashlib
import itertools
import pprint
import random
from datetime import datetime
import seaborn as sns

from matplotlib import pyplot as plt
import re

pp = pprint.PrettyPrinter(indent=4)


class MovielensUtils:
    TITLES_CLASSIC = [
        'Hot Shots! (1991)',
        'Star Trek: Generations (1994)',
        'Star Trek V: The Final Frontier (1989)',
        # horrors
        'Alien (1979)',  # 30026.0
        'Ring, The (2002)',  # 7629.0
        # 'Birds, The (1963)', # 8371.0
        'Dirty Dozen, The (1967)',
    ]

    # UAI
    TITLES_CLASSIC_4 = [
        'Hot Shots! (1991)',
        'Star Trek: Generations (1994)',
        'Star Trek V: The Final Frontier (1989)',
        # horrors
        'Alien (1979)',  # 30026.0
        # 'Ring, The (2002)',  # 7629.0
        # 'Birds, The (1963)', # 8371.0
        # 'Dirty Dozen, The (1967)',
    ]

    TITLES_STAR_WARS_ALL = [
        'Star Wars: Episode IV - A New Hope (1977)',
        'Star Wars: Episode V - The Empire Strikes Back (1980)',
        'Star Wars: Episode VI - Return of the Jedi (1983)',
        'Star Wars: Episode I - The Phantom Menace (1999)',
        'Star Wars: Episode III - Revenge of the Sith (2005)',
        'Star Wars: Episode II - Attack of the Clones (2002)',
        'Star Wars: Episode VII - The Force Awakens (2015)',
        'Star Wars: The Last Jedi (2017)',
        # 'Star Wars: The Clone Wars (2008)'
    ]

    TITLES_STAR_TREK_ALL = [
        'Star Trek: Renegades (2015)',  # approvals = 27
        'Star Trek: Nemesis (2002)',  # approvals = 1904
        'Star Trek Beyond (2016)',  # approvals = 1987
        'Star Trek V: The Final Frontier (1989)',  # approvals = 2338
        'Star Trek: Insurrection (1998)',  # approvals = 3783
        'Star Trek: The Motion Picture (1979)',  # a®pprovals = 3785
        'Star Trek III: The Search for Spock (1984)',  # approvals = 4732
        'Star Trek VI: The Undiscovered Country (1991)',  # approvals = 5358
        'Star Trek Into Darkness (2013)',  # approvals = 5621
        'Star Trek IV: The Voyage Home (1986)',  # approvals = 7544
        'Star Trek II: The Wrath of Khan (1982)',  # approvals = 10669
        'Star Trek: Generations (1994)',  # approvals = 10809
        'Star Trek: First Contact (1996)',  # approvals = 12396
        'Star Trek (2009)',  # approvals = 12854
        # 'Star Trek: Of Gods and Men (2007)', # approvals =
    ]

    TITLES_SELECT10 = [
        'Alien .1979.',
        'Dirty Dozen, The .1967.',
        'Hot Shots! .1991.',
        'Indiana Jones and the Last Crusade .1989.',
        'Indiana Jones and the Temple of Doom .1984.',
        'Star Trek V: The Final Frontier .1989.',
        'Star Trek: Generations .1994.',
        'Star Wars: Episode I - The Phantom Menace .1999.',
        'Star Wars: Episode VII - The Force Awakens .2015.',
        'Ring, The .2002.'
    ]

    TITLES_STAR_WARS_SELECT = [
        'Star Wars: Episode IV - A New Hope (1977)',  # 56660
        'Star Wars: Episode I - The Phantom Menace (1999)',  # 13000
        'Star Wars: Episode VII - The Force Awakens (2015)',  # 10000
        'Star Wars: The Last Jedi (2017)',  # 2000
    ]

    TITLES_INDIANA_ALL = [
        'Raiders of the Lost Ark (Indiana Jones and the Raiders of the Lost Ark) (1981)',  # 46384.0
        'Indiana Jones and the Last Crusade (1989)',  # 30648.0
        'Indiana Jones and the Temple of Doom (1984)',  # 17140.0,
        'Indiana Jones and the Kingdom of the Crystal Skull (2008)'  # 3000
    ]

    TITLES_JAMES_BOND_ALL = [
        'Octopussy (1983)',
        'Living Daylights, The (1987)',
        'View to a Kill, A (1985)',
        "On Her Majesty's Secret Service (1969)",
        'You Only Live Twice (1967)',
        'Licence to Kill (1989)',
        'Spectre (2015)',
        'For Your Eyes Only (1981)',
        'Man with the Golden Gun, The (1974)',
        'Diamonds Are Forever (1971)',
        'Thunderball (1965)',
        'Live and Let Die (1973)',
        'Die Another Day (2002)',
        'Quantum of Solace (2008)',
        'World Is Not Enough, The (1999)',
        'Dr. No (1962)',
        'From Russia with Love (1963)',
        'Tomorrow Never Dies (1997)',
        'Skyfall (2012)',
        'Goldfinger (1964)',
        'GoldenEye (1995)',
        'Casino Royale (2006)',

        'Never Say Never Again (1983)',
        'Spy Who Loved Me, The (1977)',
        'Moonraker (1979)',
    ]

    TITLES_MARVEL_ALL = [
        'Iron Man 3 (2013)',
        'Iron Man 2 (2010)',
        'Iron Man (2008)',
        'Hulk (2003)',
        'Incredible Hulk, The (2008)',
        'Thor: The Dark World (2013)',
        'Thor: Ragnarok (2017)',
        'Thor (2011)',
        'Captain America: Civil War (2016)',
        'Captain America: The First Avenger (2011)',
        'Captain America: The Winter Soldier (2014)',
        'Guardians of the Galaxy 2 (2017)',
        'Guardians of the Galaxy (2014)',
        'Avengers, The (1998)',
        'Avengers: Infinity War - Part II (2019)',
        'Avengers: Infinity War - Part I (2018)',
        'Avengers: Age of Ultron (2015)',
        'Avengers, The (2012)',
        'Ant-Man and the Wasp (2018)',
        'Ant-Man (2015)',
        'Doctor Strange (2016)',

        'Spider-Man: Far from Home (2019)',
        'The Amazing Spider-Man 2 (2014)',
        'Spider-Man: Into the Spider-Verse (2018)',
        'Spider-Man 3 (2007)',
        'Untitled Spider-Man Reboot (2017)',
        'Amazing Spider-Man, The (2012)',
        'Spider-Man 2 (2004)',
        'Spider-Man (2002)',
        'Black Panther (2017)',
        'Captain Marvel (2018)'
    ]

    TITLES_MARVEL_RANDOM_15 = random.Random(13).sample(TITLES_MARVEL_ALL, 15)

    TITLES_MARVEL_RANDOM_10 = random.Random(13).sample(TITLES_MARVEL_ALL, 10)

    TITLES_MARVEL_RANDOM_5 = random.Random(13).sample(TITLES_MARVEL_ALL, 5)


def unique(l):
    result = []
    for i in l:
        if i not in result:
            result.append(i)
    return result


def split_kwargs_by(dictionary, keys):
    """
    dictionary {a=[1,2,3], b=[5,6]} when keys=['a', 'b'] returns [{a=[1],b=[5]},{a=[2],b=[5]}...]
    """
    columns = [dictionary[k] for k in keys]
    split_list = list(itertools.product(*columns))
    ret = []
    for t in split_list:
        d = dictionary.copy()
        for k, v in zip(keys, t):
            d[k] = [v]
        ret.append(d)
    return ret


def convert_metric4paper(metric_col):
    if metric_col == 'query_rank':
        return 'query rank'
    if metric_col == 'p2p_diversity':
        return 'point to point'


def convert_rule4paper(rule):
    if '_' in rule:
        rule, p = rule.split('_')
        return f"${p}$-{rule}"
    else:
        return rule


def canonicalTitle(title):
    title = title.str.lower()
    title = title.str.replace(' ii', ' 2')
    for c in ' !@#$%^&*():"|;\'",./?><`~_+=-':
        title = title.str.replace(c, '', regex=False)

    return title


def print_progress(i, n, fraction=0.1, show_fn=lambda i: str(i)):
    part = max(1, int(fraction * n))
    if i % part == 0:
        print(f'processing {show_fn(i)} [{i}/{n} - {100.0 * i / n:.2}%]')


class RandFreq:
    """
    Given weight per index provide a `choice` func, which draws indices randomly (based on weights)
    e.g. for `weights=[1,2]: index 0 probability = .33%, index 1 probability = .66%
    """

    def __init__(self, weights, units=1000):
        self.cache = []
        weights_sum = float(sum(weights))
        weights_scaled = map(lambda w: int(units * w / weights_sum), weights)

        for ix, w in enumerate(weights_scaled):
            for i in range(w):
                self.cache.append(ix)

        self.cache_size = len(self.cache)

    def next(self):
        return self.cache[random.randrange(self.cache_size)]

    def choice(self, choices):
        return choices[self.next()]

    @staticmethod
    def create_linear(n):
        weights = [n - i for i in range(n)]
        return RandFreq(weights)


class dotdict(dict):
    """
    dot.notation access to dictionary attributes
    """
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    def copy(self):
        return dotdict(dict(self))

    def deepcopy(self):
        return dotdict(copy.deepcopy(dict(self)))


abc_rules = ['seqphragmen', 'seqcc', 'seqpav', 'seqslav', 'rule-x']


# 'revseqpav' is excluded, as it 'removes' the candidates starting with the full set of 17k candidates, so it takes a long time
def filter_abc_rules(rules, idf_name):
    denylist = abc_rules
    if idf_name == 'IDF_1':
        return rules
    else:
        print(f'filtering out rules from the denylist for idf: {idf_name}: {denylist}')
        return [rule for rule in rules if rule not in denylist]


def search_term2re(t):
    return "^" + t.replace('(', '.').replace(')', '.').replace('?', '.').replace('*', '.') + '$'


def search_terms2re(terms):
    return [search_term2re(term) for term in terms]


def product_re2sql_like(product_re):
    sql_like = product_re
    sql_like = sql_like[1:] if sql_like[0] == '^' else sql_like
    sql_like = sql_like[:-1] if sql_like[-1] == '$' else sql_like
    sql_like = sql_like.replace('.', '_')
    return sql_like


def product_re2display(product_re):
    import re
    product_re = product_re[1:] if product_re[0] == '^' else product_re
    product_re = product_re[:-1] if product_re[-1] == '$' else product_re
    # replace date
    product_re = re.sub(r'.(\d{4}).', r'(\1)', product_re)
    return product_re


def parse_year_sterm(sterm, default_year):
    matches = re.search(r'\((\d{4})\)', sterm)
    return int(matches[1]) if matches else default_year


def str_hash(str_params):
    hash_str = hashlib.md5(str(str_params).encode('utf-8')).digest()
    hash_str = base64.b64encode(hash_str, altchars=b'__').decode('utf-8')
    return hash_str


def params_hash(params):
    return str_hash(str(params))[:10]


def params2filename(params):
    return f'.{str_params(params, values_limit=None)}_{params_hash(params)}'


def strings_to_res(texts):
    return [string_to_re(t) for t in texts]


def string_to_re(text):
    return text.replace('(', '.').replace(')', '.').replace('_', '.').replace("'", '.')


def full_titles_to_res(titles):
    return [full_title_to_re(x) for x in titles]


def full_title_to_re(title):
    return f"^{string_to_re(title)}$"


def strings_to_sqlres(texts):
    return [string_to_sqlre(t) for t in texts]


def string_to_sqlre(text):
    text = text.strip()
    text = text[1:] if text[0] == "^" else "%" + text
    text = text[:-1] if text[-1] == "$" else text + "%"
    return text.replace('(', '_').replace(')', '_').replace('.', '_').replace("'", '_')


def str_replace(s, replace_dict):
    for to_find, to_replace in replace_dict.items():
        for c in to_find:
            s = s.replace(c, to_replace)
    return s


def str_params(params_dict, values_limit=None):
    values_limit = 10000 if values_limit is None else values_limit
    params_dict = {k: f"({str(v)[:values_limit]})" for k, v in params_dict.items()}
    return str_replace(str(params_dict), {"{}' ": "", ":": "", "*/?,": "."})[:200]


@contextlib.contextmanager
def time_log(name, verbose=1):
    start = datetime.now()
    if verbose > 1:
        print(f"Starting >> {name} <<                    @ {start}")
    yield name
    stop = datetime.now()
    if verbose > 0:
        print(f"Finished >> {name} << in {stop - start} @ {stop}.")


def log_experiment(out_folder, text, append_mode='a+'):
    text = text if text is str else pp.pformat(text)
    text = text if text[-1] == '\n' else text + '\n'
    with open(f"{out_folder}/experiment-info.txt", append_mode) as f:
        f.write(text)


def experiment_out_folder(params, exp_folder):
    run_name = params['run'] if 'run' in params else "classic"
    target_run = params['target']
    return f"out/{target_run}/{exp_folder}/{run_name}"


def grid_plot(data_df, col_name, row_name, plot_func, aspect=1.0, font_size=7, legend_ncol=1, legend_nrow=3,
              title_prefixes=None):
    col_values = unique(data_df[col_name].tolist())
    row_values = unique(data_df[row_name].tolist())
    nrows = len(row_values)
    ncols = len(col_values)
    plt.rcParams.update({'font.size': font_size})

    hcell = 2
    wcell = hcell * aspect

    htext = font_size / 25
    hlegend = htext * legend_nrow
    wspace = wcell / 10
    hspace = hcell / 10 + htext
    hframe = wcell / 10

    wfig = hframe + htext + (ncols * wcell) + (ncols - 1) * wspace + hframe
    hfig = hframe + hlegend + (nrows * hcell) + (nrows - 1) * (hspace) + hframe
    figsize = (wfig, hfig)

    grid_fig, axs = plt.subplots(figsize=figsize, nrows=nrows, ncols=ncols, squeeze=False)
    for rowix, row_value in enumerate(row_values):
        print(f"({rowix})", row_value)
        for colix, col_value in enumerate(col_values):
            is_last_row = rowix == nrows - 1
            is_col_central_even = ncols % 2 == 0 and colix == ncols / 2 - 1
            is_col_central_odd = ncols % 2 == 1 and colix == int(ncols / 2)

            df = data_df.query(f"{col_name}==@col_value and {row_name}==@row_value")
            cur_ax = axs[rowix][colix]
            f = plot_func(df,
                          ax=cur_ax,
                          legend=is_last_row and (is_col_central_even or is_col_central_odd),
                          )

            sns.despine(left=True, bottom=True)

            col_prefix, row_prefix = ["", ""] if title_prefixes is None else title_prefixes
            title = " | ".join(x for x in [
                f"{col_prefix}{col_value}" if col_name is not None else None,
                f"{row_prefix}{row_value}" if row_name is not None else None
            ] if x is not None)
            f.set_title(title)

            # add a legend centrally
            if is_last_row:
                hanchor = - (hspace) / hcell
                if is_col_central_even:
                    f.legend(loc='upper center', bbox_to_anchor=(1, hanchor), ncol=legend_ncol)
                elif is_col_central_odd:
                    f.legend(loc='upper center', bbox_to_anchor=(0.5, hanchor), ncol=legend_ncol)
            else:
                f.set(xlabel=None)
                # f.set(xticklabels=[])

            if colix > 0:
                f.set(ylabel=None)
                f.set(yticklabels=[])

    grid_fig.subplots_adjust(left=(hframe + htext) / wfig, right=(wfig - hframe) / wfig,
                             top=(hfig - hframe - htext) / hfig, bottom=(hlegend + hframe) / hfig,
                             wspace=wspace / wcell, hspace=hspace / hcell)

    return grid_fig
