import time
from typing import List, Dict


# implementation of the OWA ILP from: https://arxiv.org/pdf/1402.3044.pdf (Theorem 11)
class OwaILP1(object):

    def __init__(self, m, k, pref_profile: List[Dict[int, float]], owa_vector: List[float], verbose=0):
        """

        :param m: the count of resources
        :param k: the committee size
        :param pref_profile: a dictionary of resource-0-based-index to utility
        :param owa_vector: owa vector
        :param verbose:
        """
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        self.k = k
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.last_timestamp = time.time()

    def run(self):
        import gurobipy as gp
        from gurobipy import GRB

        try:
            n, m, K = self.n, self.m, self.k
            pref_profile = self.pref_profile
            owa = self.owa_vector

            # Create a new model
            model = gp.Model("utOWA")

            x = model.addMVar((m,), vtype=GRB.BINARY, name="x")
            y = model.addMVar((n, m, K), vtype=GRB.BINARY, name="y")

            # # Set objective
            values = (owa[k] * pref_profile[i][j] * y[i, j, k]
                      for i in range(n)
                      for j in range(m)
                      for k in range(K)
                      if j in pref_profile[i]
                      )
            model.setObjective(sum(values), GRB.MAXIMIZE)
            #
            # a)
            model.addConstr(sum(x[:]) == K, "committee_size_is_K")

            # b)
            for i in range(n):
                for j in range(m):  # !!!! paper has it as range(K)
                    for k in range(K):
                        model.addConstr(y[i, j, k] <= x[j], "committee_selector")
            #
            # c)
            for i in range(n):
                for k in range(K):
                    model.addConstr(y[i, :, k].sum() == 1, "agent_has_single_candidate_on_each_position")

            # d)
            for i in range(n):
                for j in range(m):
                    model.addConstr(y[i, j, :].sum() <= 1, "agent_utility_is_unique")  # !!!! paper has it == 1

            # e)
            for i in range(n):
                for k in range(K - 1):
                    model.addConstr(y[i, :, k].sum() >= y[i, :, k + 1].sum(), "utilities_are_sorted_for_agent")

            # Optimize model
            model.optimize()
            committee = [ix for ix, v in enumerate(x.X) if round(v) == 1]
            committee_score = model.ObjVal

            if self.verbose > 1:
                print("-------- Committe,  Score", committee, committee_score)

            model.terminate()

        except gp.GurobiError as e:
            print('Gurobi Error ' + str(e))
            raise

        except AttributeError:
            print('Encountered an attribute error')
            raise

        return committee, committee_score

    def score(self, committee):
        score = 0.0
        for voter in self.pref_profile:
            utilities = sorted([voter[cix] for cix in committee if cix in voter], reverse=True)
            for utility, owa in zip(utilities, self.owa_vector):
                score += utility * owa
        return score
