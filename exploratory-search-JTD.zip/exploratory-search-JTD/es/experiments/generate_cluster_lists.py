import pandas as pd

import data_config
from data.movielens_data import MovielensData
from elections import InstacartDataFrames
from electionutils import ElectionUtils
from utils import MovielensUtils
import math


def load_dataset(
        dataset,
        min_popularity  # only movies with at least
):
    idata = MovielensData(dataset)
    dataset_iframes = InstacartDataFrames.from_data(idata, min_popularity=min_popularity)
    dataset_utils = ElectionUtils(dataset_iframes, db_filename=":memory:")
    return idata, dataset_iframes, dataset_utils


def save_cluster_tables(dataset, cluster_dict, page_limit=49):
    _, _, dataset_utils = load_dataset(dataset, min_popularity=20)

    items = []
    for code, titles in cluster_dict.items():
        for title in titles:
            titles_search = title.replace("'", "_").replace("(", "_").replace(")", "_")
            df_found = dataset_utils.db.query(f"select * from product where product_name like '{titles_search}'")
            assert len(df_found) == 1, f"{title}: {df_found}"
            items.append(
                dict(code=code, title=title.replace('&', ' and '), approvals=int(df_found.order_count.values[0])))

    df = pd.DataFrame(items).sort_values(by=['code', 'approvals']).reset_index(drop=True)

    print(dataset)
    print("---------------- \\")

    contents = []
    last_cluster = df.code.values[0]
    for x in df.itertuples():
        if last_cluster != x.code:
            last_cluster = x.code
            contents.append('\midrule[0.1pt] \n')
        contents.append(f"{x.code} & {x.title} & {x.approvals} \\\\ \n")

    dataset_codename = 'movielens' if 'movielens' in dataset else 'goodbooks'
    for i in range(int(math.ceil(len(contents) / page_limit))):
        page_lines = contents[i * page_limit:min(len(contents), (i + 1) * page_limit)]

        with open(f"../../out/prod/clusters-{dataset_codename}{i + 1}.tex", "w") as f:
            f.write("".join(page_lines))

        print(f"Saved to: tex file")
        print(page_lines[:2])
        print("...")
        print("---------------- //")


if __name__ == "__main__":

    save_cluster_tables(
        dataset=data_config.data_movielens_25m,
        cluster_dict={
            'Indiana Jones': MovielensUtils.TITLES_INDIANA_ALL,
            'James Bond': MovielensUtils.TITLES_JAMES_BOND_ALL,
            'Marvel': MovielensUtils.TITLES_MARVEL_ALL,
            'Star Trek': MovielensUtils.TITLES_STAR_TREK_ALL,
            'Star Wars': MovielensUtils.TITLES_STAR_WARS_ALL,
            'Classic': MovielensUtils.TITLES_CLASSIC,
        })
