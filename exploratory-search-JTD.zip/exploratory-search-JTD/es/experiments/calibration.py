import sys

import numpy as np
from matplotlib import pyplot as plt

sys.path.insert(0, '/Users/gregaw/code/ddr/esearch/es')
print(sys.path)

import random

import seaborn as sns
from pandasql import sqldf

import es.data_config
import es.utils
import utils
from utils import MovielensUtils
from elections import InstacartDataFrames
from electionutils import ElectionUtils
from es.data.movielens_data import *
from es.metrics import *

pysqldf = lambda q, df: sqldf(q, dict(tmp=df))
os.makedirs("exp_results/calibration", exist_ok=True)


# ## Calculate the metrics for a product_RE


def get_out_folder(target, flavour, folder='calibration'):
    source_flavour = flavour.split('_')
    if len(source_flavour) > 1:
        folder = f"calibration_{source_flavour[0]}"

    return f"../../out/{target}/{folder}/{flavour}"


def metric_converter(m):
    if 'tf' in m:
        return f"$TFIDF(\gamma$={m[2:5].replace('_', '.')})"
    elif 'bm' in m:
        components = [c.replace('_', '.') for c in m.split('__')]
        return f"$BM25(k={components[1]}, b={components[2]})$"
    else:
        return m


def plot_top10counts(metric, metric_df, xticks, title, xlabel, fig_folder=None):
    if len(metric_df) == 0:
        return
    sorted_metric_df = metric_df.sort_values(['metric', 'title_tf'])
    g = sns.catplot(x="metric", y="top10count",
                    hue="title_tf",
                    col='dataset',
                    # palette=sns.cubehelix_palette(start=0.5, rot=0.8, dark=.0, light=.9, n_colors=15),
                    palette=sns.cubehelix_palette(n_colors=(len(sorted_metric_df.title_tf.unique())), dark=.2, light=.8),
                    #                     palette=sns.color_palette("light:b", 15),
                    #                     palette=sns.color_palette("bright", 15),
                    #             markers=["^", "o"], linestyles=["--", "-"],
                    kind="strip", data=sorted_metric_df, aspect=2,
                    legend=True,
                    s=8,
                    #                     dodge=True,
                    jitter=True,
                    alpha=0.8
                    )
    (g.set_axis_labels(xlabel, "count of cluster movies\nin the top 10")
     .set_xticklabels(labels=xticks)
     #       .set_yticklabels(range(0,11))
     .set_titles(title)
     #   .set_titles("{col_name} {col_var}")
     #   .set(ylim=(0, 1))
     .despine(offset=10)
     )
    g._legend.set_title("approvals")
    plt.xticks(rotation=90)

    if fig_folder is not None:
        fig_filename = f"{fig_folder}/calib_top10_{metric}.png"
        print(f"Saving balance figure to '{fig_filename}'")
        g.savefig(fig_filename, dpi=300)


def calibrate(dataset, min_popularity, titles, metrics_list, flavour, seed=None, target="test", verbose=0, **kwargs):
    if seed is not None:
        random.seed(seed)
    out_folder = get_out_folder(target, flavour)
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)

    if os.path.exists(f"{out_folder}/top10count.csv"):
        print("calibration results found - skipping")
        return

    rows = []
    if 'movielens' in dataset:
        idata = MovielensData(dataset, verbose=verbose)
    else:
        raise Exception(f'Unknown datatype: {dataset}')
    dataset_iframes = InstacartDataFrames.from_data(idata,
                                                    min_popularity=min_popularity,
                                                    verbose=verbose)
    dataset_utils = ElectionUtils(dataset_iframes)

    title_ids = set()
    for title in titles:
        title_ids |= set(
            dataset_utils.find_products(utils.search_term2re(title), min_order_count=1)['product_id'].tolist())

    def committee_change_count(df):
        return len(set(df['product_id'].tolist()) & title_ids)

    # df_results=[]
    for title in titles:
        movies_df = dataset_utils.find_products(title, min_order_count=1)
        #         print(f"processing {movies_df}")
        found_df = dataset_utils.calc_found_df(movies_df, metrics_list=metrics_list)
        for m in metrics_list:
            metric = Metric.from_dict(m).get_name()
            df = found_df.sort_values(metric, ascending=False)
            title_tf = df.tf.max()
            df = df[:10]
            # df['search_title'] = title
            # df['metric'] = metric
            # df_results.append(df)
            row = dict(title=title + f" (tf={title_tf})", dataset=dataset[-4:], metric=metric,
                       top10count=committee_change_count(df), title_tf=title_tf)
            rows.append(row)

    # pd.concat(df_results).to_csv(f"{out_folder}/calib_metric_details.csv", index=False)

    df = pd.DataFrame(rows)

    # Calibration visualisation
    df['title_notf'] = df.title.apply(lambda x: x.split('.')[0])

    df.to_csv(f"{out_folder}/top10count.csv")


def visualise(target, flavour, dataset, min_popularity, titles, metric_kind, metrics_list, base_metric_list,
              ghostfig_titles=None, verbose=0):
    out_folder = get_out_folder(target, flavour)
    df = pd.read_csv(f"{out_folder}/top10count.csv")
    #     new_labels = [t for t in pysqldf("select title from tmp group by title_tf, title", metric_df).title]
    #     for t, l in zip(g._legend.texts, new_labels): t.set_text(l)

    dataset_iframes = InstacartDataFrames.from_data(MovielensData(dataset, verbose=verbose),
                                                    min_popularity=min_popularity, verbose=verbose)
    dataset_utils = ElectionUtils(dataset_iframes)

    title_ids = set()
    for title in titles:
        title_ids |= set(dataset_utils.find_products(title, min_order_count=1)['product_id'].tolist())

    sns.set_theme(style="white",
                  font_scale=1.5,
                  # palette=palette,
                  context='notebook')
    # sns.set(font_scale=1.4, style='white')

    plot_top10counts(
        metric='tfidf',
        metric_df=df,
        xticks=base_metric_list,
        title="TFIDF $\gamma$ calibration",
        xlabel="$\gamma$",
        fig_folder=get_out_folder(target, flavour)
    )

    # ### Star Trek test ^^:
    # The higher the line across the movies the better the metric.
    #
    # - for each dataset (x axis)
    # - take a star trek movie (one graph per movie),
    # - reduce the elections to search for it,
    #     - calculate various metrics (`hues` on the graph)
    # - find the top10 movies according to the metric
    # - calculate the count of other Star Trek movies in these top 10 (y axis - `top10count`)

    # df['gamma'] = df.metric.apply(lambda x: float(x[2:5].replace("_", ".")) if 'tf' in x else None)
    # df['b'] = df.metric.apply(lambda x: float(x[6:10].replace("_", ".")) if 'bm' in x else None)
    # df['k'] = df.metric.apply(lambda x: float(x[12:15].replace("_", ".")) if 'bm' in x else None)

    # The calibration average values

    calib_top10_avg_df = pysqldf(
        "select metric, avg(top10count) from tmp group by metric order by metric asc", df)
    calib_top10_avg_df.to_csv(f"{out_folder}/calib_top10_{metric_kind}_avg.csv")

    title_approvals_df = pysqldf("select distinct title_notf Movie, title_tf 'Approvals' from tmp order by title_tf",
                                 df)
    title_approvals_df.to_csv(f"{out_folder}/title_approvals.csv")

    dataset_utils.products_tf_metric_grid(
        utils.search_terms2re(ghostfig_titles),
        ['TF'],
        metrics_list=[m for m in metrics_list if m['base'] in [1.2, 1.6, 2.0, 2.4, 2.8]],
        metric_converter=metric_converter,
        metric_kind=metric_kind,
        out_folder=out_folder,
        title_ids_to_highlight=title_ids
    )


def calibration(target, flavour, titles, dataset, ghostfig_titles=None):
    print(f"Running CALIBRATION experiment")

    # for k in [300]:
    #     # for k in [100, 200, 300, 400, 500, 600]:
    #     metric_kind = f"bm25k={k}"
    #     base_metric_list = [round(0.0 + x * .1, 1) for x in range(11)]
    #     calibrate(metric_kind,
    #               dataset,
    #               min_popularity=min_popularity,
    #               titles=titles,
    #               metrics_list=[dict(kind='bm25', k=k, base=b, b=b) for b in base_metric_list],
    #               base_to_show=[0.0 + x * .1 for x in range(0, 11, 2)],
    #               plot_top10counts_func=lambda metrics_df: plot_top10counts(
    #                   metric_kind, metrics_df, base_metric_list,
    #                   f"BM25(k={k}) $b$ calibration", "$b$",
    #                   fig_folder=get_out_folder(target, flavour)),
    #               seed=random_seed,
    #               target=target,
    #               flavour=flavour
    #               )

    verbose = 0
    base_metric_list = [round(1.1 + x * .05, 2) for x in range(35)]
    calib_params = dict(
        target=target,
        flavour=flavour,
        dataset=dataset,
        min_popularity=20,
        titles=utils.strings_to_res(titles),
        metric_kind='tfidf',
        metrics_list=[dict(kind='tfxtoidf', base=base) for base in base_metric_list],
        base_metric_list=base_metric_list,
        ghostfig_titles=ghostfig_titles,
    )

    calibrate(**calib_params)

    visualise(**calib_params)

    out_folder = get_out_folder(target, flavour)
    calib_all_folder = f"{out_folder}"[:out_folder.rfind('/')]
    summarise_all_flavours(calib_all_folder)


def summarise_all_flavours(calib_all_folder):
    import os

    sns.set_theme(style="whitegrid", palette="bright", font_scale=1.4, context='notebook')

    flavour_folders = {flavour: f"{calib_all_folder}/{flavour}" for flavour in os.listdir(calib_all_folder)}
    df_all = None
    for flavour, folder in flavour_folders.items():
        if '.DS_Store' not in folder and os.path.isdir(folder):
            df = pd.read_csv(f"{folder}/top10count.csv")
            flavour_titles_count = len(set(df['title'].tolist()))
            df['flavour'] = flavour
            # top10pct
            df['top10pct'] = df['top10count'] / min(10, flavour_titles_count)
            df['gamma'] = df['metric'].apply(
                lambda x: float(x.replace('tf', "").replace('toidf', '').replace('_', '.')))
            df_all = pd.concat([df_all, df]) if df_all is not None else df

    def generate_tex(gamma2avg_list):
        tex_contents = ""
        max_avg = max(avg for _, avg in gamma2avg_list)
        for gamma, average in gamma2avg_list:
            if 1.65 <= gamma <= 2.3:
                avg_tex = "\\textbf{" + str(average) + "}" if average == max_avg else average
                tex_contents += f"{gamma} & {avg_tex} \\\\ \n"
        return tex_contents

    for avg_kind in [
        'top10count',
        # 'top10pct'
    ]:
        results_df = pysqldf(f"select gamma, avg({avg_kind}) from tmp group by metric", df_all).sort_values('gamma')
        results_df.to_csv(f"{calib_all_folder}/calib_total_{avg_kind}_avg.tsv", index=False, sep='\t')

        tex_contents = generate_tex([(row.gamma, round(row[2], 2)) for row in results_df.itertuples()])
        with open(f"{calib_all_folder}/calib_total_{avg_kind}_avg.tex", 'w') as f:
            f.write(tex_contents)

        f = sns.relplot(data=results_df, x='gamma', y=f'avg({avg_kind})', kind='line', aspect=1.5)
        sns.despine(left=True, bottom=True)
        f.set_titles("")
        f.set_xlabels("$\gamma$")
        f.set_ylabels("average number of movies \n from a given cluster among top 10")
        f.savefig(f"{calib_all_folder}/calib_total_{avg_kind}_avg.png", dpi=300)

        results_df = pysqldf(f"select flavour, gamma, avg({avg_kind}) from tmp group by flavour, metric",
                             df_all).sort_values(['flavour', 'gamma'])
        results_df.to_csv(f"{calib_all_folder}/calib_flavours_{avg_kind}_avg.tsv", index=False, sep='\t')
        for flavour in set(results_df.flavour.tolist()):
            tex_contents = generate_tex(
                [(row.gamma, round(row[3], 2)) for row in results_df.query(f"flavour == '{flavour}'").itertuples()])
            with open(f"{calib_all_folder}/{flavour}/calib_top10_tfidf_avg.tex", 'w') as f:
                f.write(tex_contents)

        cluster_labels = dict(
            anne='Anne', divergent='Divergent', five='Famous Five', hunger='Hunger Games', narnia='Narnia', potter='Harry Potter',
            indiana='Indiana Jones', jamesbond='James Bond', marvel='Marvel', startrek='Star Trek'
        )
        results_df['cluster'] = results_df.flavour.apply(lambda x: cluster_labels[x[3:] if x[:3] == 'gr_' else x])

        f = sns.relplot(data=results_df, x='gamma', y=f'avg({avg_kind})', hue='cluster', style='cluster', kind='line',
                        aspect=1.5)
        sns.despine(left=True, bottom=True)
        # gf.set_title("")
        f.set_xlabels("$\gamma$")
        f.set_ylabels("average number of movies \n from a given cluster among top 10")
        out_path = f"{calib_all_folder}/calib_flavours_{avg_kind}_avg.png"
        f.savefig(out_path, dpi=300)
        print(f"Saved to {out_path}.")


if __name__ == '__main__':
    for flavour, flavour_params in dict(
            startrek=dict(
                dataset=es.data_config.data_movielens_25m,
                titles=MovielensUtils.TITLES_STAR_TREK_ALL,
                ghostfig_titles=MovielensUtils.TITLES_STAR_TREK_ALL
                # [
                #     'Star Trek III: The Search for Spock (1984)',  # for GAIW
                #     'Star Trek: Renegades (2015)'  # for GAIW
                # ],
            ),
            indiana=dict(
                dataset=es.data_config.data_movielens_25m,
                titles=MovielensUtils.TITLES_INDIANA_ALL,
                ghostfig_titles=MovielensUtils.TITLES_INDIANA_ALL
            ),
            jamesbond=dict(
                dataset=es.data_config.data_movielens_25m,
                titles=MovielensUtils.TITLES_JAMES_BOND_ALL,
                ghostfig_titles=MovielensUtils.TITLES_JAMES_BOND_ALL
            ),
            marvel=dict(
                titles=MovielensUtils.TITLES_MARVEL_ALL,
                ghostfig_titles=MovielensUtils.TITLES_MARVEL_ALL,
                dataset=es.data_config.data_movielens_25m,
            ),


    ).items():
        base_metric_list = [round(1.1 + x * .05, 2) for x in range(35)]
        calib_params = dict(
            target='prod',
            flavour=flavour,
            dataset=flavour_params['dataset'],
            min_popularity=20,
            titles=utils.strings_to_res(flavour_params['titles']),
            ghostfig_titles=flavour_params['titles'],
            metric_kind='tfidf',
            metrics_list=[dict(kind='tfxtoidf', base=base) for base in base_metric_list],
            base_metric_list=base_metric_list,
        )

        visualise(**calib_params)

        # summarise_all_flavours(get_out_folder(calib_params['target'], "", folder='calibration_gr' if 'gr_' in flavour else 'calibration'))
