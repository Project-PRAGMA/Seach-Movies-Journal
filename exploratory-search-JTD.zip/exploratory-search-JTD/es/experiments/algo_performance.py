import os
import time

import pandas as pd
from matplotlib import pyplot as plt
from pandasql import sqldf

import data_config
import es.elections
from es.data.movielens_data import MovielensData
from es.elections import InstacartDataFrames
from es.electionutils import ElectionUtils
from es.runner.scenario_runner import ScenarioRunner
from es.scorers import AgentSpreadScoringStrategy
from es.utils import dotdict
from es.utils import search_term2re

pysqldf = lambda q, df: sqldf(q, dict(tmp=df))

AQ_BASIC = "basic"
AQ_ILP = "with_ilp"

APERF_TIMINGS_CSV = "aperf-timings.csv"


def get_out_folder(target, flavour):
    return f"../../out/{target}/algo_performance/{flavour}"


def experiment_algo_performance(calc_params, output_base_folder):
    if not os.path.exists(output_base_folder):
        os.makedirs(output_base_folder, exist_ok=False)

    idata = MovielensData(calc_params["dataset"])
    iframes = InstacartDataFrames.from_data(idata, min_popularity=None)

    print(calc_params)
    start = time.time()
    runner = ScenarioRunner(iframes, calc_params)
    _ = runner.run(return_df=True, verbose=0, output_base_folder=output_base_folder,
                   include_unity=False)
    timing = time.time() - start

    print(f"TIMING: elections took: {timing}")

    return timing


def gen_algo_rules(algos, rules):
    return [f'{algo}.{r}' for r in rules for algo in algos]


def run_algo_performance(target,
                         flavour,
                         iterations_count,
                         algos,
                         rules,
                         seed,
                         titles,
                         stop_after_searches=None,
                         dataset=data_config.data_movielens_25m,
                         custom_params=None,
                         ):
    out_folder = get_out_folder(target, flavour)
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)

    idata = es.data.movielens_data.MovielensData(dataset)
    iframes = es.elections.InstacartDataFrames.from_data(idata)

    sample_orders = custom_params['filtering']['sample_orders']
    sample_products = custom_params['filtering']['sample_products']

    if sample_orders or sample_products:
        # sample new iframes and make the process use it
        iframes.sample(
            n_orders=sample_orders,
            n_products=sample_products,
            random_state=seed,
            inplace=True
        )
        dataset = f"{out_folder}/movielens_25m_o={sample_orders}_p={sample_products}"
        iframes.to_pq(dataset)
        #     disable the filtering down the stream
        custom_params['filtering'] = {}

    print(f"Running ALGO_PERFORMANCE experiment")

    eutils = es.electionutils.ElectionUtils(iframes)

    # titles_above10_df = eutils.product_search.query(f"order_count>{min_search_order_count}")
    # titles_sampled_df = titles_above10_df.sample(n=min(search_count, len(titles_above10_df)), random_state=seed)

    query = " or ".join([f"product_name ==  '{title}'" for title in titles])

    selected_titles_df = eutils.product_search.query(query)
    missing_titles = set(titles) - set(selected_titles_df.product_name.tolist())
    if len(missing_titles) > 0:
        most_popular_products = (iframes.df_order_products
                                     .groupby('product_id', as_index=False).count().sort_values('order_id',
                                                                                                ascending=False)
                                     .merge(iframes.df_products, on=['product_id'])[:20])
        raise Exception(f"Could not find all the requested titles, missing: '{missing_titles}'. "
                        f"Try \n{most_popular_products[['product_name', 'order_id']]}")

    selected_titles_sorted_df = selected_titles_df.sort_values('order_count', ascending=True)
    searches = [(search_term2re(product_name), order_count) for product_name, order_count in
                zip(
                    selected_titles_sorted_df.product_name.to_list(),
                    selected_titles_sorted_df.order_count.to_list()
                )
                ]

    if stop_after_searches:
        searches = searches[:stop_after_searches]

    outputs = []
    for iteration in range(iterations_count):
        for (search_term, order_count) in searches:
            for algo in algos:
                # ===========================================================
                print(f"Running {search_term} with orders {order_count}")
                PARAMS = dotdict(dict(
                    dataset=f"{dataset}",
                    rules=gen_algo_rules(algos=[algo], rules=rules),
                    exp_name=f"algo_performance_{dataset.split('/')[-1]}",
                    k=10,
                    searchterms=[search_term],
                    scorer_metrics=[
                        'tfidfto2',
                        # 'bm25'
                    ],
                    scorer_funcs=[
                        AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm,
                    ],
                    throw_on_rerun=False  # rerun is fine because we filter the already run searches
                ))

                if custom_params:
                    for k, v in custom_params.items():
                        PARAMS[k] = v

                timing = experiment_algo_performance(PARAMS, out_folder)
                outputs.append(dict(
                    iteration=iteration,
                    algo=algo,
                    search_term=search_term,
                    order_count=order_count,
                    timing=timing)
                )

                pd.DataFrame(outputs).to_csv(f"{out_folder}/{APERF_TIMINGS_CSV}", index=False)

    algo_performance_postprocess(target, flavour)


def _generate_speedup_table(df_pivot, out_folder):
    df_raw = df_pivot.copy()
    df_raw['algo_type'] = df_raw.algo.apply(lambda x: 'SA' if x[0] == 's' else 'Greedy' if x[0] == 'g' else 'ILP')

    df_enriched = df_raw.merge(df_raw.query("algo == 'g0' or algo == 'sa0'"),
                               on=['iteration', 'search_term', 'algo_type'],
                               suffixes=['', '_base'])

    df_enriched['title'] = df_enriched.search_term.apply(
        lambda x: x.replace("^", "").replace("$", "").replace(".", "")[:-5])

    df_agg = pysqldf(
        f'''
    select algo, title, order_count, avg(timing_base)/avg(timing) as speedup, avg(timing_base) as avg_timing
    from tmp
    group by algo, title, order_count
    order by order_count asc
    ''', df_enriched)

    df_pivot = df_agg.pivot(index=['title', 'order_count'], columns='algo', values='speedup')
    df_pivot.sort_values(by="order_count", inplace=True)
    for seconds_col in ['g0', 'sa0']:
        df_pivot[seconds_col] = df_agg.query(f"algo=='{seconds_col}'").avg_timing.values
    #     right order
    df_pivot = df_pivot[
        sorted([col for col in df_pivot.columns if "g" in col]) +
        sorted([col for col in df_pivot.columns if "sa" in col])
        ]

    tab_rows = []
    for ix, row in df_pivot.iterrows():
        (title, agents) = ix
        val_func = lambda row, col: f"{row[col]:.0f}" if '0' in col else f"{row[col]:.2f}"
        ar = [str(title), str(int(agents))] + [val_func(row, col) for col in df_pivot.columns]
        tab_rows.append(" & ".join(ar) + " \\\\")

    columns = ['title', 'agents'] + list(df_pivot.columns)
    layout = "rr" + "r" * len(df_pivot.columns)

    table_latex = (
            ""
            + "% \\begin{tabular}{" + layout + "} \n"
            + "% \\toprule \n"
            + "% " + " & ".join(columns) + "\\\\ \n"
            + """
            % \\midrule
            """
            + "\n".join(tab_rows)
            + """
            
            
            % \\bottomrule
            % \\end{tabular}
            % \\caption{\label{tab:algo_perf}}
                    """
    )

    with open(f"{out_folder}/aperf-speedup-table.tex", 'w+') as f:
        f.write(table_latex)


def _generate_runtime_fig(out_folder, df):
    df = df.copy()
    import seaborn as sns

    sns.set_theme(style="whitegrid", palette="bright", font_scale=1.3, context='notebook')

    df['algo_type'] = df.algo.apply(lambda x: 'SA' if x[0] == 's' else 'Greedy' if x[0] == 'g' else 'ILP')
    df['algo'] = df.algo.apply(lambda x: (x[:2]).upper()+x[2:])
    col_mapping = dict(timing='search time (sec)', order_count='approval count of query title',
                       algo_type="algorithm type",
                       algo="algorithm")
    for col, name in col_mapping.items():
        df[name] = df[col]

    # make sure we consistently scale the y axis
    min_time, max_time = df[col_mapping['timing']].min(), df[col_mapping['timing']].max()

    if 'basic' in out_folder:
        for algo_type in ['Greedy', 'SA']:
            df_to_show = df.query(f"algo_type == '{algo_type}'")
            f = sns.relplot(kind='line', data=df_to_show, x=col_mapping['order_count'], y=col_mapping['timing'],
                            style=col_mapping['algo'], hue=col_mapping['algo'],
                            # col=grid_col,
                            aspect=1,
                            markers=True,
                            ci='sd',
                            # legend=None,
                            # **style_args
                            )
            for ax in f.axes.flatten():
                ax.grid(axis='x')
                sns.despine(ax=ax, left=True)

            plt.ylim(min_time, max_time)
            f.set(yscale="log")
            f.savefig(f"{out_folder}/aperf-timings-log-{algo_type}.png", dpi=300)

    else:
        df['algorithm'] = df.algo_type
        grid_col = None
        f = sns.relplot(kind='line', data=df, x=col_mapping['order_count'], y=col_mapping['timing'],
                        style=col_mapping['algo'], hue=col_mapping['algo'],
                        col=grid_col,
                        aspect=1,
                        markers=True,
                        ci='sd',
                        # legend=None,
                        # **style_args
                        )
        for ax in f.axes.flatten():
            ax.grid(axis='x')
            sns.despine(ax=ax, left=True)

        f.set(yscale="log")
        f.savefig(f"{out_folder}/aperf-timings-log.png", dpi=300)


def algo_performance_postprocess(target, flavour, out_folder=None):
    out_folder = get_out_folder(target, flavour) if out_folder is None else out_folder

    df = pd.read_csv(f"{out_folder}/{APERF_TIMINGS_CSV}")
    # df['iteration'] = df.iteration.apply(lambda x: x+5)
    # df.to_csv(f"{out_folder}/{APERF_TIMINGS_CSV}.1", index=None)

    _generate_speedup_table(out_folder=out_folder, df_pivot=df)

    _generate_runtime_fig(out_folder=out_folder, df=df)


# uncomment to run using adhoc parameters (e.g. for debugging)

# algo_performance_postprocess('prod', 'ilp')
# algo_performance_postprocess('prod', 'basic')

# run_algo_performance(
#     target='manual',
#     flavour='basic',
#     iterations_count=1,
#     algos=['ilp'],
#     rules=['HUV_1', ],
#     seed=1451,
#     titles=[
#         #         0  Terminator 2: Judgment Day (1991)        22
#         # 1               Fugitive, The (1993)        18
#         # 2           L.A. Confidential (1997)        10
#         # 'Princess Bride, The (1987)',
#         # "Ocean.s Eleven (2001)",
#         # 'Maltese Falcon, The (1941)'
#         'Bruce Almighty (2003)',  # 11
#         'Who Framed Roger Rabbit? (1988)',  # 23
#         'Dark Knight, The (2008)'  # 47
#     ],
#     custom_params=dict(
#         anneal_settings={'tmax': 9900.0, 'tmin': 0.6, 'steps': 1000,
#                          'updates': 2},
#         k=10,
#         filtering=dict(sample_orders=200, sample_products=200)
#     ))
