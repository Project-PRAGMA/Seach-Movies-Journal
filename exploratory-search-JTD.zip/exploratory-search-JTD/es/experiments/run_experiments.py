import argparse
import os

from data_config import data_movielens_25m
from elections import ALGO_GREEDY, ALGO_SA, ALGO_ILP
from elections_raw import PrefProfile
from electionutils import ElectionUtils
from es.experiments import calibration as calibration_exp
from es.experiments.calibration import calibration
# ARGUMENTS
from experiments.algo_quality import gen_algo_rules, AQ_ILP, AQ_BASIC_1k, AQ_BASIC, AQ_ILP_sa10k
from experiments.counting_rradius_raw import PERTURB_REMOVE, PERTURB_ADD, PERTURB_SWAP, get_cached_ml_profile_path

# EXPERIMENTS
from utils import MovielensUtils


def run_experiment(target_run, out_folder, func, rerun=False):
    done_filename = f"{out_folder}/done.done"
    should_run = True
    if not os.path.exists(done_filename):
        status = f"Running a new run"
    elif rerun:
        status = f"Overwriting an existing run"
        os.remove(done_filename)
    else:
        status = f"Skipping - target already exists"
        should_run = False

    print(f"{status}, target: '{target_run}' out_folder: {out_folder}")
    if should_run:
        func()
        with open(done_filename, 'w+') as f:
            f.write('done')


if __name__ == "__main__":

    ap = argparse.ArgumentParser()
    ap.add_argument("-t", "--target", choices=['test', 'prod'], required=True, help="target")
    args = vars(ap.parse_args())
    target = args['target']

    if target == 'prod':

        election_utils = ElectionUtils.from_movielens(data_movielens_25m)
        hot_shots_path = get_cached_ml_profile_path(
            "Hot Shots! .1991.", target, 'movielens', election_utils)
        st_final_frontier_path = get_cached_ml_profile_path(
            "Star Trek V: The Final Frontier .1989.", target, 'movielens', election_utils)
        st_spock_path = get_cached_ml_profile_path(
            "Star Trek III: The Search for Spock .1984.", target, 'movielens', election_utils)
        indiana_temple_path = get_cached_ml_profile_path(
            "Indiana Jones and the Temple of Doom .1984.", target, 'movielens', election_utils)


        for flavour, flavour_params in dict(
                startrek=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_STAR_TREK_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_STAR_TREK_ALL
                    # [
                    #     'Star Trek III: The Search for Spock (1984)',  # for GAIW
                    #     'Star Trek: Renegades (2015)'  # for GAIW
                    # ],
                ),
                indiana=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_INDIANA_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_INDIANA_ALL
                ),
                jamesbond=dict(
                    dataset=data_movielens_25m,
                    titles=MovielensUtils.TITLES_JAMES_BOND_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_JAMES_BOND_ALL
                ),
                marvel=dict(
                    titles=MovielensUtils.TITLES_MARVEL_ALL,
                    ghostfig_titles=MovielensUtils.TITLES_MARVEL_ALL,
                    dataset=data_movielens_25m,
                ),


        ).items():
            run_experiment(target_run=target,
                           rerun=False,
                           out_folder=calibration_exp.get_out_folder(target, flavour),
                           func=lambda: calibration(
                               target=target,
                               flavour=flavour,
                               dataset=flavour_params['dataset'],
                               titles=flavour_params['titles'],
                               ghostfig_titles=flavour_params['ghostfig_titles']
                           ))


        run_experiment(target_run=target,
                       rerun=False,
                       out_folder=committee_spread.get_out_folder(target),
                       func=lambda: committee_spread.committee_spread(
                           target=target,
                           algo_quality_results_dir=f"../../out/{target}/algo_quality/basic_1k"
                       ))

    else:

        raise Exception(f"Unrecognised target for RUN_EXPERIMENTS: {target}")
