import pandas as pd
import numpy as np

import utils
from es.metrics import Metric
from es.runner.scenario_runner import ScenarioRunner
from es.scorers import AgentSpreadScoringStrategy
from es.utils import dotdict, log_experiment, experiment_out_folder


def _normalise_distances(distances, low, high):
    dlow = np.min(distances)
    dhigh = np.max(distances)
    return (distances - dlow) / (dhigh - dlow) * (high - low) + low


class Distances:
    def __init__(self, election_utils, dist_code=True):
        """
        :param election_utils:
        :param dist_code: 'rank' to use rank directly 'adjusted-tfidf' to use adjusted tfidf
        """
        self.dist_code = dist_code
        self.eu = election_utils
        self.db = self.eu.db

    def append_distances_from_products(self, product_ids, metric_def, replace=True, found_limit_per_product=None):
        """
        PRODUCES: dist_metric(search_product_id,rank,product_id)
        rank is a measure of distance between products (it could be the metric rank average or the metric average)
        """
        table_name = 'dist_metric'
        if not self.db:
            raise Exception(f"you must initiate the utils with a db")
        if not replace:
            if table_name in self.db.get_tables():
                existing_ids = set(self.db.query(f'select search_product_id from {table_name}').search_product_id)
                product_ids = set(product_ids).difference(existing_ids)
        print(f'product_ids to calculate distance metrics for: {len(product_ids)}')
        for ix, product_id in enumerate(product_ids):
            try:
                if ix % 10 == 1:
                    print(f'calculating {product_id}, #{ix}')
                product_id_df = pd.DataFrame([dict(product_id=product_id)])
                found_df = self.eu.calc_found_df(product_id_df, metrics_list=[metric_def], verbose=0, nosearchterm=True)
                metric = Metric.from_dict(metric_def).get_name()
                df = found_df.sort_values(metric, ascending=False)
                if found_limit_per_product is not None:
                    df = df[:found_limit_per_product]
                df['search_product_id'] = product_id
                if self.dist_code == 'rank':
                    df['rank'] = range(1, len(df) + 1)
                elif self.dist_code == 'inverse-log-tfidf':
                    # the bigger tfidf the lower the rank
                    df['rank'] = 1.0 / np.log(df[metric])
                elif self.dist_code == 'inverse-tfidf':
                    # the bigger tfidf the lower the rank
                    df['rank'] = 1.0 / df[metric]
                else:
                    raise Exception(f"Unrecognized rank_code: {self.dist_code}")
                df = df[['search_product_id', 'rank', 'product_id']]
                self.db.add_replace_table(df=df,
                                          tablename=table_name,
                                          if_exists=('replace' if ix == 0 and replace else 'append'))
            except Exception as e:
                print(f"WARN failed to calculate distance metric for: {product_id}, Error: {e}")

        print(f'done')

    def titleRE_to_id(self, title):
        # df = self.eu.find_products(title, min_order_count=1)
        title = utils.product_re2sql_like(title)
        # print(self.db.query(f"select * from product limit 10"))
        df = self.db.query(f"select product_id from product where product_name like '{title}'")
        if len(df) == 1:
            return df.product_id.iloc[0]
        else:
            raise Exception(f"found {len(df)} movies matchig title: >{title}<")

    def find_distances(self, metric_def, titleREs, top_rank_count=20, top_election_winners=10, sample_orders=None,
                       verbose=0, recalc=False, scorer_funcs=None, found_limit_per_product=None):
        """
            PRODUCES: p2p_ranks(a	b	rank_a_b	rank_b_a	avg_rank)

            found_limit_per_product - how many products to return in local elections per product
                                        (note: it limits the most distant products only)

        """
        #     search_product_ids = db.query(f'select product_id from product where order_count>{min_approvals}').product_id

        # retrieve all product ids for title REs
        search_product_ids = [self.titleRE_to_id(title) for title in titleREs]  # filter1

        # 1. PRIME THE DIST_metric TABLE with all the  distances from the search products to all
        self.append_distances_from_products(search_product_ids, metric_def, replace=True,
                                            found_limit_per_product=found_limit_per_product)

        # --------------
        # 2. ADD TOP (top_election_winners) ELECTION WINNERS
        print(f"** Retrieving election winners for: #{len(titleREs)} titles")
        skipping_ids = set()
        if recalc:
            self.db.exec("drop table if exists winners")
        else:
            if 'winners' in self.db.get_tables():
                already_calculated_ids = set(self.db.query(f"select distinct search_product_id id from winners").id)
                skipping_ids = set(search_product_ids).intersection(already_calculated_ids)

        if len(skipping_ids) > 0:
            print(f'skipping {len(skipping_ids)}: {skipping_ids}')
        for search_pid, titleRE in zip(search_product_ids, titleREs):
            if search_pid in skipping_ids:
                print(f'skipping {search_pid}: already calculated')
                continue
            run_params = dotdict(dict(
                exp_name='tmp',
                k=top_election_winners,
                searchterms=[titleRE],
                filtering=dict(sample_orders=sample_orders),
                rules=[
                    "HUV_0", "HUV_1", "HUV_2", "HUV_3",
                ],  # prefix sa. means 'use simulated annealing'
                anneal_settings={'tmax': 8100.0, 'tmin': 2.6, 'steps': 20000, 'updates': 10},
                # anneal_settings={'minutes': 0.5},
                scorer_metrics=['tfidfto2'],
                scorer_funcs=scorer_funcs if scorer_funcs is not None else [
                    AgentSpreadScoringStrategy.from_found_df_sorted_nosearchterm,
                ]
            ))

            runner = ScenarioRunner(self.eu.instacart_frames, run_params)
            winners_df = runner.run(return_df=True, verbose=verbose, include_unity=False)
            winners_df['search_product_id'] = search_pid
            self.db.add_replace_table(winners_df, 'winners', if_exists='append')

        top_election_winner_ids = set(self.db.query("select distinct product_id from winners").product_id)

        # --------------
        # 3. CALC DISTANCES (RANKS)
        print(f"** Calculating the distances for all the winners #{len(top_election_winner_ids)}")
        self.append_distances_from_products(
            product_ids=top_election_winner_ids,
            metric_def=metric_def,
            replace=False,
            found_limit_per_product=found_limit_per_product
        )

        # --------------
        # 4. ADD TOP METRIC RANKING PRODUCTS (top_rank_count)
        print(
            f"** ADD TOP METRIC RANKING PRODUCTS (top_rank_count) for #{len(top_election_winner_ids)} election winners")
        self.db.add_replace_table(pd.DataFrame([dict(id=pid) for pid in search_product_ids]), 'tmp')
        top_rank_product_ids = set(self.db.query(f"""
            select * from (select *, ROW_NUMBER () OVER (PARTITION BY search_product_id ORDER BY rank) RowNum from dist_metric)
            where RowNum<{top_rank_count}
            """).product_id)
        self.db.exec('drop table if exists tmp')

        # --------------
        # 5. CALC DISTANCES (RANKS)
        all_product_ids = top_election_winner_ids.union(top_rank_product_ids).union(search_product_ids)
        print(f"** Calculating the distances for winners and top ranked searched #{len(all_product_ids)} products")
        self.append_distances_from_products(
            product_ids=all_product_ids,
            metric_def=metric_def,
            replace=False,
            found_limit_per_product=found_limit_per_product
        )

        # print(f"** Normalising the distances (ranks) to be between {dist_low} and {dist_high}")
        #
        # dist_metric_df = self.db.query('select * from dist_metric')
        # dist_metric_df['rank'] = _normalise_distances(dist_metric_df['rank'], dist_low, dist_high)
        # self.db.add_replace_table(df=dist_metric_df, tablename='dist_metric', if_exists='replace')

        print(f"** Recalculating the p2p_ranks table for #{len(all_product_ids)} products")
        self.db.add_indices('dist_metric', ['search_product_id', 'product_id'])
        self.db.exec('drop table if exists p2p_ranks')
        self.db.exec('create table if not exists p2p_ranks as ' +
                     ' select a.product_id as id1, b.product_id as id2, '
                     '      a.rank rank_1_2, b.rank rank_2_1, (a.rank+b.rank)/2.0 avg_rank' +
                     ' from dist_metric a ' +
                     ' inner join dist_metric b on '
                     '      a.search_product_id < a.product_id and'
                     '      a.search_product_id = b.product_id and b.search_product_id = a.product_id'
                     )
        self.db.add_indices('p2p_ranks', ['id1', 'id2'])
