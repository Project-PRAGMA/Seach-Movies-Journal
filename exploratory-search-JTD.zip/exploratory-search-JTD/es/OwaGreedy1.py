import time
from collections import defaultdict, namedtuple
from typing import List, Dict

from es.algo_utils import build_resource_approving_voters, Voter


class OwaGreedy1(object):
    def __init__(self, m: int, k: int, pref_profile: List[Dict[int, float]],
                 owa_vector: List[float], verbose: int = 0):
        """
        g1 -
            when trying to add a product to the committee:
            - iterate only through the *approving* voters
            - and add a delta score to the already existing score
        :param m: the count of resources
        :param k: the committee size
        :param pref_profile: [voter_ix -> {resource_ix -> utility}]
        :param owa_vector: owa vector
        :param verbose:
        """
        self.verbose = verbose
        assert pref_profile, "profile must not be empty"
        self.n = len(pref_profile)
        self.m = m
        self.k = k
        assert len(owa_vector) >= self.k, f"owa vector must be longer than k={self.k}"
        self.pref_profile = pref_profile
        self.owa_vector = owa_vector
        self.last_timestamp = time.time()

        self.resource_ix2approving_voters = build_resource_approving_voters(self.pref_profile, m)

    # runs the algorithm, returns the winning committee and its score
    def run(self):
        committee = []  # we use a list to make sure the order is preserved
        committee_score = 0
        for member_ix in range(self.k):
            max_score = -1
            max_score_rix = -1
            for rix in range(self.m):
                if rix not in committee:
                    score = self.score(committee, rix, committee_score)
                    if score > max_score:
                        max_score_rix, max_score = rix, score
            committee.append(max_score_rix)
            committee_score = max_score
            if self.verbose > 0:
                print(f"added member #{member_ix}: {max_score_rix}, total committee score {max_score}")
        return committee, committee_score

    # returns the score of the a committee
    # by recalculating only the score for agents(voters) who approve resource `rix_added`
    def score(self, committee: List[int], rix_added: int, committee_score: float):
        new_committee = committee + [rix_added]
        old_resource_score = 0.0
        new_resource_score = 0.0
        for voter in self.get_voters_approving_resource(rix_added):
            old_resource_score += self.get_voter_score(committee, voter)
            new_resource_score += self.get_voter_score(new_committee, voter)
        return committee_score - old_resource_score + new_resource_score

    # returns the committee score of a single agent (voter)
    def get_voter_score(self, committee: List[int], voter: Voter):
        score = 0
        utilities = sorted(
            [voter.approvals[cix] for cix in committee if cix in voter.approvals],
            reverse=True
        )
        for utility, owa in zip(utilities, self.owa_vector):
            score += utility * owa
        return score

    def get_voters_approving_resource(self, rix: int):
        return self.resource_ix2approving_voters[rix]
