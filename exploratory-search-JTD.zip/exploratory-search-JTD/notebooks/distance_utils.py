import os

import matplotlib.pyplot as plt
import pandas as pd
import networkx as nx
import numpy as np
import seaborn as sns
from IPython.core.display import display
from matplotlib import pyplot

from es import utils
from sql_database import Database
from utils import MovielensUtils, convert_rule4paper
from pandasql import sqldf

pysqldf = lambda q, df: sqldf(q, dict(tmp=df))


def _pick_closest(x, sorted_values):
    for p in sorted_values:
        if p >= x:
            return p
    return 100


def to_percentile_sizes(series, k):
    percentiles = np.percentile(series, [(i + 1) * (100.0 / k) for i in range(k)])
    sizes = [round(p, 2) for p in percentiles]
    print(sizes)
    return series.apply(lambda x: _pick_closest(x, sizes)), sizes


def to_exponential_sizes(series):
    first_level = np.percentile(series, 10)
    sizes_count = int(np.log2(max(series) / first_level)) + 1
    sizes = [int(first_level * (2 ** i)) for i in range(sizes_count)]
    print(sizes)
    return series.apply(lambda x: _pick_closest(x, sizes)), sizes


def show_distances(ax, title, layout_df,
                   highlight_name2product_ids=None,
                   search_product_id=None,
                   legend='auto',
                   backgroud_dots_alpha=0.6,
                   markers='ooD',
                   max_title_len=50):
    highlight_name2product_ids = {} if highlight_name2product_ids is None else highlight_name2product_ids

    # ax.set_axis_off()
    title = title if len(title) <= max_title_len else title[:max_title_len] + "..."
    ax.set_title(title, fontdict=dict(fontsize=18))
    ax.set_yticklabels([])
    ax.set_xticklabels([])
    ax.set_yticks([])
    ax.set_xticks([])
    for _, s in ax.spines.items():
        s.set_linewidth(.5)
        s.set_color('grey')

    # distance_levels, _ = to_percentile_sizes(layout_df.distance, 5)
    # distance_levels, _ = to_exponential_sizes(layout_df.distance)
    distance_levels = layout_df.distance

    for hkey, hids in highlight_name2product_ids.items():
        sns.scatterplot(data=layout_df[layout_df.product_id.isin(hids)], x='x', y='y', ax=ax, legend=legend,
                        color='black',
                        marker=markers[1],
                        s=200,
                        facecolors='white', edgecolor='black',
                        alpha=.8)

    sns.scatterplot(data=layout_df, x='x', y='y',
                    style='main_genre',
                    hue='main_genre',
                    # size=distance_levels,
                    ax=ax, alpha=backgroud_dots_alpha, legend=legend, marker=markers[0])

    if search_product_id is not None:
        sns.scatterplot(data=layout_df[layout_df.product_id == search_product_id], x='x', y='y', ax=ax, legend=legend,
                        # color='black',
                        marker=markers[2],
                        facecolors='black', edgecolor='black'
                        )


def show_dist_interactive(df, chart_name, highlight_name2ids=None, tooltips=None):
    if tooltips is None:
        tooltips = [("name", "@product_name/@product_id[@order_count]"), ]
    highlight_name2ids = {} if highlight_name2ids is None else highlight_name2ids
    from bokeh.plotting import ColumnDataSource, figure, show
    # reset_output()
    # output_file(f"interactive_{chart_name}.html")
    # output_notebook()
    source = ColumnDataSource(df)
    p = figure(plot_width=600, plot_height=600, tooltips=tooltips,
               title=chart_name)
    p.circle('x', 'y', size=20, color='grey', line_color=None, alpha=.3, source=source)

    colors = ['yellow', 'orange', 'red', 'green']
    for hkey, hids in highlight_name2ids.items():
        huv_p = int(hkey[-1])
        p.circle('x', 'y', size=20, color=colors[huv_p], line_color='black', alpha=.6,
                 source=ColumnDataSource(df[df.product_id.isin(hids)]))
    show(p)


def show_distances2forces(df, dist2force_func_str):
    fig, axs = plt.subplots(1, 2, figsize=(10, 3))

    axs[0].set_title("distances")
    df.avg_rank.hist(alpha=0.5, ax=axs[0], bins=100)

    axs[1].set_title(f"forces: {dist2force_func_str}")
    eval(dist2force_func_str)(df.norm_dist).hist(alpha=0.5, ax=axs[1], bins=100)

    # axs[1].set_title("distances normalised")
    # df.norm_dist.hist(alpha=0.5, ax=axs[1], bins=100)


def _normalise_distances(distances, low, high):
    dlow = np.min(distances)
    dhigh = np.max(distances)
    return (distances - dlow) / (dhigh - dlow) * (high - low) + low


def build_distance_graph(dist2force_func_str, db, limit_to_id=None):
    def to_weight_tuples(query):
        df = db.query(query)
        #         df['norm_dist'] = _normalise_distances(df['avg_rank'], 0.0, 1.0)
        df['norm_dist'] = df['avg_rank']
        # show_distances2forces(df, dist2force_func_str)
        dist2force_func = eval(dist2force_func_str)
        forces_df = df.apply(lambda r: (int(r.id1), int(r.id2), dist2force_func(r.norm_dist)), axis=1)
        return forces_df.to_list()

    if limit_to_id is None:
        weight_tuples = to_weight_tuples("""select * from p2p_ranks r""")
    else:
        weight_tuples = to_weight_tuples(f"""
            with myt as (select product_id from winners where search_product_id in ({limit_to_id}) )
            select *, p1.product_name as pn1, p2.product_name as pn2 
            from p2p_ranks r 
            inner join product p1 on r.id1=p1.product_id
            inner join product p2 on r.id2=p2.product_id
            where id1 in (select product_id from myt) and id2 in (select product_id from myt)
            order by avg_rank, rank_1_2 asc
            """)
    g = nx.Graph()
    g.add_weighted_edges_from(weight_tuples)
    return g


def generate_layout_df(g, iterations, db, seed=13):
    pos = nx.spring_layout(g, weight='weight', iterations=iterations, dim=2, seed=seed)
    df = pd.DataFrame([dict(product_id=product_id, x=x, y=y) for product_id, (x, y) in pos.items()])
    db.add_replace_table(df, 'tmp_dist', index_columns=['product_id'])
    df = db.query(
        'select a.product_id, x, y, product_name, order_count, main_genre '
        'from tmp_dist a inner join product b on a.product_id = b.product_id')
    db.exec('drop table tmp_dist')
    return df


def get_winner_ids(search_term_like, rule, db):
    #     display(db.query(f"select * from winners where search_term like '%{search_term_like}%' and rule='{rule}'"))
    return db.query(
        f"select distinct product_id from winners where rank<=10 and search_term like '%{search_term_like}%' and rule='{rule}'").product_id.to_list()


def get_id_by_title(search_term, db):
    sterm_id = db.query(f"select product_id from product where product_name like '{search_term}'").product_id.tolist()
    assert len(sterm_id) == 1, f"expected 1 product with title: {search_term}, found: {len(sterm_id)}"
    return sterm_id[0]


def convert2print_rule(rule):
    # e.g. HUV_0 -> 0-HUV
    rule, p = tuple(rule.split("_"))
    return f"{p}-{rule}"


def convert2print_title(title, kind='movie'):
    if kind == 'movie':
        return title.replace("^", "").replace("$", "").split(" (")[0]
    elif kind == 'synthetic':
        return convert2print_synth_candidate(title)


def convert2print_synth_candidate(rule):
    # e.g., 2_3c10 -> 2.3(10)
    if '_' in rule and 'c' in rule and len(rule) <= 7:
        rule = rule.replace("$", "")
        major, rest = tuple(rule.split("_"))
        minor, candidate_ix = tuple(rest.split("c"))
        return f"${major}.{minor}({candidate_ix})$"
    else:
        return rule.replace("$", "").replace("^", "")


def visualise_diversity(out_folder, dataset_utils, ylim=None):
    winners_df = pd.read_csv(f"{out_folder}/winners.csv")
    query_ranks = []
    for (search_id, algo), grouped in winners_df[['search_product_id', 'rule', 'algo', 'product_id']].groupby(
            ['search_product_id', 'algo']):
        tfidf_df = dataset_utils.calc_found_df(search_df=pd.DataFrame([dict(product_id=search_id)]),
                                               sorted_by='tfidfto2', verbose=0)
        pid2rank = {pid: ix for ix, pid in enumerate(tfidf_df.product_id.tolist())}
        for rule, rule_winners in grouped.groupby(['rule']):
            winner_ranks = [pid2rank[pid] if pid in pid2rank else 100000 for pid in rule_winners.product_id.tolist()]
            query_ranks.append(dict(search_id=search_id, rule=rule, algo=algo, query_rank=np.mean(winner_ranks)))

    query_rank_df = pd.DataFrame(query_ranks)

    aggregates_df = pysqldf("select rule, algo, avg(query_rank) as 'query rank' from tmp group by rule, algo",
                            query_rank_df)
    aggregates_df.to_csv(f"{out_folder}/query-rank-average.csv", index=False)

    sns.set_theme(style="whitegrid", palette="bright", font_scale=1.2, context='notebook')

    query_rank_df['rule'] = query_rank_df.rule.apply(lambda x: convert_rule4paper(x))
    query_rank_df['query rank diversity'] = query_rank_df.query_rank
    query_rank_df['algorithm'] = query_rank_df.algo.apply(lambda x: 'Greedy' if x == 'g' else 'SA')
    f = sns.catplot(kind='point', data=query_rank_df, y='query rank diversity', x='rule')
    if ylim is not None:
        plt.ylim(ylim[0], ylim[1])
    sns.despine(left=True, bottom=True)
    f.savefig(f"{out_folder}/query-rank-average.png", dpi=300)


def get_dataset_type(dataset):
    if 'movielens' in dataset:
        return 'movielens'


def show_distances_layouts(graph_iterations, dist2force_funcs, db, all_titles, out_folder, dist_code, top_rank_count,
                           seed=13):
    title2id = {t: str(get_id_by_title(t, db)) for t in utils.strings_to_sqlres(all_titles)}

    for iterations in graph_iterations:
        for dist2force_func_str in dist2force_funcs:
            print(f"laying out: iterations #{iterations}")

            plt.tight_layout()

            #     distance_graph = build_distance_graph(limit_to_id=",".join(title2id.values()))
            distance_graph = build_distance_graph(dist2force_func_str=dist2force_func_str, db=db)
            layout_df = generate_layout_df(distance_graph, iterations=iterations, db=db, seed=seed)
            db.add_replace_table(layout_df, 'layout', index_columns=['product_id'], if_exists='replace')
            layout_df.to_csv(f"{out_folder}/layout_coordinates.csv", index=False)

            generate_distance_rule_grid(all_titles, db, out_folder, title2id)

            generate_distances_map(layout_df, title2id, out_folder, db)


def generate_distance_rule_grid(all_titles, db, out_folder, title2id):
    rules = [f'HUV_{ruleix}' for ruleix in [0, 1, 2]]
    n_cols = len(rules)
    n_rows = len(title2id)
    fig, axes = plt.subplots(figsize=(5 * n_cols, 3 * n_rows), squeeze=False, dpi=150)
    # fig.suptitle(f"Distances graph (iterations={iterations}, {dist2force_func_str})", fontsize=10, y=0.98)
    plt.subplots_adjust(hspace=.35)
    with sns.plotting_context("talk"):
        for rowix, (sterm, sterm_id) in enumerate(title2id.items()):
            print(f"Showing graph limited to winners for: '{sterm}' with id={sterm_id}")
            highlight_map = {}
            for colix, rule in enumerate(rules):
                is_last_row = rowix == len(title2id) - 1
                is_col_central_even = len(rules) % 2 == 0 and colix == len(rules) / 2 - 1
                is_col_central_odd = len(rules) % 2 == 1 and colix == int(len(rules) / 2)
                is_col_central = is_col_central_even or is_col_central_odd

                rule_winners = get_winner_ids(sterm, rule, db=db)
                highlight_map[rule] = rule_winners
                search_product_id = get_id_by_title(sterm, db=db)

                pos_df_with_rank = db.query(f"""
                        select l.*, dm.rank as distance from dist_metric dm inner join layout l on dm.product_id=l.product_id
                        where search_product_id={search_product_id}
                        UNION
                        select *, 0 from layout where product_id={search_product_id}
                        """)

                kind = 'synthetic' if 'synthetic' in out_folder else 'movie'
                if kind == 'synthetic':
                    pos_df_with_rank['product_name'] = pos_df_with_rank['product_name'].apply(
                        lambda x: convert2print_title(x, kind=kind))

                pos_df_with_rank.sort_values(by="main_genre", inplace=True)

                show_legend = len(pos_df_with_rank.main_genre.unique()) > 1

                cell_title = f"{convert2print_rule(rule)}" if not is_col_central else f"{convert2print_title(all_titles[rowix][:50], kind=kind)}\n{convert2print_rule(rule)}"

                # noinspection PyTypeChecker
                show_distances(plt.subplot(n_rows, n_cols, rowix * n_cols + colix + 1),
                               cell_title,
                               pos_df_with_rank,
                               highlight_name2product_ids={rule: rule_winners},
                               search_product_id=search_product_id,
                               legend=show_legend and is_last_row and is_col_central,
                               markers='ooD',
                               backgroud_dots_alpha=0.3
                               )

                # add a legend centrally
                if is_last_row and show_legend:
                    if is_col_central_even:
                        plt.legend(loc='upper center', bbox_to_anchor=(1, 0), ncol=4)
                    elif is_col_central_odd:
                        plt.legend(loc='upper center', bbox_to_anchor=(0.5, 0), ncol=4)
    # if target == "manual":
    #     show_dist_interactive(chart_name=f'{sterm.replace(":", "_")}-{rule}-it={iterations}',
    #                           df = layout_df, highlight_name2ids={rule: rule_winners})
    plt.savefig(f"{out_folder}/distance-grid.png", facecolor='white', transparent=False,
                bbox_inches='tight')


# JUST AN EXAMPLE
def get_product_ids_with_feature(param, db):
    return [get_id_by_title(sql_search, db)
            for sql_search in utils.strings_to_sqlres(MovielensUtils.TITLES_CLASSIC[:5])]


def _repeated_colors(sequence, palette):
    pal = sns.color_palette(palette=palette, n_colors=len(sequence))
    color_lists = [[color] * count for color, count in zip(pal, sequence)]
    return [col for l in color_lists for col in l]


def generate_distances_map(layout_df, title2id, out_folder, db, highlight_marker2product_ids=None):
    labels_dict = {}
    indiana_labels_dict = {
        'Raiders of the Lost Ark (Indiana Jones and the Raiders of the Lost Ark) (1981)': 'Raiders of the Lost Ark (1981)',
        'Indiana Jones and the Last Crusade (1989)': 'Last Crusade (1989)',
        'Indiana Jones and the Temple of Doom (1984)': 'Temple of Doom (1984)',
        'Indiana Jones and the Kingdom of the Crystal Skull (2008)': 'Kingdom of the Crystal Skull (2008)',
    }
    labels_dict.update(indiana_labels_dict)
    star_wars_label_dict = {label: label.replace("Star Wars: ", "") for label in [
        'Star Wars: Episode IV - A New Hope (1977)',
        'Star Wars: Episode V - The Empire Strikes Back (1980)',
        'Star Wars: Episode VI - Return of the Jedi (1983)',
        'Star Wars: Episode I - The Phantom Menace (1999)',
        'Star Wars: Episode III - Revenge of the Sith (2005)',
        'Star Wars: Episode II - Attack of the Clones (2002)',
        'Star Wars: Episode VII - The Force Awakens (2015)',
        'Star Wars: The Last Jedi (2017)',
        # 'Star Wars: The Clone Wars (2008)'
    ]}
    labels_dict.update(star_wars_label_dict)

    # sns.set_theme(style="whitegrid", font_scale=1.2, context='notebook')

    all_sterm_ids = [int(sterm_id) for (sterm, sterm_id) in title2id.items()]
    fig, ax = plt.subplots(1, 1, figsize=(8, 3), dpi=300)
    ax.set_yticklabels([])
    ax.set_xticklabels([])
    ax.set_yticks([])
    ax.set_xticks([])

    for _, s in ax.spines.items():
        s.set_linewidth(.5)
        s.set_color('grey')

    layout_sterms_df = pd.DataFrame(all_sterm_ids, columns=['product_id']).merge(layout_df, how='inner',
                                                                                 on='product_id')
    if 'synthetic' in out_folder:
        layout_sterms_df['product_name'] = layout_sterms_df.product_name.apply(lambda x: convert2print_synth_candidate(x))
    sterms_labels = layout_sterms_df.product_name.apply(lambda x: labels_dict[x] if x in labels_dict else x)
    year_label_list = sorted(
        [(utils.parse_year_sterm(sterm, default_year=ix), sterm) for ix, sterm in enumerate(sterms_labels)])
    year_sorted_labels = [label for (year, label) in year_label_list]

    # palette_name = 'hls'
    # palette_name = 'pastel'
    # palette_name = 'muted'
    palette_name = 'bright'

    if set(year_sorted_labels) == {'Star Trek: The Motion Picture (1979)', 'Star Trek II: The Wrath of Khan (1982)',
                                   'Star Trek III: The Search for Spock (1984)', 'Star Trek IV: The Voyage Home (1986)',
                                   'Star Trek V: The Final Frontier (1989)',
                                   'Star Trek VI: The Undiscovered Country (1991)', 'Star Trek: Generations (1994)',
                                   'Star Trek: First Contact (1996)', 'Star Trek: Insurrection (1998)',
                                   'Star Trek: Nemesis (2002)', 'Star Trek (2009)', 'Star Trek Into Darkness (2013)',
                                   'Star Trek: Renegades (2015)', 'Star Trek Beyond (2016)'}:
        palette = _repeated_colors([10, 2, 1, 1], palette=palette_name)
        palette[-1] = palette[-3]
        # palette = ['blue'] * 10 + ['green'] * 2 + ['red'] + ['green']
    elif set(year_sorted_labels) == set(star_wars_label_dict.values()):
        palette = _repeated_colors([3, 3, 2], palette=palette_name)
        # palette = ['green'] * 3 + ['red'] * 3 + ['blue'] * 2
    elif set(year_sorted_labels) == set(indiana_labels_dict.values()):
        palette = _repeated_colors([3, 1], palette=palette_name)
        # palette = ['green'] * 3 + ['red']
    elif set(year_sorted_labels) == {
        'Hot Shots! (1991)',
        'Star Trek: Generations (1994)',
        'Star Trek V: The Final Frontier (1989)',
    }:
        palette = _repeated_colors([2, 1], palette=palette_name)
        # palette = ['black'] * 2 + ['blue']
    elif (set(year_sorted_labels) == set(MovielensUtils.TITLES_MARVEL_RANDOM_10) or
          set(year_sorted_labels) == set(MovielensUtils.TITLES_MARVEL_RANDOM_5) or
          set(year_sorted_labels) == set(MovielensUtils.TITLES_MARVEL_RANDOM_15) or
          set(year_sorted_labels) == set(MovielensUtils.TITLES_MARVEL_ALL)):
        palette = build_palette_by_year(year_group_count=5, year_label_list=year_label_list, palette=palette_name)
    elif set(year_sorted_labels) == set(MovielensUtils.TITLES_JAMES_BOND_ALL):
        palette = build_palette_by_group(
            title2group={
                'GoldenEye (1995)': 0,
                'Quantum of Solace (2008)': 1,
                'Skyfall (2012)': 1,
                'Spectre (2015)': 1,
                'Casino Royale (2006)': 1,
                'Die Another Day (2002)': 2,
                'World Is Not Enough, The (1999)': 2,
                'Tomorrow Never Dies (1997)': 2,
            },
            year_label_list=year_label_list,
            palette_name=palette_name)
    elif set(year_sorted_labels) == set(MovielensUtils.TITLES_CLASSIC):
        palette = _repeated_colors([1, 1, 1, 1, 1, 1], palette=palette_name)
        palette[4] = palette[2]
    else:
        palette = sns.color_palette(palette_name, n_colors=len(year_sorted_labels))

    # highlight_marker2product_ids = {
    #     'o': get_product_ids_with_feature('actor1', db)
    # }
    # if highlight_marker2product_ids is not None:
    #     for marker, hids in highlight_marker2product_ids.items():
    #         sns.scatterplot(data=layout_df[layout_df.product_id.isin(hids)], x='x', y='y', ax=ax,
    #                         # legend=legend,
    #                         color='black',
    #                         marker=marker,
    #                         s=200,
    #                         facecolors='white', edgecolor='black',
    #                         alpha=.6)

    # fig, ax = pyplot.subplots(figsize=(6, 4))

    sns.scatterplot(data=layout_df, ax=ax,
                    x='x',
                    y='y',
                    s=20,
                    alpha=0.5
                    )
    sns.scatterplot(data=layout_sterms_df, ax=ax,
                    x='x',
                    y='y',
                    style=sterms_labels,
                    style_order=year_sorted_labels,
                    hue=sterms_labels,
                    hue_order=year_sorted_labels,
                    s=160,
                    palette=palette,
                    alpha=.9
                    )

    ax.legend(
        loc='upper center',
        bbox_to_anchor=(0.5, 0),
        ncol=2,
        fontsize=10,
    )
    plt.savefig(f"{out_folder}/distance-map.png", facecolor='white', transparent=False,
                bbox_inches='tight', dpi=300)


def build_palette_by_group(title2group, year_label_list, palette_name):
    unique_group_count = len(set(title2group.values())) + 1
    default_group_ix = unique_group_count - 1
    discrete_palette = sns.color_palette(palette_name, unique_group_count)
    palette = [discrete_palette[title2group[label]] if label in title2group else discrete_palette[default_group_ix] for
               _, label in
               year_label_list]
    return palette


def build_palette_by_year(year_group_count, year_label_list, palette='pastel'):
    min_year = min(year for year, _ in year_label_list)
    color_indices = [int((year - min_year) / year_group_count) for year, _ in year_label_list]
    discrete_palette = sns.color_palette(palette, len(set(color_indices)))
    palette = [discrete_palette[color_index] for color_index in color_indices]
    return palette
