import argparse
import os
import time
import warnings

import es.data_config
from es.utils import params2filename, experiment_out_folder, str_params, MovielensUtils

warnings.simplefilter(action='ignore', category=FutureWarning)
import papermill as pm

run_config_dict = dict(
    test={
        'runner-movielens.ipynb': [dict(sample_orders=1000)],

        'movielens-results.ipynb': [dict(
            run="classic",
            search_term="^Hot Shots! .1991.",
            sample_orders=None,
            k=10,
            min_popularity=20)
        ],

        "runner-synthetic.ipynb": [
            dict(run=run, cube_proba=cube_proba, multi_iterations=2, n_voters=1000)
            for run, cube_proba in [
                ('synthetic_probas', [.5, .1, .1, .1, .1, .025, .025, .025, .025]),  # for GAIW
                ('netflix_implied_median_probas', [0.236, 0.175, 0.141, 0.115, 0.096, 0.08, 0.065, 0.05, 0.04])
                # netflix implied - median
            ]],

        'movielens-satisfaction.ipynb': [dict(sample_orders=100,
                                              titles=['Hot Shots! (1991)', 'Star Trek: Generations (1994)'])],
        # 'movielens-StarTrek-calibration.ipynb': [dict(
        #     run="startrek", titles=['Star Trek (2009)', 'Star Trek: First Contact (1996)', ])],
        # slow - a lot is going on
        'distances-synthetic.ipynb': [dict(
            run='classic', dist_code=dist_code, layout_seed=13, dist2force_funcs=funcs,
            cube_size=3, n_levels=2, cand_size=2, n_voters=400, sample_orders=None, recalc=True, top_rank_count=1,
            graph_iterations=[10], search_terms=['0_0c1$']
        )
            for dist_code, funcs in [
                ('rank', ["lambda x: (1/(x+0.0))**2"]),
                # ('inverse-log-tfidf', ["lambda x: pow(4,(1/(x+0.0)))"]),
            ]
        ],
        'distances-movielens.ipynb': [dict(top_rank_count=1, dist_code='rank', min_popularity=20,
                                           layout_seed=13,
                                           sample_orders=1000, recalc=True,
                                           search_terms=titles,
                                           graph_iterations=[10],
                                           dataset=es.data_config.data_movielens_25m,
                                           )
                                      for run, titles in [
                                          ('classic', ['Hot Shots! (1991)'])
                                      ]
                                      ],  # slow - distance compute

    },
    prod={

        'movielens-results.ipynb': [dict(
            run="classic",
            search_term="^Hot Shots! .1991.",
            sample_orders=None,
            k=10,
            min_popularity=20)
        ],

        # 'movielens-satisfaction.ipynb': [dict(sample_orders=None,
        #                                       titles=[
        #                                           'Hot Shots! (1991)',
        #                                           'Star Trek: Generations (1994)',
        #                                           'Star Trek V: The Final Frontier .1989.',
        #                                       ])],
        #
        "runner-synthetic.ipynb": [dict(
            run=f'{str_params(dict(run=run))}',
            multi_iterations=100,
            n_voters=1000,
            rules=['HUV_0', 'HUV_1', 'HUV_2', 'HUV_3', 'sa.HUV_0', 'sa.HUV_1', 'sa.HUV_2', 'sa.HUV_3'],
            cube_proba=cube_proba
        ) for run, cube_proba in [
            ('synthetic_probas', [.5, .1, .1, .1, .1, .025, .025, .025, .025]),  # for GAIW
            ('netflix_implied_median_probas', [0.236, 0.175, 0.141, 0.115, 0.096, 0.08, 0.065, 0.05, 0.04])
            # netflix implied - median
        ]],

        'distances-synthetic.ipynb': [dict(
            run='classic',
            dist_code=dist_code,
            top_rank_count=top_rank_count,
            layout_seed=layout_seed,
            dist2force_funcs=funcs,

            cube_size=3,
            n_levels=2,
            cand_size=5,
            n_voters=1000,
            sample_orders=None,
            recalc=True,
            graph_iterations=[10000],
            search_terms=[f'{i}_{i}c{(i * 8) % 25}$' for i in range(6)]  # we spread candidates 0, 8, 16, 24
        )
            for layout_seed in [13]
            for dist_code, funcs in [
                ('rank', ["lambda x: (1/x)**2"]),
                # ('inverse-log-tfidf', ["lambda x: pow(4.4,1/x)"]),
            ]
            for top_rank_count in [2]
        ],

        'distances-movielens.ipynb': [dict(
            # run=f'{str_params(dict(run=run, dist_code=dist_code, top_rank_count=top_rank_count, layout_seed=layout_seed))}',
            run=f'{run}',
            dist_code=dist_code,
            top_rank_count=top_rank_count,
            layout_seed=layout_seed,
            min_popularity=20,
            sample_orders=None,
            recalc=False,
            dataset=dataset,
            dist2force_funcs=funcs,
            graph_iterations=[10000],
            search_terms=titles
        )
            for layout_seed in [13]
            for run, dataset, titles in [
                ('classic', es.data_config.data_movielens_25m, MovielensUtils.TITLES_CLASSIC),
                ('classic4', es.data_config.data_movielens_25m, MovielensUtils.TITLES_CLASSIC_4), # for UAI
                ('star-trek-all', es.data_config.data_movielens_25m, MovielensUtils.TITLES_STAR_TREK_ALL),
                ('star-wars-all', es.data_config.data_movielens_25m, MovielensUtils.TITLES_STAR_WARS_ALL),
                ('indiana-all', es.data_config.data_movielens_25m, MovielensUtils.TITLES_INDIANA_ALL),
                ('marvel', es.data_config.data_movielens_25m, MovielensUtils.TITLES_MARVEL_ALL),
                ('jamesbond', es.data_config.data_movielens_25m, MovielensUtils.TITLES_JAMES_BOND_ALL),
            ]
            for dist_code, funcs in [
                ('rank', ["lambda x: (1/x)**2"]),
                # ('inverse-log-tfidf', ["lambda x: pow(2.55,1/x)"]),
            ]
            for top_rank_count in [2]
        ],

    }
)


def run_notebooks(target_run, rerun=False):
    start = time.time()
    cwd = "notebooks"
    for filename, paramslist in run_config_dict[target_run].items():
        for params in paramslist:
            str_postfix = f'.{params2filename(params)}.ipynb'
            params.update(dict(target=target_run))
            out_folder = experiment_out_folder(params, filename.replace('.ipynb', ''))
            if not os.path.exists(out_folder):
                os.makedirs(out_folder)
            out_filename = f"{out_folder}/{filename.replace('.ipynb', str_postfix)}"
            done_filename = f"{out_folder}/done.done"
            should_run = True
            if not os.path.exists(done_filename):
                status = f"Running a new run"
            elif rerun:
                status = f"Overwriting an existing run"
            else:
                status = f"Skipping - target already exists"
                should_run = False

            print(f"{status}, target: '{target_run}' for {filename}, outputs: {out_filename}")
            if should_run:
                pm.execute_notebook(
                    f'{cwd}/{filename}',
                    f'{out_filename}',
                    parameters=params,
                    cwd=cwd
                )
                with open(done_filename, 'w+') as f:
                    f.write("done")
        print(f"notebooks finished in {time.time() - start:.3f} sec")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-t", "--target", choices=run_config_dict.keys(), required=True, help="target")
    ap.add_argument("-rr", "--rerun", dest='rerun', action='store_true', help="rerun existing experiments")
    ap.add_argument("-norr", "--no-rerun", dest='rerun', action='store_false',
                    help="ignore existing experimments (don't rerun)")
    ap.set_defaults(rerun=False)
    args = vars(ap.parse_args())

    run_notebooks(target_run=args['target'], rerun=args['rerun'])
