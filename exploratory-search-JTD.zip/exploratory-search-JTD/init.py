from es.data.movielens_data import MovielensData
from es.data_config import data_movielens_100k, data_movielens_1m, data_movielens_25m


def setup():


    # ====================== MOVIELENS

    MovielensData(data_movielens_100k).convert_raw2parquet()
    MovielensData(data_movielens_1m).convert_raw2parquet()
    MovielensData(data_movielens_25m).convert_raw2parquet()

    pass


if __name__ == "__main__":
    setup()
