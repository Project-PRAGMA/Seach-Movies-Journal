import os

from es.data_config import data_folder_movielens_raw

for folder in [data_folder_movielens_raw]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# -------------------- movielens

print(f"downloading the raw movielens datasets to {data_folder_movielens_raw}")
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-100k.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-1m.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-10m.zip ')
# os.system(f'wget -P {data_folder_movielens_raw} http://files.grouplens.org/datasets/movielens/ml-25m.zip ')
